#                  _       _ 
#                 | |     | |
#  _ __ ___   __ _| |_ ___| |__ 
# | '_ ` _ \ / _` | __/ __| '_ \ 
# | | | | | | (_| | || (__| | | |
# |_| |_| |_|\__,_|\__\___|_| |_|

from datetime import date, timedelta
import os
import sys

configs = os.path.dirname(__file__) # code/stats/configs
dir01 = os.path.split(configs)[0] # code/stats
funcs = os.path.join(dir01, 'funcs') # code/stats/funcs
sys.path.append(funcs)

from functions_stats import * 

# Fix environment warning message for pyspark.pandas
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1"

# Sys path
sys_path = "match2"

# Date set
today = date.today()
week_start = today - timedelta(days=today.weekday())
week_start_str = str(week_start)
previous_week_start = week_start - timedelta(weeks=1)
previous_week_start_str = str(previous_week_start)

# Getting last 180 days
today_180= today - timedelta(days= 180)
today_180= today_180.strftime("%Y-%m-%d")

# Latest Files (Requires function_stats.py to be run first)
latest_udprn_date = latest_directory('match2/udprn')
latest_taxonomy_date = latest_directory('match2/taxonomy')

chv_path= '/user/unity/v2/monthly_cv'
latest_chv = latest_file(chv_path, 'IP_Address_Data_Output_')

# Dictionaries of Suppliers/Marketplaces {'full_name': 'acronym_name'} (note: Unacast to be added back in when their data is being ingested)
ip_suppliers_dict =  {'channel_view': 'chv', 'digital_element': 'de', 'unacast': 'uc'}
uid_suppliers_dict = {'id5': 'id5'}
marketplaces_dict =  {'pubmatic': 'pubm'}

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##############################
### Which Process running? ###
##############################

n = 1
    # 1: Normal Run
    # 2: Unit Test Run ("Stats Test")
    # 3: Quick Run
    # 4: Wrong Data Run

if n==2: # Unit Test Run ("Stats Test")
    # Date set
    today = "2022-12-19"
    week_start = "2022-12-19"
    previous_week_start = "2022-12-12"
    latest_mc_date = '2022-12-21'
    latest_udprn_date = '2022-12-21'
    # Sys Path
    sys_path += "/test/stats_test"
elif n==3: # Quick Run
    # Date set
    week_start = input("\nWHAT IS THE {week_start} BEING USED?\n\tYYYY-MM-DD  >>>  ")
    previous_week_start = week_start
    # Sys Path
    sys_path += "/quick_run"
elif n==4: # Wrong Data Run
    # Date set
    week_start = ""
    previous_week_start = ""
    # Sys Path
    sys_path += "/test/wrong_test"

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

####################
###  FILE PATHS  ###
####################

# S01_taxonomy_suppress_stats.py
S01_stats_in1 = os.path.join(sys_path, "process", week_start_str, "taxonomy_suppress.parquet")
S01_stats_out1 = os.path.join(sys_path, "stats", week_start_str, f"taxonomy_suppress_stats__{week_start}.csv")

# S02_to_ip_supplier_stats.py
# S02_stats_in1 = os.path.join(sys_path, "udprn", latest_udprn_date, "udprn_lat_lon.parquet") # TODO why was this being read in?
S02_stats_in1 = os.path.join(sys_path, "de", week_start_str, "to_de.csv") 
S02_stats_in2 = os.path.join(sys_path,"process","historic_udprn_lat_lon.parquet")
S02_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"to_ip_supplier_stats__{week_start}.csv")
S02_stats_out2 = os.path.join(sys_path,"stats", week_start_str,f"to_ip_supplier_latlon_udprn_count_distribution_stats__{week_start}.csv")
S02_stats_out3 = S02_stats_in2

# S03_from_ip_supplier_stats.py
S03_stats_in1_dict = {'digital_element': os.path.join(sys_path,"process", week_start_str,"de01_long.parquet"),
                      'unacast': os.path.join(sys_path,"unacast", week_start_str,"process/unacast_hh_ip.parquet")}
S03_stats_in2 = os.path.join(sys_path, "process", week_start_str, "taxonomy_suppress.parquet")
S03_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"from_ip_supplier_stats__{week_start}.csv")
    # S03_stats_out2 = os.path.join(sys_path,"stats", week_start_str,f"from_ip_supplier_<>_latlon_ip_time_count_distribution_stats__{week_start}.parquet")
    # S03_stats_out3 = os.path.join(sys_path,"stats", week_start_str,f"from_ip_supplier_<>_latlon_ip_count_distribution_stats__{week_start}.parquet")
S03_stats_out4 = os.path.join(sys_path,"stats", week_start_str,f"from_ip_supplier_<>_udprn_ip_count_distribution_stats__{week_start}.parquet")

# S04_check_vs_chv_stats.py
S04_stats_in1_dict = {'digital_element': os.path.join(sys_path,"process", week_start_str,"DE_flag_chv.parquet"),
                      'unacast': os.path.join(sys_path,"unacast", week_start_str,"process/unacast_hh_ip_flags.parquet")}
S04_stats_in2 = os.path.join(sys_path,"process", week_start_str,"taxonomy_suppress.parquet")
S04_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"check_vs_chv_stats__{week_start}.csv")

# S05_check_vs_pub_stats.py
S05_stats_in1 = os.path.join("v2/central_backlog/*/*/preprocessed_data.parquet") # Publisher IPs
S05_stats_in2 = os.path.join(sys_path,"process", week_start_str,"chv_mk2.parquet")
S05_stats_in3_dict = {'digital_element': os.path.join(sys_path,"process", week_start_str,"DE_cb_key.parquet"),
                      'unacast': os.path.join(sys_path,"unacast", week_start_str,'process/unacast_hh_ip_flags.parquet')}
S05_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"initial_check_vs_pub_stats__{week_start}.csv")
S05_stats_out2 = os.path.join(sys_path,"stats", week_start_str,f"check_vs_pub_stats__{week_start}.csv")

# S06_ip_supplier_data_deletion_stats.py
S06_stats_in1_dict = {'digital_element': os.path.join(sys_path,"process", week_start_str,"DE_rows_to_keep.parquet"),
                      'unacast': os.path.join(sys_path,"unacast", week_start_str,'process/unacast_hh_ip_flags.parquet')}
S06_stats_in2_dict = {'digital_element': os.path.join(sys_path,"process", week_start_str,"DE_rows_for_deletion.parquet"),
                      'unacast': os.path.join(sys_path,"unacast", week_start_str,'process/unacast_hh_ip.parquet')}
S06_stats_in3_dict = {
    'digital_element': [
        os.path.join(sys_path,"de", week_start_str,"from_de__*.csv.gz"),
        os.path.join(sys_path,"process", week_start_str,"DE_rows_for_deletion.parquet"),
        os.path.join(sys_path,"process", week_start_str,"DE_cb_key.parquet"),
        os.path.join(sys_path,"process", week_start_str,"DE_flag_chv.parquet"),
        os.path.join(sys_path,"process", week_start_str,"DE_flag_chv_pubip.parquet"),
        os.path.join(sys_path,"process", week_start_str,"de01.parquet"),
        os.path.join(sys_path,"process", week_start_str,"de01_long.parquet"),
    ],
    'unacast': [
        os.path.join(sys_path,"unacast", week_start_str,'from_unacast__*.csv'),
        os.path.join(sys_path,"unacast", week_start_str,'process/unacast_hh_ip.parquet')
    ]
}
S06_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"ip_supplier_data_deletion_stats__{week_start}.csv")

# S07_chv_mk2_stats.py
S07_stats_in1 = os.path.join(sys_path,"process", week_start_str,"chv_mk2.parquet")
S07_stats_in2 = os.path.join(sys_path,"process", week_start_str,"taxonomy_suppress.parquet")
S07_stats_in3 = latest_chv
S07_stats_in4_dict = {'digital_element': os.path.join(sys_path,"process", week_start_str,"DE_cb_key.parquet")}
S07_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"chv_mk2_stats__{week_start}.csv")

# S08_to_uid_supplier_stats.py
S08_stats_in1 = os.path.join("id_graph","uid", previous_week_start_str,"chv_mk2_180.parquet") # NB this is from previous_week_start as those IPs were sent to UID suppliers, so tells use where to attribute IPs
S08_stats_in2 = os.path.join(sys_path,"id5", week_start_str, "to_id5.csv")
S08_stats_in3 = os.path.join(sys_path,"process", week_start_str, f"to_id5_with_exclusive_flag.parquet")
S08_stats_out1 = os.path.join(sys_path,"stats", week_start_str, f"to_uid_supplier_stats__{week_start}.csv")
S08_stats_out2 = os.path.join(sys_path,"stats", week_start_str, f"to_uid_supplier_all_timestamp_distribution_stats__{week_start}.parquet")
S08_stats_out3 = os.path.join(sys_path,"process", week_start_str, f"to_id5_with_exclusive_flag.parquet")

# S09_from_uid_supplier_stats.py
S09_stats_in1_dict = {'id5': os.path.join(sys_path,"process", week_start_str, "id5.parquet")}
S09_stats_in2 = os.path.join(sys_path,"process", week_start_str, f"to_id5_with_exclusive_flag.parquet")
S09_stats_out1 = os.path.join(sys_path,"stats", week_start_str, f"from_uid_supplier_stats__{week_start}.csv")
S09_stats_out2 = os.path.join(sys_path,"stats", week_start_str, f"from_uid_supplier_<uid_supp>_ip_uid_count_distribution_stats__{week_start}.parquet")
S09_stats_out3 = os.path.join(sys_path,"stats", week_start_str, f"from_uid_supplier_<uid_supp>_uid_ip_count_distribution_stats__{week_start}.parquet")
S09_stats_out4 = os.path.join(sys_path,"stats", week_start_str, f"from_uid_supplier_<uid_supp>_timestamp_distribution_stats__{week_start}.parquet")
S09_stats_out5 = os.path.join(sys_path,"process", week_start_str, f"from_uid_suppliers_with_ip_source__{week_start}.parquet")

# S10_combiner_stats.py
S10_stats_in1 = os.path.join(sys_path,"process", week_start_str,"uid_hh_dd.parquet")
S10_stats_in2 = os.path.join(sys_path,"stats", week_start_str,f"taxonomy_suppress_stats__{week_start}.csv")
S10_stats_in3 = os.path.join(sys_path,"process", week_start_str, f"from_uid_suppliers_with_ip_source__{week_start}.parquet")
S10_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"combiner_stats__{week_start}.csv")

# S11_to_marketplace_stats.py
S11_stats_in1_dict = {'pubmatic' : os.path.join(sys_path,"process", week_start_str,"uid_s_code_pub.parquet"),
                        'all' : os.path.join(sys_path,"process", week_start_str,"uid_s_code_cal.parquet")}
S11_stats_in2_dict = {'pubmatic' : '/data/griffin/S_CODE_PUBMATIC.csv', 
                        'all' : os.path.join(sys_path,"taxonomy", latest_taxonomy_date, 'process/S_Code_Dist.parquet')}
S11_stats_out1 = os.path.join(sys_path,"stats", week_start_str, f"to_mkt_stats__{week_start}.csv")
S11_stats_out2 = os.path.join(sys_path,"stats", week_start_str, f"to_mkt_<>_seg_uid_count_distribution_stats__{week_start}.parquet")
S11_stats_out3 = os.path.join(sys_path,"stats", week_start_str, f"to_mkt_<>_uid_seg_count_distribution_stats__{week_start}.parquet")
# match2/process/2023-09-25/uid_s_code_pub_all.parquet

# S11_1_pubmatic_marketplace_stats.py
S11_1_stats_in1 = os.path.join(sys_path,"process", week_start_str,"uid_s_code_pub_all2.parquet")       
S11_1_stats_in2 = os.path.join(sys_path,"process", week_start_str,"hh_all.parquet")
S11_1_stats_in3 = os.path.join(sys_path,"process", week_start_str,"ip_all.parquet")
S11_1_stats_in4 = os.path.join(sys_path,"process", week_start_str,"uid_s_code_pub_all.parquet")
S11_1_stats_in5 = os.path.join(sys_path,"stats", '*', "pubmatic_seg_uid_count_stats__*.csv")
S11_1_stats_out1 = os.path.join(sys_path,"stats", week_start_str, f"pubmatic_uid_backlog_stats__{week_start}.csv")
S11_1_stats_out2 = os.path.join(sys_path,"stats", week_start_str, f"pubmatic_seg_uid_count_stats__{week_start}.csv")

# S99_stakeholder_dashboard_stats.py
S99_stats_in1 = os.path.join(sys_path,"stats/*/to_mkt_stats__*.csv")
S99_stats_in2 = os.path.join(sys_path,"stats", week_start_str, f"to_mkt_all_seg_uid_count_distribution_stats__{week_start}.parquet")
S99_stats_in3 = os.path.join(sys_path,"stats", '*', "to_mkt_all_seg_uid_count_distribution_stats__*.parquet")
S99_stats_out1 = os.path.join(sys_path,"stats", week_start_str,f"stakeholder_dashboard_unique_uids_stats__{week_start}.csv")
S99_stats_out2 = os.path.join(sys_path,"stats", week_start_str,f"stakeholder_dashboard_uid_count_for_segments_stats__{week_start}.csv")

