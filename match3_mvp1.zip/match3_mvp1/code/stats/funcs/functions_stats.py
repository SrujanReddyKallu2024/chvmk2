from pyspark.sql.functions import udf
from pyspark.sql.functions import col

def add_ip_type_column(df, ip_col='ip'):
    """
    Checks if each row in a column is an IP address, and returns the IP address type (IPv4 or IPv6).
    The result is outputted to a new column called 'ip_type'.
    
        Parameters:
            df (dataframe): Spark DataFrame with IP address column
            ip_col (str): The name of the IP address column.  Default = "ip"

            Returns:
            df (dataframe): Spark DataFrame with an additional column "ip_type" to denote the IP type (ipv4, ipv6 or invalid_ip)
    """
    from pyspark.sql.types import StringType    
    #
    def ip_type(ip):
        """
        Checks what the IP type is of a given IP address.

        Parameters:
            ip (str) : The IP address

        Returns:
            ip_type (str) : The IP type ("ipv4", "ipv6" or "invalid_ip")
        """
        import ipaddress    
        # Check if IPv4
        try:
            ip_test = ipaddress.IPv4Address(ip)
            return "ipv4"
        except:
            # Check if IPv6
            try:
                ip_test = ipaddress.IPv6Address(ip)
                return "ipv6"
            except:
                return "invalid_ip"
    #
    # create UDF function
    udf_ip_type = udf(lambda x: ip_type(x), StringType())
    #
    return df.withColumn('ip_type', udf_ip_type(col(ip_col)))

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

def latest_directory(path, pattern='202'):
    """
    Finds latest file or directory.
    #
    Parameters
    ----------
    path (str): The path for the directory you wish to search
    #   
    Returns
    -------
    latest_directory (str): The most recent directory available in the path given
    #
    """
    #
    import subprocess
    import re
    #
    shell_info = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    shell_info_list = str(shell_info).split("\\n")
    #  
    all_directories = []
    date_length = len('YYYY-MM-DD')
    for x in shell_info_list:
        # only interested in filepath, located at the end of each item shell_info_list
        possible_filepath = x.split()[-1] 
        if 'match2/' in possible_filepath: # only grab filepaths with '202' (default) at start
            possible_directory = possible_filepath[-date_length:] # only grab the YYYY-MM-DD of filepath
            if possible_directory.startswith(pattern):
                directory = possible_filepath[-date_length:]  
                all_directories.append(directory) # append to list
    #
    latest_directory = sorted(all_directories)[-1]
    return latest_directory

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

def latest_file(path, pattern=''):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    '''
    import subprocess
    import re
    import os
    files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    dirx= y[-1]
    return dirx


def delete_from_hdfs(file_list):
    """
    Deletes files from given hdfs paths
    Returns: A dictionary with file paths as keys and deletion status as values
    """
    import subprocess
    for file_path in file_list:
        del_cmd = ["hdfs","dfs","-rm","-r","-skipTrash", file_path]    
        delproc = subprocess.run(del_cmd, capture_output=True, text=True)
        if delproc.returncode != 0:
            print("Error deleting file: ", file_path)            
        else:
            print("Deleted file: ", file_path)