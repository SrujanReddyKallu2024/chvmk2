# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2.1) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show as "de")
    # (3.1) count_cbk_deletion - The number of unique CB Key Households, originating from the specified IP supplier file, which were not matched and not used
    # (3.2) count_ip_deletion - The number of unique IP addresses, originating from the specified IP supplier file, which were not matched and not used
    # (3.3) count_cbk_ip_unmatched - The number of [CB Key Household, IP Address] combinations, originating from the specified IP Supplier file, which were not matched and not used
    
# Input: [unmatched_ip_supplier, matched_ip_supplier]
# Output: timestamp with stats as shown above    

# ESTIMATED TIME: <1 MINUTE

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries  
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType

spark = SparkSession.builder.appName("ip_supplier_data_deletion_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
funcs = os.path.join(dir01, 'funcs')
sys.path.append(configs)
sys.path.append(funcs)


from stats_addresses import *
from functions_stats import delete_from_hdfs

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()
stats_list = [] # for loop below will append stats for each ip supplier

ip_suppliers_dict2 = ip_suppliers_dict.copy()
del ip_suppliers_dict2['channel_view'] # dont need ChV ips in this dictionary
ip_suppliers_dict2['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

# Empty dataframe for aggregating IP suppliers' data
schema = StructType([StructField('cb_key_household',StringType(),True),
                     StructField('ip',StringType(),True)])
keep_agg = spark.createDataFrame(data=[], schema=schema) 
deletion_agg = spark.createDataFrame(data=[], schema=schema) 
        # |cb_key_household| ip|
        # +----------------+---+
        # +----------------+---+

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

for ip_supplier in ip_suppliers_dict2:
    # Record timings 
    loop_start_time = time.time()
    print(f'Starting stats for {ip_supplier}')
    ip_supplier_acronym = ip_suppliers_dict2[ip_supplier]
    # Import Data
    if ip_supplier == 'all':
        keep = keep_agg
        deletion = deletion_agg
    else:
        try:
            keep = spark.read.parquet(S06_stats_in1_dict[ip_supplier]).select('cb_key_household', 'ip').distinct()
            deletion = spark.read.parquet(S06_stats_in2_dict[ip_supplier]).select('cb_key_household', 'ip').distinct()
        except:
            print(f"\t\tException Occured - Can't import {ip_supplier} data ")        
        #
        # Fix there being no uc_for_deletion file (leave behind what wasnt brought into the keep file)
        if ip_supplier == 'unacast':
            deletion = deletion.join(keep, ['cb_key_household', 'ip'], 'left_anti')
        #
        # Union to aggregate table (keep_agg)
        try:
            keep_agg = keep_agg.unionByName(keep, allowMissingColumns=True)   # add the ip suppliers dataframe to the aggregate dataframe, if its not the final 'all' run
            deletion_agg = deletion_agg.unionByName(deletion, allowMissingColumns=True)   # add the ip suppliers dataframe to the aggregate dataframe, if its not the final 'all' run
        except:
            print(f"\t\tException Occured - Can't add {ip_supplier} data to aggregate table")   
    #
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------
    # Process Data 
    # CB Key Household 
    keep_cbk = keep.select('cb_key_household').distinct() # unique cb_key_households
    keep_cbk = keep_cbk.withColumn('keep_flag', F.lit('1')) # flag cb_key_household to keep
    deletion_cbk = deletion.join(keep_cbk, 'cb_key_household', 'left') # join with cb_key_household for deletion
    deletion_cbk_final = deletion_cbk.where(F.col('keep_flag').isNull()).select('cb_key_household') # Final unique list of CBKs for deletion
            # |  cb_key_household|
            # |102039246310735872|
    # IP
    keep_ip = keep.select('ip').distinct() # Group by IPs
    keep_ip = keep_ip.withColumn('keep_flag', F.lit('1')) # flag IPs to keep
    deletion_ip = deletion.join(keep_ip, 'ip', 'left') # join with IPs for deletion
    deletion_ip_final = deletion_ip.where(F.col('keep_flag').isNull()).select('ip') # Final unique list of IPs for deletion
            # |            ip|
            # |109.104.101.54|
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------
    ##############
    ### STATS ####
    ##############
    # (1.1) date_of_calculation & (1.2) week_start
    stats_data={'date_of_calculation': str(today), 'week_start': week_start_str}
    #
    # (2.1) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show a "de")
    stats_data['ip_supplier'] = ip_supplier_acronym
    #
    # (3.1) count_cbk_deletion - The number of unique CB Key Households, originating from the specified IP supplier file, which were not matched and not used
    try:
        stats_data['count_cbk_deletion'] = deletion_cbk_final.groupby('cb_key_household').count().count()                          
    except:
        stats_data['count_cbk_deletion'] = 0
    #
    # (3.2) count_ip_deletion - The number of unique IP addresses, originating from the specified IP supplier file, which were not matched and not used
    try:
        stats_data['count_ip_deletion'] = deletion_ip_final.groupby('ip').count().count()                               
    except:
        stats_data['count_ip_deletion'] = 0
    #   
    # (3.3) count_cbk_ip_unmatched - The number of [CB Key Household, IP Address] combinations, originating from the specified IP Supplier file, which were not matched and not used
    try:
        stats_data['count_hh_ip_unmatched'] = deletion.count()  
    except:
        stats_data['count_hh_ip_unmatched'] = 0
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------
    # Append stats_data to stats_list
    stats_list.append(stats_data)
    # time split
    split_time = round((time.time() - loop_start_time) / 60, 1) 
    print(f"Stats for {ip_supplier} took: {split_time} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------
 
#####################
###  SAVE AS CSV  ###
#####################
                   
# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

stats_psdf

# Export Stats as CSV
stats_psdf.to_csv(S06_stats_out1, emptyValue='')
    
# script run times
script_duration = round((time.time() - time_script_start) / 60, 1)
print(f"Stats for whole script:\t{script_duration} minutes")

## data cleanup after stats
ip_suppliers_dict2.pop('all',None)
for ip_supplier in ip_suppliers_dict2:
    delete_from_hdfs(S06_stats_in3_dict[ip_supplier])
    
    
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - keep
    # |           ip| cb_key_household|
    # +-------------+-----------------+
    # |104.28.214.13|87882052159930368|
    # |104.28.214.13|87882052162027520|

# INPUT 2 - deletion
    # |            ip|   cb_key_household|
    # +--------------+-------------------+
    # |104.28.154.101|4889331294239981568|
    # |104.28.154.101|4889331294238932992|


# OUTPUT - stats_psdf
#   date_of_calculation  week_start ip_supplier  count_cbk_deletion  count_ip_deletion  count_hh_ip_unmatched
# 0          2023-11-19  2023-11-13          de             5999706            1095923               32559957
# 1          2023-11-19  2023-11-13          uc             3509026             330478               38190705
# 2          2023-11-19  2023-11-13         all             5996848            1101126               70750662


