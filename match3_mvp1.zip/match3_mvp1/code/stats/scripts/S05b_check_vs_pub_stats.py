# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show as "de")    
    # (3.2) count_ip_matched_on_pub_ip - The number of unique usable IP addresses originating from IP Supplier's file and have matched to an IP addresses on the Publishers IP file
    # (4.1) count_cbk_matched_on_pub_ip - The number of unique CB Key Households (from matching useable IP addresses between IP supplier and Publishers)    
    # (4.3) count_cbk_matched_to_pub_and_chv - The number of unique CB Key Households (from matching useable IP addresses between IP supplier and Publishers), which are already matched on Channel View
    # (4.4) pct_pub_cbk_matched_to_chv - The percentage of CB Key Households (from matching useable IP addresses between IP supplier and Publishers) which are already matched on Channel View CB Key Households (count_cbk_matched_to_pub_and_chv / count_cbk_matched_on_pub_ip
    # (5.1) count_cbk_matched_via_pub_cv - The number of unique CB Key Households (from matching useable IP addresses between IP supplier and Publishers), which are not in Channel View so have been added via Consumer View
    # (5.2) count_ip_matched_via_pub_cv - The number of unique IP Addresses, originating from the IP Supplier's file, which are associated with the count_cbk_matched_via_pub_cv

# Input: [chv_mk2, Publisher IP file, IP supplier ingested file]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: <1 MIN

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
import os
import sys
from datetime import date, timedelta
import pyspark.sql.functions as F
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1" # Fix environment warning message for pyspark.pandas
import pyspark.pandas as ps
import time
from pyspark.sql import SparkSession
import pandas as pd

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)

from stats_addresses import *

spark = SparkSession.builder.appName("S05_check_vs_pub_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()

chv_condition = F.col('flag_chv') == 1
not_chv_condition = F.col('flag_chv') == 0
pub_condition = F.col('flag_pubip') == 1

ip_suppliers_dict2 = ip_suppliers_dict.copy()
del ip_suppliers_dict2['channel_view'] # dont need ChV ips in this dictionary
ip_suppliers_dict2['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Data
pub = spark.read.parquet(S05_stats_in1)

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Process Data
stats_list = [] # each loop of stats will add an ip supplier's stats to this list. (will be a list of dictionaries)

# Accumulating last 180 days from Publisher IPs
pub2= pub.groupby('ip').agg(F.max('last_seen').alias('last_seen')) # grab the most recently seen date for each IP
pub3= pub2.select('ip', F.from_unixtime(F.col("last_seen")).alias("x")) # convert last_seen from unix time
pub4= pub3.withColumn('Timestamp', F.substring('x', 1,10)).drop('x') # grab only the yyyy-mm-dd
pub5= pub4.where(F.col('Timestamp')>= today_180) # filter to only dates within last 180 days
        # |            ip| Timestamp|
        # |154.115.221.78|2023-10-20|
pub_ip_count = pub5.select('ip').distinct().count()

# cache for faster processing
pub5.cache()
print(f'{pub5.count():,} rows')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##############
### STATS ####
##############    
# Separating out chv stats
# Import Data
stats_list = []
try:
    previous_stats = spark.read.csv(S05_stats_out1, header=True).toPandas()
    print("previous stats found")
    chv_mk2 = spark.read.parquet(S05_stats_in2)
    print("read chv mk2 data")
except Exception as e:
    print(f"ERROR: {e}")
else:
    chv_mk2.cache()
    print(f'{chv_mk2.count():,} rows')    
    for ip_supplier in ip_suppliers_dict2:
        loop_start_time_2 = time.time()
        ip_supplier_acronym = ip_suppliers_dict2[ip_supplier]
        if ip_supplier == 'all':            
            ip_supp_condition = (F.col('chv_de_flag')=='de') | (F.col('chv_de_flag')=='uc')
        else:
            ip_supp_condition = F.col('chv_de_flag') == ip_supplier_acronym
        # (1.1) date_of_calculation & (1.2) week_start
        stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
        # (2.1) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show a "de")
        stat_name = 'ip_supplier'   
        try:
            stats_data[stat_name] = ip_supplier_acronym
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        #
        # (3.1) count_ip_from_pub - The number of unique usable IP addresses in the Publisher IP file
        stat_name = 'count_ip_from_pub'
        try:
            stats_data[stat_name] = pub_ip_count
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        #
        # (3.2) count_ip_matched_on_pub_ip - The number of unique usable IP addresses originating from IP Supplier's file and have matched to an IP addresses on the Publishers IP file
        stat_name = 'count_ip_matched_on_pub_ip'
        try:
            supp_ip_and_pub_ip = chv_mk2.where(pub_condition & ip_supp_condition)
            stats_data[stat_name] = supp_ip_and_pub_ip.select('ip').distinct().count()
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        # (4.1) count_cbk_matched_on_pub_ip - The number of unique CB Key Households (from matching useable IP addresses between IP supplier and Publishers)
        stat_name = 'count_cbk_matched_on_pub_ip'
        try:
            stats_data[stat_name] = supp_ip_and_pub_ip.select('cb_key_household').distinct().count()
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        #
        # (4.2) pct_cbk_matched_on_pub_ip - The percentage of unique CB Key Households in the file from IP supplier, which have been successfully matched to a Publisher useable IP address (count_cbk_matched_on_pub_ip / count_cbk_before_chv_matching)
        stat_name = 'pct_cbk_matched_on_pub_ip'
        try:            
            stats_data[stat_name] = stats_data['count_cbk_matched_on_pub_ip'] / int(previous_stats.loc[previous_stats["ip_supplier"]==ip_supplier_acronym]["count_cbks_in_ip_supplier_file"].values[0])
        except:            
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        #        
        # (4.3) count_cbk_matched_to_pub_and_chv - The number of unique CB Key Households (from matching useable IP addresses between IP supplier and Publishers), which are already matched on Channel View
        stat_name = 'count_cbk_matched_to_pub_and_chv'
        try:
            pub_and_chv = chv_mk2.where(pub_condition & chv_condition & ip_supp_condition) 
            stats_data[stat_name] = pub_and_chv.select('cb_key_household').distinct().count()
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        # (4.4) pct_pub_cbk_matched_to_chv - The percentage of CB Key Households (from matching useable IP addresses between IP supplier and Publishers) which are already matched on Channel View CB Key Households (count_cbk_matched_to_pub_and_chv / count_cbk_matched_on_pub_ip
        stat_name = 'pct_pub_cbk_matched_to_chv'
        try:
            stats_data[stat_name] = stats_data['count_cbk_matched_to_pub_and_chv'] / stats_data['count_cbk_matched_on_pub_ip']
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0        
        # -------------------------------------------------------------------------------------------------------------------------------------------------------------
        # (5.1) count_cbk_matched_via_pub_cv - The number of unique CB Key Households (from matching useable IP addresses between IP supplier and Publishers), which are not in Channel View so have been added via Consumer View
        stat_name = 'count_cbk_matched_via_pub_cv'
        try:
            pub_not_chv = supp_ip_and_pub_ip.where(~chv_condition)
            stats_data[stat_name] = pub_not_chv.groupby('cb_key_household').count().count()
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        #
        # (5.2) count_ip_matched_via_pub_cv - The number of unique IP Addresses, originating from the IP Supplier's file, which are associated with the count_cbk_matched_via_pub_cv
        stat_name = 'count_ip_matched_via_pub_cv'
        try:
            stats_data[stat_name] = pub_not_chv.select('ip').distinct().count()
        except:
            print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
            stats_data[stat_name] = 0
        #
        stats_list.append(stats_data)
        split_time = round((time.time() - loop_start_time_2) / 60, 1) 
        print(f"Stats for {ip_supplier} took: {split_time} minutes")
    # Combine Stats into Pandas DataFrame
    stats_df = pd.DataFrame.from_dict(stats_list)
    combined_stats = pd.merge(previous_stats, stats_df, on=['week_start', 'ip_supplier'])
    # Export Stats as CSV
    final_stats = (
        spark.createDataFrame(combined_stats)
        .withColumn("date_of_calculation", F.when(F.col("date_of_calculation_y") > F.col("date_of_calculation_x"), F.col("date_of_calculation_y")).otherwise(F.col("date_of_calculation_x")))        
        .select("date_of_calculation","week_start","ip_supplier","count_ip_from_pub","count_ip_matched_on_pub_ip","count_cbk_matched_on_pub_ip","pct_cbk_matched_on_pub_ip","count_cbk_matched_to_pub_and_chv","pct_pub_cbk_matched_to_chv","count_cbk_matched_via_pub_cv","count_ip_matched_via_pub_cv")
    )
    final_stats.write.csv(S05_stats_out2, header=True, mode="overwrite")

# Drop dataframes from memory
try:
    chv_mk2.unpersist()
    pub5.unpersist()
except:
    pass
        
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 pub
    # |publisherid|                fpid|            ip|first_seen| last_seen|numSessions|
    # +-----------+--------------------+--------------+----------+----------+-----------+
    # |      MP002|pubcommonid=307cf...|  90.218.16.29|1675187327|1675187327|          1|
    # |      MP002|pubcommonid=70445...|86.182.227.222|1675203161|1675203161|          1|

# INPUT 2 chv_mk2
    # |           ip| cb_key_household|first_seen| last_seen|ip_rank|ip_flag|flag_chv|flag_pubip|chv_de_flag|
    # +-------------+-----------------+----------+----------+-------+-------+--------+----------+-----------+
    # |104.28.214.13|87882052159930368|2023-08-29|2023-09-04|      0|      1|       1|         0|         de|
    # |104.28.214.13|87882052162027520|2023-08-29|2023-09-04|      1|      1|       1|         0|         de|
    
# INPUT 3 ip_supp_ingest
    # | cb_key_household|           ip|
    # +-----------------+-------------+
    # |73595626727669760|90.204.45.121|
    # |73595626727669760|   80.3.60.54|

# OUTPUT 1 stats_psdf
    #    date_of_calculation  week_start ip_supplier  count_ip_from_pub  count_ip_matched_on_pub_ip  count_cbk_matched_on_pub_ip  pct_cbk_matched_on_pub_ip  count_cbk_matched_to_pub_and_chv  pct_pub_cbk_matched_to_chv  count_cbk_matched_via_pub_cv  count_ip_matched_via_pub_cv
    # 0          2023-11-17  2023-11-13          de            4084146                      993957                      4524810                   0.221728                           2622233                    0.579523                       1902577                       694277
    # 1          2023-11-17  2023-11-13          uc            4084146                      945351                      1306376                   0.365102                            831659                    0.636615                        474717                       694662
    # 2          2023-11-17  2023-11-13         all            4084146                     1552341                      5251227                   0.255477                           3089106                    0.588264                       2162121                      1178083
