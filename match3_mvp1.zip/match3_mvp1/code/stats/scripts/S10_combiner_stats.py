# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (1.3) uid_supplier - The abbreviation for the name of the UID Supplier (e.g. Lotame would show as "lot") 
    # (1.4) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
    # (2.1) count_cbk_with_uid - The number of unique CB Key Households which have an associated UID
    # (2.2) pct_cbk_before_suppress_with_uid - The percentage of all unique CB Key Households (before suppress) which now have at least 1 associated UID
    # (2.3) pct_cbk_after_suppress_with_uid - The percentage of all unique CB Key Households (after suppress) which now have at least 1 associated UID
    # (3) DISTRIBUTION OF [CBK, UID_COUNT] - Each CB Key Household is displayed next to the number of UIDs associated with that particular CB Key Household
    # (3.1) mean_uid_per_cbk - The mean number of UIDs which each CB Key Household has been linked to (count_total_uid divided by the number of unique CB Key Households)
    # (3.2) stddev_uid_per_cbk - The standard deviation around the mean_uid_per_cbk
    # (3.3) min_uid_per_cbk - The lowest number of UIDs which a CB Key Household has been linked to
    # (3.4) max_uid_per_cbk - The highest number of UIDs which a CB Key Household has been linked to
    # (4.1) uid_cbk_ratio - The number of unique UIDs divided by the number of unique CB Key Households (count_unique_uid divided by the number of unique CB Key Households)

# Input: [UDPRN, IP, UID]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: <1 MIN

# TODO
# Loop uid and ip suppliers to find breakdown of above. use S09's code for this

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
import pyspark.sql.functions as F
from pyspark.sql.types import StructType 
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
import pyspark.pandas as ps
from datetime import date, timedelta
from pyspark.sql import SparkSession
import time
import os
import sys

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)

from stats_addresses import *

# Fix environment warning message for pyspark.pandas
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1"

spark = SparkSession.builder.appName("combiner_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()

stats_list = [] # each loop of stats will add a uid supplier's stats to this list. (will be a list of dictionaries)

uid_suppliers_dict['all'] = 'all' # Add 'all' to uid_suppliers_dict to get aggregate stats 
ip_suppliers_dict['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

# column to use to filter to only data from a specified IP supplier
data_flag_col = 'chv_de_flag'

# value to look for in 'type_uid' column to filter to only data from that UID supplier
supplier_type_uids = {'id5': 'id5UID'}

# # Build Blank Dataframe to capture all of the UID suppliers' data # TODO DELETE AS NOT IMPORTING DIFFERENT STUFF NOW FOR EACH UID SUPPLIER
# schema = StructType([StructField('ip',StringType(),True),
#                 StructField('uid',StringType(),True),
#                 StructField('timestamp',IntegerType(),True),
#                 StructField('chv_de_flag',StringType(),True),
#                 StructField('exclusive_ip',StringType(),True)
#                 ])
# uid_df_all = spark.createDataFrame(data=[], schema=schema) 
#         # | ip|uid|timestamp|chv_de_flag|exclusive_ip|
#         # +---+---+---------+-----------+------------+
#         # +---+---+---------+-----------+------------+

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Data
tax_stats = spark.read.csv(S10_stats_in2,header=True)
        # |date_of_calculation|week_start|count_udprn_before_suppress|count_udprn_after_suppress|count_cbk_before_suppress|count_cbk_after_suppress|
        # +-------------------+----------+---------------------------+--------------------------+-------------------------+------------------------+
        # |         2024-01-17|2024-01-15|                   26820785|                  25794249|                 26822741|                25796174|

uid_ip_sources = spark.read.parquet(S10_stats_in3).select('ip', 'uid', 'type_uid', 'chv_de_flag', 'exclusive_ip')
        # |           ip|                 uid|type_uid|chv_de_flag|exclusive_ip|
        # +-------------+--------------------+--------+-----------+------------+
        # |103.7.204.183|ID5-ZHMOH5-DWE1Tj...|  id5UID|         uc|           0|
        # |103.7.204.183|ID5-ZHMOH5-DWE1Tj...|  id5UID|         de|           0|

uid_hh_dd = spark.read.parquet(S10_stats_in1)
        # |  cb_key_household|                 uid|
        # +------------------+--------------------+
        # |172371553575501824|ID5-b920Lkh6dy3Pv...|

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

###################
### ADD SOURCES ###
###################

uid_hh_dd_sources = uid_hh_dd.join(uid_ip_sources, 'uid', 'left')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##############
### STATS ####
##############

for uid_supplier in uid_suppliers_dict:
    uid_supplier_acronym = uid_suppliers_dict[uid_supplier]
    # Timestamp
    print(f'Started UID Supplier: {uid_supplier}')
    uid_loop_start_time = time.time()
    # Filter to only data from specificed UID supplier
    if uid_supplier == 'all':
        uid_df = uid_hh_dd_sources
    else:
        type_uid_condition = F.col('type_uid')==supplier_type_uids[uid_supplier]
        uid_df = uid_hh_dd_sources.where(type_uid_condition)
    #
    uid_df.cache()
    #
    for ip_supplier in ip_suppliers_dict:
        ip_supplier_acronym = ip_suppliers_dict[ip_supplier]
        # Filter to only data from specified IP supplier
        if ip_supplier == 'all':
            uid_ip_df = uid_df # use all the uid file
        else:
            uid_ip_df = uid_df.where(F.col(data_flag_col)==ip_supplier_acronym)
        #
        # -------------------------------------------------------------------------------------------------------------------------------------------------------------
        ##################
        ### STAT CALCS ###
        ##################
        # (1.1) date_of_calculation & (1.2) week_start
        stats_data = {'date_of_calculation': today, 'week_start': week_start_str}
        # (1.3) uid_supplier - The abbreviation for the name of the UID Supplier (e.g. Lotame would show as "lot")
        try:
            stats_data['uid_supplier'] = uid_supplier_acronym
        except:
            stats_data['uid_supplier'] = 0
        #
        # (1.4) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
        try:
            stats_data['ip_supplier'] = ip_supplier_acronym
        except:
            stats_data['ip_supplier'] = 0
        #
        # #(2.1) count_cbk_with_uid - The number of unique CB Key Households which have an associated UID
        try:
            stats_data['count_cbk_with_uid'] = uid_ip_df.groupby('cb_key_household').count().count()
        except:
            stats_data['count_cbk_with_uid'] = 0
        #
        # (2.2) pct_cbk_before_suppress_with_uid - The percentage of all unique CB Key Households (before suppress) which now have at least 1 associated UID
        cast_df = tax_stats.withColumn("count_cbk_before_suppress", tax_stats["count_cbk_before_suppress"].cast(IntegerType()))
        try:
            stats_data['pct_cbk_before_suppress_with_uid'] = stats_data['count_cbk_with_uid'] / cast_df.collect()[0][4]
        except:
            stats_data['pct_cbk_before_suppress_with_uid'] = 0
        #
        # (2.3) pct_cbk_after_suppress_with_uid - The percentage of all unique CB Key Households (after suppress) which now have at least 1 associated UID
        cast_df = tax_stats.withColumn('count_cbk_after_suppress', tax_stats['count_cbk_after_suppress'].cast(IntegerType()))
        try:
            stats_data['pct_cbk_after_suppress_with_uid'] = stats_data['count_cbk_with_uid'] / cast_df.collect()[0][5]
        except:
            stats_data['pct_cbk_after_suppress_with_uid'] = 0
        #
        # (3) DISTRIBUTION OF [CBK, UID_COUNT] - Each CB Key Household is displayed next to the number of UIDs associated with that particular CB Key Household
        cbk_grouped = uid_ip_df.groupby('cb_key_household').agg(F.count('uid').alias('uid_count'))
        cbk_grouped.cache()
        # TODO Technical Debt: save this distribution when uid_supplier=='all'
        #
        # (3.1) mean_uid_per_cbk - The mean number of UIDs which each CB Key Household has been linked to (count_total_uid divided by the number of unique CB Key Households)
        try:
            stats_data['mean_uid_per_cbk'] = cbk_grouped.select(F.mean('uid_count')).collect()[0][0]
        except:
            stats_data['mean_uid_per_cbk'] = 0
        #
        # (3.2) stddev_uid_per_cbk - The standard deviation around the mean_uid_per_cbk
        try:
            stats_data['stddev_uid_per_cbk'] = cbk_grouped.select(F.stddev('uid_count')).collect()[0][0]
        except:
            stats_data['stddev_uid_per_cbk'] = 0
        #
        # (3.3) min_uid_per_cbk - The lowest number of UIDs which a CB Key Household has been linked to
        try:
            stats_data['min_uid_per_cbk'] = cbk_grouped.select(F.min('uid_count')).collect()[0][0]
        except:
            stats_data['min_uid_per_cbk'] = 0
        #
        # (3.4) max_uid_per_cbk - The highest number of UIDs which a CB Key Household has been linked to
        try:
            stats_data['max_uid_per_cbk'] = cbk_grouped.select(F.max('uid_count')).collect()[0][0]
        except:
            stats_data['max_uid_per_cbk'] = 0
        #
        # (4.1) uid_cbk_ratio - The number of unique UIDs divided by the number of unique CB Key Households (count_unique_uid divided by the number of unique CB Key Households)
        try:
            stats_data['uid_cbk_ratio'] = uid_ip_df.groupby('uid').count().count() / stats_data['count_cbk_with_uid']
        except:
            stats_data['uid_cbk_ratio'] = 0
        #
        # ---------------------------------------------------------------------------------------------------------------------------------------------------------
        # Append stats_data to stats_list
        stats_list.append(stats_data)
    
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

# Export Stats as CSV
stats_psdf.to_csv(S10_stats_out1, emptyValue='')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - uid_df

# +-------------------+--------------------+
# |   cb_key_household|                 uid|
# +-------------------+--------------------+
# |6611326690050179072|ID5-229aOAi9Dq-0u...|
# |2854444165786238976|ID5-1844VIcEzbHes...|
# | 138829520109043712|ID5-83d1Uva5pN3Vu...|
# |5515691580550283264|ID5-8585EyOpRN6Ds...|

# INPUT 2 - tax_stats

# +-------------------+----------+---------------------------+--------------------------+-------------------------+------------------------+
# |date_of_calculation|week_start|count_udprn_before_suppress|count_udprn_after_suppress|count_cbk_before_suppress|count_cbk_after_suppress|
# +-------------------+----------+---------------------------+--------------------------+-------------------------+------------------------+
# |         2023-09-06|2023-09-04|                   26755616|                  25734772|                 26757006|                25736137|
# +-------------------+----------+---------------------------+--------------------------+-------------------------+------------------------+


# INPUT 3 - uid_ip_sources
    # |           ip|                 uid| timestamp|chv_de_flag|exclusive_ip|
    # +-------------+--------------------+----------+-----------+------------+
    # |103.7.204.183|ID5-ZHMOH5-DWE1Tj...|1704745200|         uc|           0|
    # |103.7.204.183|ID5-ZHMOH5-DWE1Tj...|1704745200|         de|           0|

# OUTPUT 1

# +-------------------+----------+------------------+--------------------------------+-------------------------------+------------------+------------------+---------------+---------------+------------------+
# |date_of_calculation|week_start|count_cbk_with_uid|pct_cbk_before_suppress_with_uid|pct_cbk_after_suppress_with_uid|  mean_uid_per_cbk|stddev_uid_per_cbk|min_uid_per_cbk|max_uid_per_cbk|     uid_cbk_ratio|
# +-------------------+----------+------------------+--------------------------------+-------------------------------+------------------+------------------+---------------+---------------+------------------+
# |         2023-09-07|2023-09-04|           8657753|              0.3235695727690908|             0.3364045272217816|12.838251102797688|13.009862640137808|              2|            537|3.9271165393607324|
# +-------------------+----------+------------------+--------------------------------+-------------------------------+------------------+------------------+---------------+---------------+------------------+
#   date_of_calculation  week_start  count_cbk_with_uid  pct_cbk_before_suppress_with_uid  pct_cbk_after_suppress_with_uid  mean_uid_per_cbk  stddev_uid_per_cbk  min_uid_per_cbk  max_uid_per_cbk  uid_cbk_ratio
# 0          2023-09-11  2023-09-11             8842904                          0.330308                         0.343405          10.55161            9.901151                1              321       3.068543
