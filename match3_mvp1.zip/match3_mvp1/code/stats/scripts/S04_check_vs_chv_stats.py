# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2.1) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show as "de")
    # (3.1) count_cbk_before_chv_matching - The number of unique CB Key Households which can be attached to the UDPRNs in the file from specified IP supplier
    # (3.2) count_cbk_matched_to_chv - The number of unique CB Key Households, attributed to the file from the specified IP supplier,  which have been matched to Channel View by using CB Key Household
    # (3.3) pct_cbk_matched_to_chv - The percentage of count_cbk_before_chv_matching which has been matched to Channel View, by using CB Key Household
    # (3.4) count_cbk_unmatched_to_chv - The number of unique CB Key Households which have not been matched to Channel View by using CB Key Household
    # (4.1) pct_chv_cbk_matched - The percentage of unique CB Key Households in Channel View, which have been matched to the file from IP supplier, by using CB Key household
    # (5.1) count_ip_matched_to_chv - The number of unique IPs in the file from IP supplier which have been matched to Channel View , by using CB Key Household

# Input: [de_process_files, chv_process_files]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: <1 MIN

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#Import Libraries
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1" # Fix environment warning message for pyspark.pandas
import pyspark.pandas as ps
from datetime import date, timedelta
import time
from pyspark.sql import SparkSession

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)

from stats_addresses import *

spark = SparkSession.builder.appName("S04_check_vs_chv_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()

stats_list = [] # for loop below will append stats for each ip supplier

ip_suppliers_dict2 = ip_suppliers_dict.copy()
del ip_suppliers_dict2['channel_view'] # dont need ChV ips in this dictionary
ip_suppliers_dict2['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

# Empty dataframe for aggregating IP suppliers' data
schema = StructType([StructField('cb_key_household',StringType(),True),
                     StructField('ip',StringType(),True),
                     StructField('flag_chv',StringType(),True)])
df_agg = spark.createDataFrame(data=[], schema=schema) 
        # |cb_key_household| ip|flag_chv|
        # +----------------+---+--------+
        # +----------------+---+--------+

        
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Data
chv = spark.read.parquet(S04_stats_in2).select('cb_key_household')

# Calculate cbk count
chv_cbk_count = chv.distinct().count()

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##############
### STATS ####
##############

time_stats_start = time.time() # to record time for each loop

# Loop through all ip suppliers from dictionary found in stats_addresses.py
for ip_supplier in ip_suppliers_dict2:
    #
    time_split = time.time()
    print(f'Starting stats for {ip_supplier.title()}')
    # Import IP Supplier data
    if ip_supplier == 'all':
        ip_supp_processed = df_agg
    else:
        ip_supp_processed = spark.read.parquet(S04_stats_in1_dict[ip_supplier]).select('cb_key_household', 'ip', 'flag_chv')
        # Add "ip_type" column and union to aggregate table (df_agg)
        try:
            df_agg = df_agg.unionByName(ip_supp_processed, allowMissingColumns=True)   # add the ip suppliers dataframe to the aggregate dataframe, if its not the final 'all' run
        except:
            print(f"\t\tException Occured - Can't add {ip_supplier} data to aggregate table")
    #
    #
    # Cache for faster processing
    ip_supp_processed.cache()
    print(f'\t\t\t{ip_supp_processed.count():,} rows')
    #
    # (1.1) date_of_calculation & (1.2) week_start
    stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
    #
    # (2.1) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show a "de")
    stat_name = 'ip_supplier'
    try:
        ip_supplier_acronym = ip_suppliers_dict2[ip_supplier]
        stats_data[stat_name] = ip_supplier_acronym
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (3.1) count_cbk_before_chv_matching - The number of unique CB Key Households which can be attached to the UDPRNs in the file from specified IP supplier
    stat_name = 'count_cbk_before_chv_matching'
    try:
        stats_data[stat_name] = ip_supp_processed.groupby('cb_key_household').count().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (3.2) count_cbk_matched_to_chv - The number of unique CB Key Households which have been matched to Channel View by using CB Key Household
    stat_name = 'count_cbk_matched_to_chv'   
    try:
        chv_matched = ip_supp_processed.where(ip_supp_processed.flag_chv == 1)
        stats_data[stat_name] = chv_matched.groupby('cb_key_household').count().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #   
    # (3.3) pct_cbk_matched_to_chv - The percentage of count_cbk_before_chv_matching which has been matched to Channel View, by using CB Key Household
    stat_name = 'pct_cbk_matched_to_chv'
    try:
        stats_data[stat_name] = stats_data['count_cbk_matched_to_chv'] / stats_data['count_cbk_before_chv_matching']
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (3.4) count_cbk_unmatched_to_chv - The number of unique CB Key Households which have not been matched to Channel View by using CB Key Household
    stat_name = 'count_cbk_unmatched_to_chv'
    try:
        chv_unmatched = ip_supp_processed.where(ip_supp_processed.flag_chv == 0)
        stats_data[stat_name] = chv_unmatched.groupby('cb_key_household').count().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (4.1) pct_chv_cbk_matched - The percentage of unique CB Key Households in Channel View, which have been matched to the file from IP supplier, by using CB Key household
    stat_name = 'pct_chv_cbk_matched'
    try:
        stats_data[stat_name] = stats_data['count_cbk_matched_to_chv'] / chv_cbk_count
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (5.1) count_ip_matched_to_chv - The number of unique IPs in the file from IP supplier which have been matched to Channel View , by using CB Key Household
    stat_name = 'count_ip_matched_to_chv'
    try:
        stats_data[stat_name] = chv_matched.groupby('ip').count().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
# -------------------------------------------------------------------------------------------------------------------------------------------------------------
    #
    # Append stats_data to stats_list
    stats_list.append(stats_data)
    # Record the time taken
    time_for_loop = round((time.time() - time_split) / 60, 1)
    print(f'{ip_supplier} stats took {time_for_loop} minutes\n')
    #
    # Remove df from cache
    try:
        df.unpersist()
    except:
        continue

# -------------------------------------------------------------------------------------------------------------------------------------------------------------
        
#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

stats_psdf

# Export Stats as CSV
stats_psdf.to_csv(S04_stats_out1, emptyValue='')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# script run times
script_duration = round((time.time() - time_script_start)/60, 1)
print(f"Stats for whole script:\t{script_duration} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - ip_supp_processed
    # |  cb_key_household|  UDPRN|            ip|ip_rank|ip_flag|flag_chv|
    # +------------------+-------+--------------+-------+-------+--------+
    # |102039251127894016|9119170|86.163.149.145|      0|      1|       1|
    # |102039251127894016|9119170|  94.10.30.131|      1|      1|       1|

# INPUT 2 - chv
    # |   UDPRN|   cb_key_household|cb_key_db_person|flag_hh|flag_UDPRN|
    # +--------+-------------------+----------------+-------+----------+
    # |10000022|3920606161181605888|      4006902937|   null|      null|
    # |10000022|3920606161181605888|      4006902938|   null|      null|

# OUTPUT 1 - stats_psdf
    #  date_of_calculation  week_start ip_supplier  count_cbk_before_chv_matching  count_cbk_matched_to_chv  pct_cbk_matched_to_chv  count_cbk_unmatched_to_chv  pct_chv_cbk_matched  count_ip_matched_to_chv
    # 0          2023-11-17  2023-11-13          de                       20406991                  12504867                0.612774                     7902124             0.466107                 10284480
    # 1          2023-11-17  2023-11-13          uc                        3451501                   3151413                0.913056                      300088             0.117466                  5094177
    # 2          2023-11-17  2023-11-13         all                       20555012                  12636448                0.614762                     7918564             0.471012                 13273981

