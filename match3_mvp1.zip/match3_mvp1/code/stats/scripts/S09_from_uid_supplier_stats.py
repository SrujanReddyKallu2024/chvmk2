# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2.1) uid_supplier - The abbreviation for the name of the UID Supplier (e.g. Lotame would show as "lot")
    # (2.2) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
    # (3.1) count_total_uid - The total number (not unique) of UIDs in the file from specified UID supplier, using all of the IP addresses from specified IP address supplier
    # (3.2) count_unique_uid - The number of unique UIDs in the file from specified UID supplier, using all of the IP addresses from specified IP address supplier
    # (3.3) count_exclusive_uid - The number of unique UIDs associated with the IPs which were exclusively from the specified IP address supplier
    # (4.1) count_ip_with_uid - The number of unique IP addresses from the specified IP address supplier(s), which now have at least 1 associated UID from the specified UID supplier(s)
    # (4.2) count_exclusive_ip_with_uid - The number of unique IP addresses which are exclusively provided by the specified IP address supplier(s), and now have at least 1 associated UID from the specified UID supplier(s)
    # (5) DISTRIBUTION OF [IP, UID_COUNT] - Each unique IP address is displayed next to the number of UIDs associated with that particular IP address
    # (5.1) mean_uid_per_ip - The mean number of UIDs which each IP address has been linked to
    # (5.2) stddev_uid_per_ip - The standard deviation around the mean_uid_per_ip
    # (5.3) min_uid_per_ip - The lowest number of UIDs which an IP address has been linked to
    # (5.4) max_uid_per_ip - The highest number of UIDs which an IP address has been linked to
    # (6) DISTRIBUTION OF [UID, IP_COUNT] - Each unique UID is displayed next to the number of IP addresses associated with that particular UID
    # (6.1) mean_ip_per_uid - The mean number of IP addresses which each UID has been linked to
    # (6.2) stddev_ip_per_uid - The standard deviation around the mean_ip_per_uid
    # (6.3) min_ip_per_uid - The lowest number of IP addresses which a UID has been linked to
    # (6.4) max_ip_per_uid - The highest number of IP addresses which a UID has been linked to
    # (7) DISTRIBUTION OF [TIMESTAMP] - Timestamps are shown next to the number of occurences.  Timestamps have been binned into days and rebased with 0 as the week_start
    # (7.1) earliest_timestamp_for_uid - The earliest timestamp shown for a UID.  Timestamp is displayed as days before stats file's week_start
    # (7.2) latest_timestamp_for_uid - The latest timestamp shown for a UID. Timestamp is displayed as days before stats file's week_start

# Input: [ip,uid,timestamp] & [chv_de_flag,ip,exclusive_ip]
# Output: timestamp with stats as shown above

# ESTIMATED TIME = <12 minutes ([chv, de] + [id5])

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
from datetime import date, timedelta, datetime
from pyspark.sql.types import StructType 
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import BooleanType
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import sys
import os
from pyspark.sql import SparkSession

# Import addresses
scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)
from stats_addresses import * 

# Create Spark session
spark = SparkSession.builder.appName("from_uid_supplier_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration  
time_script_start = time.time()
stats_list = [] # each loop of stats will add a uid supplier's stats to this list. (will be a list of dictionaries)

uid_suppliers_dict['all'] = 'all' # Add 'all' to uid_suppliers_dict to get aggregate stats 
ip_suppliers_dict['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

data_flag_col = 'chv_de_flag'

# Build Blank Dataframe to capture all of the UID suppliers' data
schema = StructType([StructField('ip',StringType(),True),
                StructField('uid',StringType(),True),
                StructField('type_uid',StringType(),True),
                StructField('timestamp',IntegerType(),True),
                StructField('chv_de_flag',StringType(),True),
                StructField('exclusive_ip',StringType(),True)
                ])
from_uid_all = spark.createDataFrame(data=[], schema=schema) 
        # | ip|uid|type_uid|timestamp|chv_de_flag|exclusive_ip|
        # +---+---+--------+---------+-----------+------------+
        # +---+---+--------+---------+-----------+------------+

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import ChV Mk2 180 file and exclusive flags
chv_mk2_180 = spark.read.parquet(S09_stats_in2).select(data_flag_col, 'ip', 'exclusive_ip')  # NB this is the ChV_Mk2_180 made in previous week
        # |chv_de_flag|           ip|exclusive_ip|
        # +-----------+-------------+------------+
        # |        chv| 1.120.135.99|           1|
        # |        chv|1.120.141.152|           1|

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#############
### STATS ###
#############

for uid_supplier in uid_suppliers_dict:
    uid_supplier_acronym = uid_suppliers_dict[uid_supplier]
    # Timestamp
    print(f'Started UID Supplier: {uid_supplier}')
    uid_loop_start_time = time.time()
    # Import UID Supplier's data 
    if uid_supplier == 'all':
        from_uid_all.write.parquet(S09_stats_out5, mode="overwrite")
        from_uid2 = from_uid_all
    else:
        from_uid = spark.read.parquet(S09_stats_in1_dict[uid_supplier])
            # |     ip|           household|                 uid|type_uid| timestamp|
            # +-------+--------------------+--------------------+--------+----------+
            # |1.1.1.1|-2305782380940893455|ID5-997dBCjkRbJvu...|  id5UID|1693758000|
        #
        from_uid = from_uid.select('ip', 'uid', 'type_uid', 'timestamp') # only relevant columns
            # |            ip|                 uid|type_uid| timestamp|
            # +--------------+--------------------+--------+----------+
            # |94.174.107.210|ID5-dbeeTRhT0QC9u...|  id5UID|1699653600|
            # |  2.97.202.245|ID5-c861XgDQ4Ep-q...|  id5UID|1705342800|
        # Add on columns to know which ip supplier provided IP and which IPs are exclusive
        from_uid2 = from_uid.join(chv_mk2_180, 'ip', 'left')
            # |            ip|                 uid|type_uid| timestamp|chv_de_flag|exclusive_ip|
            # +--------------+--------------------+--------+----------+-----------+------------+
            # |90.248.195.171|ID5-83a10bxvVCsFp...|  id5UID|1704933600|         uc|           1|
            # |90.248.195.171|ID5-28fflRGMbsNur...|  id5UID|1704740400|         uc|           1|
        # Add cleaned dataframe to aggregated dataframe (for 'all' loop)
        from_uid_all = from_uid_all.unionByName(from_uid2)
    # Cache DataFrame for faster processing
    from_uid2.cache().count()
    #
    # Loop through IP Suppliers
    for ip_supplier in ip_suppliers_dict:
        ip_supplier_acronym = ip_suppliers_dict[ip_supplier]
        # Timestamp
        print(f'\t[{uid_supplier} | {ip_supplier}]')
        ip_loop_start_time = time.time()
        # Filter the data if looking at only 1 IP Supplier's contribution
        if ip_supplier == 'all':
            from_uid_ip = from_uid2 # use all the uid file
        else:
            from_uid_ip = from_uid2.where(F.col(data_flag_col) == ip_supplier_acronym) # e.g. 'chv_de_flag' == 'de'
        #
        # -------------------------------------------------------------------------------------------------------------------------------------------------------------
        ##################
        ### STAT CALCS ###
        ##################
        # (1.1) date_of_calculation & (1.2) week_start
        stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
        #
        # (2.1) uid_supplier - The abbreviation for the name of the UID Supplier (e.g. Lotame would show as "lot")
        try:
            stats_data['uid_supplier'] = uid_supplier_acronym
        except:
            stats_data['uid_supplier'] = 0
        #
        # (2.2) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
        try:
            stats_data['ip_supplier'] = ip_supplier_acronym
        except:
            stats_data['ip_supplier'] = 0
        #
        # (3.1) count_total_uid - The total number (not unique) of UIDs in the file from specified UID supplier, using all of the IP addresses from specified IP address supplier
        try:
            stats_data['count_total_uid'] = from_uid_ip.count()
        except:
            stats_data['count_total_uid'] = 0
        #
        # (3.2) count_unique_uid - The number of unique UIDs in the file from specified UID supplier, using all of the IP addresses from specified IP address supplier
        try:
            stats_data['count_unique_uid'] = from_uid_ip.groupby('uid').count().count()
        except:
            stats_data['count_unique_uid'] = 0
        #
        # (3.3) count_exclusive_uid - The number of unique UIDs associated with the IPs which were exclusively from the specified IP address supplier
        exclusive_ip_condition = (F.col('exclusive_ip') == 1)
        try:
            stats_data['count_exclusive_uid'] = from_uid_ip.where(exclusive_ip_condition).groupby('uid').count().count()
        except:
            stats_data['count_exclusive_uid'] = 0
        #
        # (4.1) count_ip_with_uid - The number of unique IP addresses from the specified IP address supplier(s), which now have at least 1 associated UID from the specified UID supplier(s)
        try:
            stats_data['count_ip_with_uid'] = from_uid_ip.groupby('ip').count().count()
        except:
            stats_data['count_ip_with_uid'] = 0
        #
        # (4.2) count_exclusive_ip_with_uid - The number of unique IP addresses which are exclusively provided by the specified IP address supplier(s), and now have at least 1 associated UID from the specified UID supplier(s)
        try:
            stats_data['count_exclusive_ip_with_uid'] = from_uid_ip.where(exclusive_ip_condition).groupby('ip').count().count()
        except:
            stats_data['count_exclusive_ip_with_uid'] = 0
        #
        print(f'\t\t4/7')
        # (5) DISTRIBUTION OF [IP, UID_COUNT] - Each unique IP address is displayed next to the number of UIDs associated with that particular IP address
        print(f'\t\tCalculating #5 - [IP, UID_COUNT]')
        count_col = 'uid_count'
        ip_grouped = from_uid_ip.groupby('ip').agg(F.count('uid').alias(count_col))
        if ip_grouped.count()==0:
            ip_grouped = None # i.e. if there are no records from that ip_supplier
            print(f"Exception Occured - No UIDs for {uid_supplier} - {ip_supplier} data")
        if ip_supplier == 'all':
            S09_stats_out2_v2 = S09_stats_out2.replace("<uid_supp>", uid_supplier_acronym)
            ip_grouped.write.mode('overwrite').option("header",True).parquet(S09_stats_out2_v2)
        #
        # (5.1) mean_uid_per_ip - The mean number of UIDs which each IP address has been linked to
        try:
            stats_data['mean_uid_per_ip'] = ip_grouped.select(F.mean(count_col)).collect()[0][0]
        except:
            stats_data['mean_uid_per_ip'] = 0
        #
        # (5.2) stddev_uid_per_ip - The standard deviation around the mean_uid_per_ip
        try:
            stats_data['stddev_uid_per_ip'] = ip_grouped.select(F.stddev(count_col)).collect()[0][0]
        except:
            stats_data['stddev_uid_per_ip'] = 0
        #
        # (5.3) min_uid_per_ip - The lowest number of UIDs which an IP address has been linked to
        try:
            stats_data['min_uid_per_ip'] = ip_grouped.select(F.min(count_col)).collect()[0][0] 
        except:
            stats_data['min_uid_per_ip'] = 0
        #
        # (5.4) max_uid_per_ip - The highest number of UIDs which an IP address has been linked to
        try:
            stats_data['max_uid_per_ip'] = ip_grouped.select(F.max(count_col)).collect()[0][0] 
        except:
            stats_data['max_uid_per_ip'] = 0
        #
        print(f'\t\t5/7')
        # (6) DISTRIBUTION OF [UID, IP_COUNT] - Each unique UID is displayed next to the number of IP addresses associated with that particular UID
        print(f'\t\tCalculating #6 - [UID, IP_COUNT]')
        count_col = 'ip_count'
        uid_grouped = from_uid_ip.groupby('uid').agg(F.count('ip').alias(count_col))
        if uid_grouped.count()==0:
            uid_grouped = None
            print(f"Exception Occured - No IPs for {uid_supplier} - {ip_supplier} data")
        if ip_supplier=='all':
            S09_stats_out3_v2 = S09_stats_out3.replace("<uid_supp>", uid_supplier_acronym)
            uid_grouped.write.mode('overwrite').option("header",True).parquet(S09_stats_out3_v2)
        #
        # (6.1) mean_ip_per_uid - The mean number of IP addresses which each UID has been linked to
        try:
            stats_data['mean_ip_per_uid'] = uid_grouped.select(F.mean(count_col)).collect()[0][0]
        except:
            stats_data['mean_ip_per_uid'] = 0
        #
        # (6.2) stddev_ip_per_uid - The standard deviation around the mean_ip_per_uid
        try:
            stats_data['stddev_ip_per_uid'] = uid_grouped.select(F.stddev(count_col)).collect()[0][0]
        except:
            stats_data['stddev_ip_per_uid'] = 0
        #
        # (6.3) min_ip_per_uid - The lowest number of IP addresses which a UID has been linked to
        try:
            stats_data['min_ip_per_uid'] = uid_grouped.select(F.min(count_col)).collect()[0][0]
        except:
            stats_data['min_ip_per_uid'] = 0
        #
        # (6.4) max_ip_per_uid - The highest number of IP addresses which a UID has been linked to
        try:
            stats_data['max_ip_per_uid'] = uid_grouped.select(F.max(count_col)).collect()[0][0]
        except:
            stats_data['max_ip_per_uid'] = 0
        #
        print(f'\t\t6/7')
        # (7) DISTRIBUTION OF [TIMESTAMP] - Timestamps are shown next to the number of occurences.  Timestamps have been binned into days and rebased with 0 as the date_of_calculation
        print(f'\t\tCalculating #7 - [TIMESTAMP]')
        # Convert from unixtime to string, then from string to datetime
        try:
            from_uid_ip_time = from_uid_ip.withColumn('timestamp', F.from_unixtime(F.col("timestamp"),"yyyy-MM-dd"))
            dates = from_uid_ip_time.select(F.col('timestamp'), F.to_date(F.col('timestamp'), "yyyy-MM-dd").alias("date")).drop('timestamp')
            # |      date|
            # +----------+
            # |2023-09-04|
        except:
            print(f"Exception Occured - No timestamps for {uid_supplier} - {ip_supplier} data")
        #
        if ip_supplier=='all':
            dates_grouped = dates.groupby('date').count().sort(F.col('date').desc())
            S09_stats_out4_v2 = S09_stats_out4.replace("<uid_supp>", uid_supplier_acronym)
            dates_grouped.write.mode('overwrite').option("header",True).parquet(S09_stats_out4_v2)
        #
        # (7.1) earliest_timestamp_for_uid - The earliest timestamp shown for a UID.  Timestamp is displayed as days before stats file's week_start
        try:
            stats_data['earliest_timestamp_for_uid'] = earliest_time_rebased
            earliest_time = dates.select(F.min('date')).collect()[0][0]
            earliest_time_rebased = (week_start - earliest_time).days
        except:
            stats_data['earliest_timestamp_for_uid'] = 0
        #
        # (7.2) latest_timestamp_for_uid - The latest timestamp shown for a UID. Timestamp is displayed as days before stats file's week_start
        try:
            latest_time = dates.select(F.max('date')).collect()[0][0]
            latest_time_rebased = (week_start - latest_time).days     
            stats_data['latest_timestamp_for_uid'] = latest_time_rebased
        except:
            stats_data['latest_timestamp_for_uid'] = 0
        #
        # -------------------------------------------------------------------------------------------------------------------------------------------------------------
        # Append stats_data to stats_list
        stats_list.append(stats_data)
        # Timings
            # ip time split
        ip_split_time = round((time.time() - ip_loop_start_time) / 60, 1) 
        print(f'\t\tCompleted ({ip_split_time} minutes)\n')
            # uid time split
        if ip_supplier == 'all':
            uid_split_time = round((time.time() - uid_loop_start_time) / 60, 1) 
            print(f'\tCompleted ({uid_split_time} minutes)\n\n')
    # Unpersist the Cached UID dataframe
    from_uid2.unpersist()

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

# Export Stats as CSV
stats_psdf.to_csv(S09_stats_out1, emptyValue='')

# timings
script_time = round((time.time() - time_script_start) / 60, 1)
print(f"Stats for script took: {script_time} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - id5
    # |         ip|                 uid| timestamp|
    # +-----------+--------------------+----------+         
    # |94.11.6.176|ID5-997dBCjkRbJvu...|1693758000|
    # |94.11.6.176|ID5-ZHMO00K7iJFng...|1690388400|

    #FULL FILE
    # |         ip|           household|                 uid|type_uid| timestamp|
    # +-----------+--------------------+--------------------+--------+----------+
    # |94.11.6.176|-2305782380940893455|ID5-997dBCjkRbJvu...|  id5UID|1693758000|
    # |94.11.6.176|-2305782380940893455|ID5-ZHMO00K7iJFng...|  id5UID|1690388400|
    # |94.11.6.176|-2305782380940893455|ID5-960beHUsxYgQs...|  id5UID|1692823200|
    # |94.11.6.176|-2305782380940893455|817ea6ae-f33f-4f6...| android|1691162400|

# INPUT 2 - chv_mk2_180
    # |chv_de_flag|         ip|exclusive_ip|
    # +-----------+-----------+------------+
    # |        chv|    1.1.1.1|           1|
    # |        chv|1.107.95.83|           1|

    # FULL FILE
    # |           ip|  cb_key_household|first_seen| last_seen|ip_rank|ip_flag|flag_chv|flag_pubip|chv_de_flag|
    # +-------------+------------------+----------+----------+-------+-------+--------+----------+-----------+
    # |104.28.214.13| 87882052159930368|2023-08-29|2023-09-04|      0|      1|       1|         0|         de|
    # |104.28.214.13| 87882052162027520|2023-08-29|2023-09-04|      1|      1|       1|         0|         de|
    # |104.28.227.37|133281331248365568|2023-08-29|2023-09-04|      0|      1|       1|         0|         de|
    # |104.28.229.36|179178375050428416|2023-08-29|2023-09-04|      2|      1|       1|         0|         de|
    # |104.28.229.36|179178375053574144|2023-08-29|2023-09-04|      1|      1|       1|         0|         de|


# OUTPUT 1 - stats_psdf
    #   date_of_calculation  week_start uid_supplier ip_supplier  count_total_uid  count_unique_uid  count_exclusive_uid  count_ip_with_uid  count_exclusive_ip_with_uid  mean_uid_per_ip  stddev_uid_per_ip  min_uid_per_ip  max_uid_per_ip  mean_ip_per_uid  stddev_ip_per_uid  min_ip_per_uid  max_ip_per_uid  earliest_timestamp_for_uid  latest_timestamp_for_uid
    # 0          2023-09-07  2023-09-04          id5         chv          7213146           7213146              5065552             817002                       587429         8.828798           9.547565               2             298         1.000000           0.000000               1               1                          89                        -1
    # 1          2023-09-07  2023-09-04          id5          de         31485122          31485118             29337524            3306968                      3077395         9.520843          10.142687               2             478         1.000000           0.000356               1               2                          89                        -1
    # 2          2023-09-07  2023-09-04          id5         all         38698268          36550670             34403076            3894397                      3664824         9.936909          11.103409               2             524         1.058757           0.235169               1               2                          89                        -1
    # 3          2023-09-07  2023-09-04          all         chv          7213146           7213146              5065552             817002                       587429         8.828798           9.547565               2             298         1.000000           0.000000               1               1                          89                        -1
    # 4          2023-09-07  2023-09-04          all          de         31485122          31485118             29337524            3306968                      3077395         9.520843          10.142687               2             478         1.000000           0.000356               1               2                          89                        -1
    # 5          2023-09-07  2023-09-04          all         all         38698268          36550670             34403076            3894397                      3664824         9.936909          11.103409               2             524         1.058757           0.235169               1               2                          89                        -1


# OUTPUT 2 - ip_grouped
    # |            ip|uid_count|
    # +--------------+---------+
    # |  104.28.200.3|        1|
    # |104.28.209.240|       17|

# OUTPUT 3 - uid_grouped
    # |                 uid|ip_count|
    # +--------------------+--------+
    # |ID5-f11dRriDE5gHt...|       1|
    # |ID5-ce7bNNsrIPF4t...|       1|

# OUTPUT 4 - dates_grouped
    # |      date|  count|
    # +----------+-------+
    # |2023-09-05| 187859|
    # |2023-09-04|5857970|

# -----------------------------------------------------------------------------------------------------------------------
# TIMINGS OF DATA TRANSFERS

#  	                    Week 1 (2023-08-28)	 	                                Week 2 (2023-09-04)
#  	         M	T	    W	        T	    F  S  S	 	     M       T	W	    T	          F   S  S	
#           +--+--+-----------+------------+--+--+--+  +------------+--+--+--------------+-------+--+--+
# DE	 	|     |to_de 11:00|from_de 5:46|	 	 	 	 	 	 	 	 	 	 
# ChV Mk2	|	 	 	      |made 09:42  |	 	 	 	 	 	 	 	 	 	 
# ID5	 	| 	 	 	 	 	 	                   |to_id5 11:08|	  |from_id5 10:43|	 	 
# Pubmatic	| 	 	 	 	 	 	 	 	 	 	 	 	                             |to_Pubm|	

# -----------------------------------------------------------------------------------------------------------------------
# STATS WHEN ONLY USING ID5UID, NOT MAIDS
    # |date_of_calculation|week_start|uid_supplier|ip_supplier|count_total_uid|count_unique_uid|count_exclusive_uid|count_ip_with_uid|count_exclusive_ip_with_uid|  mean_uid_per_ip|stddev_uid_per_ip|min_uid_per_ip|max_uid_per_ip|   mean_ip_per_uid|  stddev_ip_per_uid|min_ip_per_uid|max_ip_per_uid|earliest_timestamp_for_uid|latest_timestamp_for_uid|
    # +-------------------+----------+------------+-----------+---------------+----------------+-------------------+-----------------+---------------------------+-----------------+-----------------+--------------+--------------+------------------+-------------------+--------------+--------------+--------------------------+------------------------+
    # |         2023-09-08|2023-09-04|         id5|        all|       31939001|        30180467|           28421933|          3894397|                    3664824| 8.20126992702593|8.447587483834564|             1|           516|1.0582672892371083|0.23424818902224956|             1|             2|                        89|                      -1|
    # |         2023-09-08|2023-09-04|         id5|         de|       25951964|        25951964|           24193430|          3306968|                    3077395| 7.84766105991954|7.671876093351896|             1|           467|               1.0|                0.0|             1|             1|                        89|                      -1|
    # |         2023-09-08|2023-09-04|         id5|        chv|        5987037|         5987037|            4228503|           817002|                     587429|7.328056724463343|7.375274768888195|             1|           258|               1.0|                0.0|             1|             1|                        89|                      -1|
    # |         2023-09-08|2023-09-04|         all|        all|       31939001|        30180467|           28421933|          3894397|                    3664824| 8.20126992702593|8.447587483834564|             1|           516|1.0582672892371083|0.23424818902224956|             1|             2|                        89|                      -1|
    # |         2023-09-08|2023-09-04|         all|         de|       25951964|        25951964|           24193430|          3306968|                    3077395| 7.84766105991954|7.671876093351896|             1|           467|               1.0|                0.0|             1|             1|                        89|                      -1|
    # |         2023-09-08|2023-09-04|         all|        chv|        5987037|         5987037|            4228503|           817002|                     587429|7.328056724463343|7.375274768888195|             1|           258|               1.0|                0.0|             1|             1|                        89|                      -1|

