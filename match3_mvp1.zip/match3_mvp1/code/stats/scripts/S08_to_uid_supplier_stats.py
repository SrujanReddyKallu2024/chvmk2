# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2.1) uid_supplier - The abbreviation for the name of the UID Supplier (e.g. Lotame would show as "lot")
    # (2.2) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
    # (3.1) count_ip_timestamp_sent - The number of unique [IP Address, Timestamp] combinations sent to a UID supplier
    # (3.2) count_ip_sent - The number of unique IP addresses sent to a UID supplier, which are supplied by the specified IP supplier   
    # (3.3) count_ip_exclusive_sent - The number of unique IP addresses which have exclusively been supplied from the specified IP supplier 
    # (4.1) earliest_timestamp_for_ip - The earliest timestamp shown for an IP address.  Timestamp is displayed as days before stats file's week_start
    # (4.2) latest_timestamp_for_ip - The latest timestamp shown for an IP address. Timestamp is displayed as days before stats file's week_start
    # (5) DISTRIBUTION OF [TIMESTAMP] - Timestamps are shown next to the number of occurences.  Timestamps have been binned into days and rebased with 0 as the week_start
    # (6.1) count_timestamp_for_ip_last_2w - Number of [IP, Timestamp] combinations which occured within 2 weeks of the data of stat file's week_start
    # (6.2) pct_timestamp_for_ip_last_2w - count_timestamp_for_ip_last_2w as a proportion of count_ip_timestamp_sent, expressed as a value from 0 to 1

# Input: [ip, Timestamp]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: <2 MINUTES

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
from datetime import date, timedelta, datetime
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import sys
import os
from pyspark.sql import SparkSession

# Import addresses
scripts = os.path.dirname(__file__) # match3_mvp1/code/stats/scripts
dir01 = os.path.split(scripts)[0] # match3_mvp1/code/stats/
configs = os.path.join(dir01, 'configs') # match3_mvp1/code/stats/configs
sys.path.append(configs)
from stats_addresses import * 

# Create Spark session
spark = SparkSession.builder.appName("to_uid_supplier_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

###################
### IMPORT DATA ###
###################

chv_mk2_180 = spark.read.parquet(S08_stats_in1).select('ip', 'chv_de_flag').distinct()
    # |          ip|chv_de_flag|
    # +------------+-----------+
    # |11.11.11.111|         de|

to_uid = spark.read.csv(S08_stats_in2, header=True)
    # |        ip| Timestamp|
    # +----------+----------+
    # |2.28.7.216|2023-11-24|

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()
stats_list = [] # each loop of stats will add a uid supplier's stats to this list. (will be a list of dictionaries)

uid_suppliers_dict['all'] = 'all' # Add 'all' to uid_suppliers_dict to get aggregate stats
ip_suppliers_dict['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#############
### CLEAN ###
#############

# Make flag table to show where each ip came from and which ones are exclusive
    # Take only the exclusive ips
chv_mk2_180_unique_ips = chv_mk2_180.groupby('ip').count()
    # |           ip|count|
    # +-------------+-----+
    # | 11.11.11.111|    1|
chv_mk2_180_exclusive_ips = chv_mk2_180_unique_ips.where(F.col('count')==1).drop(F.col('count'))
chv_mk2_180_exclusive_ips = chv_mk2_180_exclusive_ips.withColumn('exclusive_ip',F.lit('1'))
    # |          ip|exclusive_ip|
    # +------------+------------+
    # |11.11.11.111|           1|
chv_mk2_180_with_exclusive_flag = chv_mk2_180.join(chv_mk2_180_exclusive_ips, 'ip', how='left')
    # |          ip|chv_de_flag|exclusive_ip|
    # +------------+-----------+------------+
    # |11.11.11.111|         de|           1|
    

# Join onto to_uid to add ip_supplier and exclusive_ip
to_uid2 = to_uid.join(chv_mk2_180_with_exclusive_flag, 'ip').fillna("0")
    # |          ip| Timestamp|chv_de_flag|exclusive_ip|
    # +------------+----------+-----------+------------+
    # |11.11.11.111|2023-08-31|         de|           1|

# Fix Timestamp column dtype
to_uid3 = to_uid2.withColumn('Timestamp', F.to_date(F.col('Timestamp'), "yyyy-MM-dd"))

# Save, read back in and cache, to speed up script
to_uid3.write.mode('overwrite').parquet(S08_stats_out3)
df = spark.read.parquet(S08_stats_in3)
df.cache().count()

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#############
### STATS ###
#############

for uid_supplier in uid_suppliers_dict:
    uid_supplier_acronym = uid_suppliers_dict[uid_supplier]
    # Timestamp
    print(f'Started UID Supplier: {uid_supplier}')
    uid_loop_start_time = time.time()
    for ip_supplier in ip_suppliers_dict:
        ip_supplier_acronym = ip_suppliers_dict[ip_supplier]
        # Timestamp
        print(f'\t[{uid_supplier} | {ip_supplier}]')
        ip_loop_start_time = time.time()
        # Filter Data
        if ip_supplier != 'all':
            df2 = df.where(F.col('chv_de_flag')==ip_supplier_acronym)
        else:
            df2 = df
        #
        # ---------------------------------------------------------------------------------------------------------------------------------------------------------
        # (1.1) date_of_calculation & (1.2) week_start
        stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
        #
        # (2.1) uid_supplier - The abbreviation for the name of the UID Supplier (e.g. Lotame would show as "lot")
        try:
            stats_data['uid_supplier'] = uid_supplier_acronym # 'id5'
        except:
            stats_data['uid_supplier'] = 0
        #
        # (2.2) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
        try:
            stats_data['ip_supplier'] = ip_supplier_acronym # 'de'
        except:
            stats_data['ip_supplier'] = 0
        #
        # (3.1) count_ip_timestamp_sent - The number of unique [IP Address, Timestamp] combinations sent to a UID supplier      
        try:
            count_ip_timestamp_sent = df2.groupby('ip', 'Timestamp').count().count()
            stats_data['count_ip_timestamp_sent'] = count_ip_timestamp_sent # 10,064,666
        except:
            print(f"\t\tException Occured - Could not calculate count_ip_timestamp_sent for {ip_supplier} data")
            stats_data['count_ip_timestamp_sent'] = 0
        #
        # (3.2) count_ip_sent - The number of unique IP addresses sent to a UID supplier, which are supplied by the specified IP supplier
        try:
            stats_data['count_ip_sent'] = df2.groupby('ip').count().count() # 9,452,924
        except:
            print(f"\t\tException Occured - Could not calculate count_ip_sent for {ip_supplier} data")
            stats_data['count_ip_sent'] = 0
        #
        # (3.3) count_ip_exclusive_sent - The number of unique IP addresses which have exclusively been supplied from the specified IP supplier 
        try:
            df_exclusive_ips = df2.where(F.col('exclusive_ip') == 1)
            stats_data['count_ip_exclusive_sent'] = df_exclusive_ips.groupby('ip').count().count() # 8,877,947
        except:
            print(f"\t\tException Occured - Could not calculate count_ip_exclusive_sent for {ip_supplier} data")
            stats_data['count_ip_exclusive_sent'] = 0
        #
        # (4.1) earliest_timestamp_for_ip - The earliest timestamp shown for an IP address.  Timestamp is displayed as days before stats file's week_start
        try:
            earliest_time = df2.select(F.min('Timestamp')).collect()[0][0]
            earliest_time_rebased = (week_start - earliest_time).days 
            stats_data['earliest_timestamp_for_ip'] = earliest_time_rebased # 94
        except:
            print(f"\t\tException Occured - Could not calculate earliest_timestamp_for_ip for {ip_supplier} data")
            stats_data['earliest_timestamp_for_ip'] = 0
        #
        # (4.2) latest_timestamp_for_ip - The latest timestamp shown for an IP address. Timestamp is displayed as days before stats file's week_start
        try:
            most_recent_time = df2.select(F.max('Timestamp')).collect()[0][0]
            most_recent_time_rebased = (week_start - most_recent_time).days 
            stats_data['latest_timestamp_for_ip'] = most_recent_time_rebased # 6
        except:
            print(f"\t\tException Occured - Could not calculate latest_timestamp_for_ip for {ip_supplier} data")
            stats_data['latest_timestamp_for_ip'] = 0
        #
        print(f'\t\t4/6')
        #
        # (5) DISTRIBUTION OF [Timestamp] - Timestamps are shown next to the number of occurences
        try:
            time_grouped = df2.groupby('Timestamp').count()
            if ip_supplier == 'all':            
                time_grouped_rebased = time_grouped.withColumn('Timestamp_rebased', F.datediff(F.lit(week_start), F.col('Timestamp')))
                time_grouped.write.mode('overwrite').parquet(S08_stats_out2)
        except:
            print(f"\t\tException Occured - Could not calculate time_grouped for {ip_supplier} data")
        #
        print(f'\t\t5/6')
        #
        # (6.1) count_timestamp_for_ip_last_2w - Number of [IP, Timestamp] combinations which occured within 2 weeks of the stat file's week_start
        try:
            last_2_weeks = week_start - timedelta(weeks=2)
            timestamp_for_ip_within_2w = time_grouped.where(F.col('Timestamp')>=last_2_weeks)
            count_timestamp_for_ip_last_2w = timestamp_for_ip_within_2w.groupby('count').sum().collect()[0][0]
            stats_data['count_timestamp_for_ip_last_2w'] = count_timestamp_for_ip_last_2w
        except:
            stats_data['count_timestamp_for_ip_last_2w'] = 0
        #
        # (6.2) pct_timestamp_for_ip_last_2w - count_timestamp_for_ip_last_2w as a proportion of count_ip_timestamp_sent, expressed as a value from 0 to 1
        try:
            stats_data['pct_timestamp_for_ip_last_2w'] = count_timestamp_for_ip_last_2w / count_ip_timestamp_sent
        except:
            stats_data['pct_timestamp_for_ip_last_2w'] = 0
        #
        # ---------------------------------------------------------------------------------------------------------------------------------------------------------
        # Append stats_data to stats_list
        stats_list.append(stats_data)
        # Timings
            # ip time split
        ip_split_time = round((time.time() - ip_loop_start_time) / 60, 1) 
        print(f'\t\tCompleted ({ip_split_time} minutes)\n')
            # uid time split
        if ip_supplier == 'all':
            uid_split_time = round((time.time() - uid_loop_start_time) / 60, 1) 
            print(f'\tCompleted ({uid_split_time} minutes)\n\n')
            
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Unpersist
df2.unpersist()

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

stats_psdf

# Export Stats as CSV
stats_psdf.to_csv(S08_stats_out1, emptyValue='') 

# timings
script_time = round((time.time() - time_script_start) / 60, 1)
print(f"Stats for script took: {script_time} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - chv_mk2_180 
    # |          ip|chv_de_flag|
    # +------------+-----------+
    # |11.11.11.111|         de|

# INPUT 2 - to_uid
    # |          ip| Timestamp|
    # +------------+----------+
    # |11.11.11.111|2023-11-24|

# INPUT 3 - df
    # |          ip| Timestamp|chv_de_flag|exclusive_ip|
    # +------------+----------+-----------+------------+
    # |11.11.11.111|2023-08-31|         de|           1|

# OUTPUT 1 - stats_psdf
    #   date_of_calculation  week_start uid_supplier ip_supplier  count_ip_timestamp_sent  count_ip_sent  count_ip_exclusive_sent  earliest_timestamp_for_ip  latest_timestamp_for_ip  count_timestamp_for_ip_last_2w  pct_timestamp_for_ip_last_2w
    # 0          2023-11-19  2023-11-13          id5         chv                  7535085        7535085                  4884555                         93                        3                           81646                      0.010835
    # 1          2023-11-19  2023-11-13          id5          de                 10331149       10331149                  5944357                          3                        3                        10331149                      1.000000
    # 2          2023-11-19  2023-11-13          id5          uc                  8153490        8153490                  4063559                         23                        3                         3242699                      0.397707
    # 3          2023-11-19  2023-11-13          id5         all                 20126495       20126495                 14892471                         93                        3                          565192                      0.028082
    # 4          2023-11-19  2023-11-13          all         chv                  7535085        7535085                  4884555                         93                        3                           81646                      0.010835
    # 5          2023-11-19  2023-11-13          all          de                 10331149       10331149                  5944357                          3                        3                        10331149                      1.000000
    # 6          2023-11-19  2023-11-13          all          uc                  8153490        8153490                  4063559                         23                        3                         3242699                      0.397707
    # 7          2023-11-19  2023-11-13          all         all                 20126495       20126495                 14892471                         93                        3                          565192                      0.028082

# OUTPUT 2 - time_grouped
    # | Timestamp|  count|
    # +----------+-------+
    # |2023-09-01|9452924|
    # |2023-07-31|     33|

# OUTPUT 3 - to_uid3
    # |          ip| Timestamp|chv_de_flag|exclusive_ip|
    # +------------+----------+-----------+------------+
    # |11.11.11.111|2023-08-31|         de|           1|
