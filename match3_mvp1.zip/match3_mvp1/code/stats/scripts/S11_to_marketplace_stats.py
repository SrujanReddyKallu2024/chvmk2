# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2) marketplace - The abbreviation for the name of the Marketplace(s) (e.g. Pubmatic would show as "pubm")
    # TODO(3.1) count_seg - The number of segments (S Codes) in the specified marketplace(s)
    # (3.2) count_seg_with_uid - The number of segments (S Codes) in the specified marketplace(s) which now have at least 1 associated UID 
    # (4) count_mkt_uid - The number of unique UIDs which are sent to the specified marketplace(s)
    # (5) DISTRIBUTION OF [S_CODE, UID_COUNT] - Each segment (SCode) is displayed next to the number of UIDs associated with that particular segment.
    # (5.1) mean_uid_per_seg - The mean number of UIDs which each segment has been linked to
    # (5.2) stddev_uid_per_seg - The standard deviation around the mean_uid_per_seg.
    # (5.3) min_uid_per_seg - The lowest number of UIDs which a segment has been linked to
    # (5.4) max_uid_per_seg - The highest number of UIDs which a segment has been linked to
    # (6) DISTRIBUTION OF [UID, S_CODE_COUNT] - Each UID is displayed next to the number of segments (S_Code) associated with that particular UID 
    # (6.1) mean_seg_per_uid - The mean number of segments which a UID has been linked to
    # (6.2) min_seg_per_uid - The lowest number of segments which a UID has been linked to
    # (6.3) max_seg_per_uid - The highest number of segments which a UID has been linked to

# Input: [S_Code, uid]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: 9 MIN

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
import ipaddress
from pyspark.sql.types import IntegerType
from datetime import date, timedelta
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import sys
import os
from pyspark.sql import SparkSession
import pandas as pd

# Import addresses
scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)
from stats_addresses import * 

# Create Spark session
spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()

stats_list = [] # each loop of stats will add amarketplace's stats to this list. (will be a list of dictionaries)
marketplaces_dict['all'] = 'all' # Add 'all' to marketplaces_dict to get aggregate stats

scode_col = "S_Code"
uid_col = "uid"

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##################
### STAT CALCS ###
##################

for marketplace in marketplaces_dict:
    loop_start_time = time.time()
    print('\n','~'*30, f'starting stats for {marketplace}')
    # Import Data
    dt_uid = spark.read.parquet(S11_stats_in1_dict[marketplace]).select(scode_col, uid_col)
        # | S_Code|uid|
    if marketplace == 'all':
        mkt_s_codes4 = spark.read.parquet(S11_stats_in2_dict[marketplace]).select(scode_col)
    else:
        try:
            # Import Data from local filepath
            mkt_s_codes = pd.read_csv(S11_stats_in2_dict[marketplace])
            mkt_s_codes2 = ps.from_pandas(mkt_s_codes)
            mkt_s_codes3 = mkt_s_codes2.to_spark()
            mkt_s_codes4= mkt_s_codes3.withColumn(scode_col, F.regexp_replace(scode_col, r'^S[0]*', 'S'))
        except:
            print(f'ERROR - Cannot read in SCODE file for {marketplace}')
            pass
        #
    #-----------------------------------------------------------------------------------------------------------------------------
    # (1.1) date_of_calculation & (1.2) week_start
    stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
    # (2) marketplace - The abbreviation for the name of the Marketplace(s) (e.g. Pubmatic would show as "pubm")
    marketplace_acronym = marketplaces_dict[marketplace]
    try:
        stats_data['marketplace'] = marketplace_acronym
    except:
        stats_data['marketplace'] = 0
    # (3.1) count_seg - The number of segments (S Codes) in the specified marketplace(s)
    try:
        stats_data['count_seg'] = mkt_s_codes4.groupby(scode_col).count().count()
    except:
        stats_data['count_seg'] = 0    
    # (3.2) count_seg_with_uid - The number of segments (S Codes) in the specified marketplace(s) which now have at least 1 associated UID 
    try:
        stats_data['count_seg_with_uid'] = dt_uid.groupby(scode_col).count().count()
    except:
        stats_data['count_seg_with_uid'] = 0    
    #
    # (4) count_mkt_uid - The number of unique UIDs which are sent to the specified marketplace(s)
    try:
        stats_data['count_mkt_uid'] = dt_uid.groupby(uid_col).count().count()
    except:
        stats_data['count_mkt_uid'] = 0    
    #
    # (5) DISTRIBUTION OF [S_CODE, UID_COUNT] - Each segment (SCode) is displayed next to the number of UIDs associated with that particular segment.
    print('\t#5 [S_CODE, UID_COUNT]')
    count_col = 'uid_count'
    scode_uid_count = dt_uid.groupby(scode_col).agg(F.count(uid_col).alias(count_col))
         # | scode | uid_count |
    # add week_start and date_of_calculation
    scode_uid_count2 = scode_uid_count.withColumn('week_start', F.lit(week_start_str))
    scode_uid_count3 = scode_uid_count2.withColumn('date_of_calculation', F.lit(str(today)))
    # SAVE DISTRIBUTION OF [S_CODE, UID_COUNT]
    S11_stats_out2_v2 = S11_stats_out2.replace("<>", marketplace_acronym)
    scode_uid_count3.write.mode('overwrite').option("header",True).parquet(S11_stats_out2_v2)
    # (5.1) mean_uid_per_seg - The mean number of UIDs which each segment has been linked to
    try:
        stats_data['mean_uid_per_seg'] = scode_uid_count.select(F.mean(count_col)).collect()[0][0]
    except:
        stats_data['mean_uid_per_seg'] = 0    
    #
    # (5.2) stddev_uid_per_seg - The standard deviation around the mean_uid_per_seg.
    try:
        stats_data['stddev_uid_per_seg'] = scode_uid_count.select(F.stddev(count_col)).collect()[0][0]
    except:
        stats_data['stddev_uid_per_seg'] = 0    
    #
    # (5.3) min_uid_per_seg - The lowest number of UIDs which a segment has been linked to
    try:
        stats_data['min_uid_per_seg'] = scode_uid_count.select(F.min(count_col)).collect()[0][0]
    except:
        stats_data['min_uid_per_seg'] = 0    
    #
    # (5.4) max_uid_per_seg - The highest number of UIDs which a segment has been linked to
    try:
        stats_data['max_uid_per_seg'] = scode_uid_count.select(F.max(count_col)).collect()[0][0]
    except:
        stats_data['max_uid_per_seg'] = 0    
    #
    # (6) DISTRIBUTION OF [UID, S_CODE_COUNT] - Each UID is displayed next to the number of segments (S_Code) associated with that particular UID 
    print('\t#6 [UID, S_CODE_COUNT]')
    count_col = 'scode_count'
    uid_scode_count = dt_uid.groupby(uid_col).agg(F.count(scode_col).alias(count_col))
        # | uid | scode_count |
    # SAVE DISTRIBUTION OF [UID, S_CODE_COUNT]
    S11_stats_out3_v2 = S11_stats_out3.replace("<>", marketplace_acronym)
    uid_scode_count.write.mode('overwrite').option("header",True).parquet(S11_stats_out3_v2)
    #
    # (6.1) mean_seg_per_uid - The mean number of segments which a UID has been linked to
    try:
        stats_data['mean_seg_per_uid'] = uid_scode_count.select(F.mean(count_col)).collect()[0][0]
    except:
        stats_data['mean_seg_per_uid'] = 0    
    #
    # (6.2) min_seg_per_uid - The lowest number of segments which a UID has been linked to
    try:
        stats_data['min_seg_per_uid'] = uid_scode_count.select(F.min(count_col)).collect()[0][0]
    except:
        stats_data['min_seg_per_uid'] = 0    
    #
    # (6.3) max_seg_per_uid - The highest number of segments which a UID has been linked to
    try:
        stats_data['max_seg_per_uid'] = uid_scode_count.select(F.max(count_col)).collect()[0][0]
    except:
        stats_data['max_seg_per_uid'] = 0    
    #
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------
    # Append stats_data to stats_list
    stats_list.append(stats_data)
    # time split
    split_time = round((time.time() - loop_start_time) / 60, 1) 
    print(f"\t{marketplace} stats took: {split_time} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

# Export Stats as CSV
stats_psdf.to_csv(S11_stats_out1, emptyValue='')

# timings
script_time = round((time.time() - time_script_start) / 60, 1)
print(f"Stats for script took: {script_time} minutes")

stats_psdf
print('######### Finished S11 ###########')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - dt_uid
        # |S_Code|uid                                           |
        # +------+----------------------------------------------+
        # |S877  |ID5-b64e12V_53PAto1RchDYNGIkHJiZcpNl1mSFk5-TMg|
        # |S68   |ID5-b64e12V_53PAto1RchDYNGIkHJiZcpNl1mSFk5-TMg|

# INPUT 2 - mkt_s_codes
        # |S_Code|
        # +------+
        # |    S9|

# OUTPUT 1 - stats_psdf
    #   date_of_calculation  week_start marketplace  count_seg  count_seg_with_uid  count_mkt_uid  mean_uid_per_seg  stddev_uid_per_seg  min_uid_per_seg  max_uid_per_seg  mean_seg_per_uid  min_seg_per_uid  max_seg_per_uid
    # 0          2023-09-06  2023-09-04        pubm          0                 900       31481267      5.046399e+06        5.496518e+06            15521         30180798        144.268622                1              440
    # 1          2023-09-06  2023-09-04         all          0                 910       31481267      5.041573e+06        5.469586e+06            15521         30180798        145.732100                1              445

    #   date_of_calculation  week_start marketplace  count_seg  count_seg_with_uid  count_mkt_uid  mean_uid_per_seg  stddev_uid_per_seg  min_uid_per_seg  max_uid_per_seg  mean_seg_per_uid  min_seg_per_uid  max_seg_per_uid
    # 0          2023-09-11  2023-09-11        pubm          0                 773       27000654      3.844048e+06        4.512540e+06            12739         24944110        110.051011                1              333
    # 1          2023-09-11  2023-09-11         all          0                 943       27000721      4.022623e+06        4.324391e+06            12739         24944110        140.490066                1              475


# OUTPUT 2 - scode_uid_count
        # |S_Code|uid_count|
        # +------+---------+
        # |    S1|      100|
        # |    S2|      200|

# OUTPUT 3 - distrib_of_uid_scode_count
        # |       uid|scode_count|
        # +----------+-----------+
        # |ID5-a1b1c1|         10|
        # |ID5-a2b2c2|         20|