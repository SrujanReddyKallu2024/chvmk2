# Code below gathers the following stats:
    # (2.0) date_of_calculation - The date when the stat script was run
    # (2.1) count_mkt_uid_total -  Count of unique UIDs from UID backlog + this week
    # (2.2) count_mkt_uid_backlogonly - Count of unique UIDs from UID backlog only
    # (2.3) count_mkt_uid_lost -  - Count of unique UIDs from UID backlog that were lost this week
    # (2.4) count_mkt_cbk_total -  Count of unique CBkeys with uids from backlog + this week
    # (2.5) count_mkt_cbk_backlogonly -  Count of unique CBKeys with uids from backlog only 
    # (2.6) count_mkt_ip_total -  Count of unique IPs with uids from backlog + this week
    # (2.7) count_mkt_ip_backlogonly -  Count of unique IPs with uids from backlog only
    # (2.8) mean_uid_per_cbk_total -  Mean of count of unique UIDs per CBKeys from backlog + this week
    # (2.9) mean_uid_per_cbk_backlogonly -  Mean of count of unique UIDs per CBKeys from backlog only
    # (2.10) mean_uid_per_ip_total -  Mean of count of unique UIDs per IPs from backlog + this week
    # (2.11) mean_uid_per_ip_backlogonly -  Mean of count of unique UIDs per IPs from backlog only
    # (3.1) count_latest_uids_for_seg - Count of uids for a segment for this week only
    # (3.2) count_backlog_uids_for_seg - Count of uids for a segment for backlog only
    # (3.3) count_total_uids_for_seg - Count of uids for a segment for backlog + this week
    # (3.4) alltime_mean_total_uid_for_seg - All time mean of count of uids for a segment for backlog + this week

# Input: [S_Code, uid_backlog]
# Output: 2 outputs with stats as shown above

# ESTIMATED TIME: ~2 MIN

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import sys
import os
from pyspark.sql import SparkSession

# Import addresses
scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)
from stats_addresses import * 

# Create Spark session
spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()

stats_list = [] # each loop of stats will add amarketplace's stats to this list. (will be a list of dictionaries)
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##################
### STAT CALCS ###
##################

#Pubmatic Stats

start_time = time.time()
print('\n','~'*30, 'starting stats for pubmatic')

# Import Data
dt_uid_backlog = spark.read.parquet(S11_1_stats_in1)
dt_cbk_backlog = spark.read.parquet(S11_1_stats_in2)
dt_ip_backlog = spark.read.parquet(S11_1_stats_in3)

#-----------------------------------------------------------------------------------------------------------------------------
# (2.0) date_of_calculation & (1.2) week_start
stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
        
# (2.1) count_mkt_uid_total -  Count of unique UIDs from UID backlog + this week
try:
    stats_data['count_mkt_uid_total'] = dt_uid_backlog.where(F.col("week_id").isin([0,1,2])).count()
except:
    stats_data['count_mkt_uid_total'] = 0

# (2.2) count_mkt_uid_backlogonly - Count of unique UIDs from UID backlog only
try:
    stats_data['count_mkt_uid_backlogonly'] = dt_uid_backlog.where(F.col("week_id").isin([1,2])).count()
except:
    stats_data['count_mkt_uid_backlogonly'] = 0

# (2.3) count_mkt_uid_lost -  - Count of unique UIDs from UID backlog that were lost this week
try:
    stats_data['count_mkt_lost_uids'] = dt_uid_backlog.where(F.col("week_id")==3).count()
except:
    stats_data['count_mkt_lost_uids'] = 0

# (2.4) count_mkt_cbk_total -  Count of unique CBkeys with uids from backlog + this week
try:
    stats_data['count_mkt_cbk_total'] = dt_cbk_backlog.where(F.col("week_id").isin([0,1,2])).select("cb_key_household").distinct().count()
except:
    stats_data['count_mkt_cbk_total'] = 0

# (2.5) count_mkt_cbk_backlogonly -  Count of unique CBKeys with uids from backlog only
try:
    stats_data['count_mkt_cbk_backlogonly'] = stats_data['count_mkt_cbk_total'] - dt_cbk_backlog.where(F.col("week_id")==0).select("cb_key_household").distinct().count()
except:
    stats_data['count_mkt_cbk_backlogonly'] = 0

# (2.6) count_mkt_ip_total -  Count of unique IPs with uids from backlog + this week
try:
    stats_data['count_mkt_ip_total'] = dt_ip_backlog.where(F.col("week_id").isin([0,1,2])).select("ip").distinct().count()
except:
    stats_data['count_mkt_ip_total'] = 0

# (2.7) count_mkt_ip_backlogonly -  Count of unique IPs with uids from backlog only
try:
    stats_data['count_mkt_ip_backlogonly'] = stats_data['count_mkt_ip_total'] - dt_ip_backlog.where(F.col("week_id")==0).select("ip").distinct().count() 
except:
    stats_data['count_mkt_ip_backlogonly'] = 0

# (2.8) mean_uid_per_cbk_total -  Mean of count of unique UIDs per CBKeys from backlog + this week
try:
    stats_data['mean_uid_per_cbk_total'] = stats_data['count_mkt_uid_total']/stats_data['count_mkt_cbk_total']
except:
    stats_data['mean_uid_per_cbk_total'] = 0

# (2.9) mean_uid_per_cbk_backlogonly -  Mean of count of unique UIDs per CBKeys from backlog only
try:
    stats_data['mean_uid_per_cbk_backlogonly'] = stats_data['count_mkt_uid_backlogonly']/stats_data['count_mkt_cbk_backlogonly']
except:
    stats_data['mean_uid_per_cbk_backlogonly'] = 0

# (2.10) mean_uid_per_ip_total -  Mean of count of unique UIDs per IPs from backlog + this week
try:
    stats_data['mean_uid_per_ip_total'] = stats_data['count_mkt_uid_total']/stats_data['count_mkt_ip_total']
except:
    stats_data['mean_uid_per_ip_total'] = 0

# (2.11) mean_uid_per_ip_backlogonly -  Mean of count of unique UIDs per IPs from backlog only
try:
    stats_data['mean_uid_per_ip_backlogonly'] = stats_data['count_mkt_uid_backlogonly']/stats_data['count_mkt_ip_backlogonly']
except:
    stats_data['mean_uid_per_ip_backlogonly'] = 0

# -------------------------------------------------------------------------------------------------------------------------------------------------------------
# Append stats_data to stats_list
stats_list.append(stats_data)

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

# Export Stats as CSV
stats_psdf.to_csv(S11_1_stats_out1, emptyValue='')

## UID Backlog stats
# 3.1 count_latest_uids_for_seg - Count of uids for a segment for this week only
# 3.2 count_backlog_uids_for_seg - Count of uids for a segment for backlog only
# 3.3 count_total_uids_for_seg - Count of uids for a segment for backlog + this week
df_uid_backlog_per_seg_count = (
    spark.read.parquet(S11_1_stats_in4)
    .groupBy("S_Code")
    .agg(
        F.count(F.when(F.col("week_id")==0,F.col("uid"))).alias("count_latest_uids_for_seg"),
        F.count(F.when(F.col("week_id").isin([1,2]),F.col("uid"))).alias("count_backlog_uids_for_seg"),
        F.count(F.when(F.col("week_id").isin([0,1,2]),F.col("uid"))).alias("count_total_uids_for_seg")
    )
).cache()

try:
    df_uid_backlog_per_seg_avg_alltime_init = spark.read.csv(S11_1_stats_in5, header=True).select("S_Code","count_total_uids_for_seg")
    df_uid_backlog_per_seg_avg_alltime = df_uid_backlog_per_seg_avg_alltime_init.union(
        df_uid_backlog_per_seg_count.select(df_uid_backlog_per_seg_avg_alltime_init.columns)
    )
except:
    df_uid_backlog_per_seg_avg_alltime = df_uid_backlog_per_seg_count.select("S_Code","count_total_uids_for_seg")

# 3.4 alltime_mean_total_uid_for_seg - All time mean of count of uids for a segment for backlog + this week
df_uid_backlog_per_seg_avg_latest = (
    df_uid_backlog_per_seg_avg_alltime
    .groupBy("S_Code")
    .agg(
        F.avg("count_total_uids_for_seg").alias("alltime_mean_total_uid_for_seg")
    )
)
    
df_uid_split_stats = (
    df_uid_backlog_per_seg_count
    .join(
        df_uid_backlog_per_seg_avg_latest,
        on="S_Code",how="left_outer"
    )
    .withColumn("date_of_calculation", F.lit(str(today)))
    .withColumn("week_start", F.lit(week_start_str))
)
df_uid_split_stats.write.csv(S11_1_stats_out2, header=True, mode="overwrite")
# time split
split_time = round((time.time() - start_time) / 60, 1) 
print(f"\t pubmatic stats took: {split_time} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# timings
script_time = round((time.time() - time_script_start) / 60, 1)
print(f"Stats for script took: {script_time} minutes")

stats_psdf
print('######### Finished S11_1 ###########')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - dt_uid_backlog
    # +--------------------+--------------------+----------+-------+
    # |              USERID|               SEGID|      week|week_id|
    # +--------------------+--------------------+----------+-------+
    # |ID5-00002G8KLPyGo...|S91,S38,S446,S925...|2023-10-02|      0|
    # |ID5-00010sxpHJ6mu...|S494,S515,S769,S7...|2023-10-02|      0|
    # |ID5-0001DnRD7HgGs...|S11,S432,S36,S894...|2023-10-02|      0|

# INPUT 2 - dt_cbk_backlog
    # +-------------------+-------+----------+
    # |   cb_key_household|week_id|      week|
    # +-------------------+-------+----------+
    # | 180323224354029568|      0|2023-10-02|
    # | 132170776201658368|      0|2023-10-02|
    # |  83180581240700928|      0|2023-10-02|

# INPUT 3 - dt_ip_backlog
    # +--------------+-------+----------+
    # |            ip|week_id|      week|
    # +--------------+-------+----------+
    # | 86.159.176.82|      0|2023-10-02|
    # |   5.66.52.192|      0|2023-10-02|
    # |   87.80.5.131|      0|2023-10-02|

# INPUT 4 - df_uid_backlog_per_seg_count
    # +--------------------+----------+-------+------+
    # |                 uid|      week|week_id|S_Code|
    # +--------------------+----------+-------+------+
    # |ID5-0000Oryc7J-Gv...|2023-10-02|      0|  S108|
    # |ID5-0000Oryc7J-Gv...|2023-10-02|      0|  S769|
    # |ID5-0000Oryc7J-Gv...|2023-10-02|      0|  S337|

# INPUT 5 - df_uid_backlog_per_seg_avg_alltime
    # |S_Code|count_latest_uids_for_seg|count_backlog_uids_for_seg|count_total_uids_for_seg|alltime_mean_total_uid_for_seg|date_of_calculation|week_start|
    # +------+-------------------------+--------------------------+------------------------+------------------------------+-------------------+----------+
    # |  S206|                   503656|                    217923|                  721579|                      721579.0|         2023-10-18|2023-10-02|
    # |  S300|                  3390810|                   1460129|                 4850939|                     4850939.0|         2023-10-18|2023-10-02|
    # |  S319|                  3629166|                   1598363|                 5227529|                     5227529.0|         2023-10-18|2023-10-02|

# OUTPUT 1 - stats_psdf
    #    |date_of_calculation|week_start|count_mkt_uid_backlog|count_mkt_lost_uids|count_mkt_cbk_backlog|count_mkt_ip_backlog|count_mkt_uid_total|count_mkt_cbk_total|count_mkt_ip_total|mean_uid_per_ip_backlogonly|mean_uid_per_cbk_backlogonly|mean_uid_per_ip_total|mean_uid_per_cbk_total|
    #    +-------------------+----------+---------------------+-------------------+---------------------+--------------------+-------------------+-------------------+------------------+---------------------------+----------------------------+---------------------+----------------------+
    #    |         2023-10-18|2023-10-02|             19039177|            5264762|             12226397|             4514141|           64219110|           22798293|           9420806|          4.217674414689307|          1.5572189419335885|     6.81673202908541|    2.8168385238315867|
    #    +-------------------+----------+---------------------+-------------------+---------------------+--------------------+-------------------+-------------------+------------------+---------------------------+----------------------------+---------------------+----------------------+

# OUTPUT 2 - df_uid_split_stats
    # |S_Code|count_latest_uids_for_seg|count_backlog_uids_for_seg|count_total_uids_for_seg|alltime_mean_total_uid_for_seg|date_of_calculation|week_start|
    # +------+-------------------------+--------------------------+------------------------+------------------------------+-------------------+----------+
    # |  S206|                   503656|                    217923|                  721579|                      721579.0|         2023-10-18|2023-10-02|
    # |  S300|                  3390810|                   1460129|                 4850939|                     4850939.0|         2023-10-18|2023-10-02|
    # |  S319|                  3629166|                   1598363|                 5227529|                     5227529.0|         2023-10-18|2023-10-02|
    # |   S34|                  5962337|                   2484949|                 8447286|                     8447286.0|         2023-10-18|2023-10-02|
