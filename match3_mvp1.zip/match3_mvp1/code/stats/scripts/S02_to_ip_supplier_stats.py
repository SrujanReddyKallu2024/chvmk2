# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # TODO (2.1) count_udprn - The number of unique UDPRNs in the file sent to IP suppliers
    # (2.2) count_udprn_with_latlon - The number of unique UDPRNs in the file sent to IP suppliers, which have an associated Lat/Lon
    # (3) DISTRIBUTION OF [LAT/LON, UDPRN_COUNT] - The distribution of UDPRN_Count for Lat/Lon combinations.  UDPRN_Counts are found by grouping Lat/Lons and finding how many UDPRNs are associated with that combination
    # (3.1) mean_udprn_per_latlon - The mean number of unique UDPRNs for a Lat/Lon combination
    # (3.2) stddev_udprn_per_latlon - The standard deviation around the mean_udprn_per_latlon
    # (3.3) min_udprn_per_latlon - The minimum number of unique UDPRNs for a Lat/Lon combination
    # (3.4) max_udprn_per_latlon - The maximum number of unique UDPRNs for a Lat/Lon combination
    # (4) count_udprn_with_unique_latlon - The number of unique UDPRNs which have a unique Lat/Lon combination, i.e. UDPRNs which don’t share their Lat/Lon with any other UDPRNs.
    # (5.1) count_udprn_seen_before - The number of this week's unique UDPRNs which have been seen in previous weeks
    # (5.2) count_udprn_not_seen_before - The number of this week's unique UDPRNs which have not been seen in previous weeks

# Input 1: Latest [UDPRN, Lat, Lon]
# Input 2: Historic [UDPRN, Lat, Lon, last_seen, weeks_since_last_seen]
# Output 1: Stats above (excluding DISTRIBUTION)
# Output 2: Stats for DISTRIBUTION above
# Output 3: Updated Historic [UDPRN, Lat, Lon, last_seen, weeks_since_last_seen]

# ESTIMATED TIME: 1 minute

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
from datetime import date, timedelta
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import sys
import os
from pyspark.sql import SparkSession

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)

from stats_addresses import *

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
start_time = time.time()

# -------------------------------------------------------------------------------------------------------------------------------------------------------------
# Import Data
df_this_week = spark.read.csv(S02_stats_in1, header=True)

try:
    df_historic = spark.read.parquet(S02_stats_in2)
except: # make initial df_historic 
    df_temp = spark.read.csv(S02_stats_in1, header=True)
    df_temp2 = df_temp.withColumn('last_seen', F.lit(week_start)) # Add 'last_seen' column
    df_temp3 = df_temp2.withColumn('weeks_since_last_seen', F.ceil(F.datediff(df_temp2.last_seen, F.lit(week_start))/7)) # Add 'weeks_since_last_seen' column
    df_temp3.write.mode("overwrite").parquet(S02_stats_out3) # save initial df_historic
    df_historic = spark.read.parquet(S02_stats_in2)

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# (1.1) date_of_calculation & (1.2) week_start
stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}

# (2.1) count_udprn - The number of unique UDPRNs in the file sent to IP suppliers #TODO drop? as same as 2.2
df_this_week_dedup = df_this_week.distinct()
try:
    stats_data['count_udprn'] = df_this_week_dedup.groupby('UDPRN').count().count()
except:
    stats_data['count_udprn'] = 0

# (2.2) count_udprn_with_latlon - The number of unique UDPRNs in the file sent to IP suppliers, which have an associated Lat/Lon
try:
    stats_data['count_udprn_with_latlon'] = df_this_week_dedup.filter(df_this_week_dedup.Latitude.isNotNull()).groupby('UDPRN').count().count()
except:
    stats_data['count_udprn_with_latlon'] = 0

# (3) DISTRIBUTION OF [LAT/LON, UDPRN_COUNT] - The distribution of UDPRN_Count for Lat/Lon combinations.  UDPRN_Counts are found by grouping Lat/Lons and finding how many UDPRNs are associated with that combination
lat_lon_grouped = df_this_week_dedup.groupby('Latitude', 'Longitude').agg(F.count('*').alias('udprn_count'))  # [Lat/Lon, udprn_count]
distrib_of_udprn_count = lat_lon_grouped.groupby('udprn_count').count().sort(F.col('udprn_count').desc())

# (3.1) mean_udprn_per_latlon - The mean number of unique UDPRNs for a Lat/Lon combination
try:
    stats_data['mean_udprn_per_latlon'] = lat_lon_grouped.select(F.mean('udprn_count')).collect()[0][0]
except:
    stats_data['mean_udprn_per_latlon'] = 0

# (3.2) stddev_udprn_per_latlon - The standard deviation around the mean_udprn_per_latlon
try:
    stats_data['stddev_udprn_per_latlon'] = lat_lon_grouped.select(F.stddev('udprn_count')).collect()[0][0]
except:
    stats_data['stddev_udprn_per_latlon'] = 0

# (3.3) min_udprn_per_latlon - The minimum number of unique UDPRNs for a Lat/Lon combination
try:
    stats_data['min_udprn_per_latlon'] = lat_lon_grouped.select(F.min('udprn_count')).collect()[0][0]
except:
    stats_data['min_udprn_per_latlon'] = 0

# (3.4) max_udprn_per_latlon - The maximum number of unique UDPRNs for a Lat/Lon combination
try:
    stats_data['max_udprn_per_latlon'] = lat_lon_grouped.select(F.max('udprn_count')).collect()[0][0]
except:
    stats_data['max_udprn_per_latlon'] = 0

# (4) count_udprn_with_unique_latlon - The number of unique UDPRNs which have a unique Lat/Lon combination, i.e. UDPRNs which don’t share their Lat/Lon with any other UDPRNs.
try:
    stats_data['count_udprn_with_unique_latlon'] = lat_lon_grouped.where(F.col('udprn_count')==1).count()
except:
    stats_data['count_udprn_with_unique_latlon'] = 0

# (5.1) count_udprn_seen_before - The number of this week's unique UDPRNs which have been seen in previous weeks
count_historic = df_historic.groupby('UDPRN').count().count() # dedup the historic data
df_inner = df_this_week_dedup.join(df_historic, ['UDPRN','Longitude', 'Latitude'])
try:
    stats_data['count_udprn_seen_before'] = df_inner.count()
except:
    stats_data['count_udprn_seen_before'] = 0

# (5.2) count_udprn_not_seen_before - The number of this week's unique UDPRNs which have not been seen in previous weeks
try:
    stats_data['count_udprn_not_seen_before'] = stats_data['count_udprn'] - stats_data['count_udprn_seen_before']
except:
    stats_data['count_udprn_not_seen_before'] = 0

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################################
###  UPDATE HISTORIC LIST PARQUET ###
#####################################

# Add 'last_seen' and 'weeks_since_last_seen' columns to this week's file
df_this_week_dedup2 = df_this_week_dedup.withColumn('last_seen', F.lit(week_start_str))
df_this_week_dedup3 = df_this_week_dedup2.withColumn('weeks_since_last_seen', F.ceil(F.datediff(df_this_week_dedup2.last_seen, F.lit(week_start))/7))

# Union this week's file with those that were not seen this week
join_conditions = (df_historic.UDPRN == df_this_week_dedup3.UDPRN) & (df_historic.Longitude == df_this_week_dedup3.Longitude) & (df_historic.Latitude == df_this_week_dedup3.Latitude)
df_not_seen_this_week = df_historic.join(df_this_week_dedup3, join_conditions, 'leftanti')
df_historic_updated = df_this_week_dedup3.union(df_not_seen_this_week)

# Write to Parquet
df_historic_updated.cache()
df_historic_updated.count()
df_historic_updated.write.mode('overwrite').parquet(S02_stats_out3)

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  EXPORT TO CSV  ###
#######################

# Combine Stats into PySpark.Pandas DataFrame
stats = {week_start: stats_data}
stats_psdf = ps.DataFrame.from_dict(stats, orient = 'index', columns=stats_data.keys())

# Export Stats as CSV
stats_psdf.to_csv(S02_stats_out1, emptyValue='')

# Export udprn_count Distribution Stats as CSV
distrib_of_udprn_count.write.mode('overwrite').option("header",True).csv(S02_stats_out2)

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# script run time
end_time = round(time.time() - start_time, 1)
print(f"Stats for script took: {end_time} seconds")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - df_this_week
    # |   UDPRN|       Lat|       Lon|
    # +--------+----------+----------+
    # |10000022|51.8852228|-2.0963317|
    # |10000074|51.8912118|-2.0834988|

# INPUT 2 - df_historic
    # |   UDPRN|       Lat|       Lon| last_seen|weeks_since_last_seen|
    # +--------+----------+----------+----------+---------------------+
    # |10000022|51.8852228|-2.0963317|2022-12-19|                    0|
    # |10000074|51.8912118|-2.0834988|2022-12-19|                    0|

# OUTPUT 1 - stats_psdf
    #            date_of_calculation  week_start  count_udprn  count_udprn_with_latlon  mean_udprn_per_latlon  stddev_udprn_per_latlon  min_udprn_per_latlon  max_udprn_per_latlon  count_udprn_with_unique_latlon  count_udprn_seen_before  count_udprn_not_seen_before
    # 2023-09-04          2023-09-07  2023-09-04     24738685                 24738685               1.143913                 1.796492                     1                   786                        20745270                 24738685                            0
    # 2023-09-11          2023-09-15  2023-09-11     24738685                 24738685               1.143913                 1.796492                     1                   786                        20745270                 24738685                            0



# OUTPUT 2 - distrib_of_udprn_count
    # |udprn_count|count|
    # +-----------+-----+
    # |       1194|    1|
    # |       1178|    1|

# OUTPUT 3 - df_historic_updated
    # |   UDPRN|       Lat|       Lon| last_seen|weeks_since_last_seen|
    # +--------+----------+----------+----------+---------------------+
    # |10000022|51.8852228|-2.0963317|2023-09-04|                    0|
    # |10000074|51.8912118|-2.0834988|2023-09-04|                    0|

