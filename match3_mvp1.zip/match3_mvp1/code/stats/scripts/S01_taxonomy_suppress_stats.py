# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2.1) count_udprn_before_suppress - The number of unique UDPRNs before any suppression list (e.g. CIP or NMR)
    # (2.2) count_udprn_after_suppress - The number of unique UDPRNs after suppression list (e.g. CIP or NMR)
    # (3.1) count_cbk_before_suppress - The number of unique Clarity Blue (CB) Key Households before any suppression list (e.g. CIP or NMR)
    # (3.2) count_cbk_after_suppress - The number of unique Clarity Blue (CB) Key Households after suppression list (e.g. CIP or NMR)

# Input 1: [UDPRN, cb_key_household, cb_key_db_person, flag_hh, flag_UDPRN] 
# Output 1: Stats above as csv

# ESTIMATED TIME: 0.2 mins

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
from datetime import date, timedelta
import pyspark.sql.functions as F
import pyspark.pandas as ps
import time
import os
import sys
from pyspark.sql import SparkSession

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)

from stats_addresses import * 

# Fix environment warning message for pyspark.pandas
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1"

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Data
df_before_suppress = spark.read.parquet(S01_stats_in1)
df_after_suppress = df_before_suppress.where(df_before_suppress.flag_UDPRN.isNull())

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##############
### STATS ####
##############

# (1.1) date_of_calculation & (1.2) week_start
stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}

# (2.1) count_udprn_before_suppress - The number of unique UDPRNs before any suppression list (e.g. CIP or NMR)
try:
    stats_data['count_udprn_before_suppress'] = df_before_suppress.groupby('UDPRN').count().count()
except:
    stats_data['count_udprn_before_suppress'] = 0

# (2.2) count_udprn_after_suppress - The number of unique UDPRNs after suppression list (e.g. CIP or NMR)
try:
    stats_data['count_udprn_after_suppress'] = df_after_suppress.groupby('UDPRN').count().count()
except:
    stats_data['count_udprn_after_suppress'] = 0

# (3.1) count_cbk_before_suppress - The number of unique Clarity Blue (CB) Key Households before any suppression list (e.g. CIP or NMR)
try:
    stats_data['count_cbk_before_suppress'] = df_before_suppress.groupby('cb_key_household').count().count()
except:
    stats_data['count_cbk_before_suppress'] = 0

# (3.2) count_cbk_after_suppress - The number of unique Clarity Blue (CB) Key Households after suppression list (e.g. CIP or NMR)
try:
    stats_data['count_cbk_after_suppress'] = df_after_suppress.groupby('cb_key_household').count().count()
except:
    stats_data['count_cbk_after_suppress'] = 0

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  EXPORT TO CSV  ###
#######################

# Combine Stats into PySpark.Pandas DataFrame
stats = {week_start: stats_data}
stats_psdf = ps.DataFrame.from_dict(stats, orient = 'index', columns=stats_data.keys())

# Export Stats as CSV
stats_psdf.to_csv(S01_stats_out1, emptyValue='')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# script run time
end_time = round((time.time() - time_script_start)/60, 1)
print(f"Stats for script took: {end_time} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - df_before_suppress
# |   UDPRN|   cb_key_household|cb_key_db_person|flag_hh|flag_UDPRN|
# +--------+-------------------+----------------+-------+----------+
# |10000241|3920606279271186432|      4030247637|   null|      null|
# |10000241|3920606279271186432|      4030247638|   null|      null|

# OUTPUT 1 - stats_psdf
#            date_of_calculation  week_start  count_udprn_before_suppress  count_udprn_after_suppress  count_cbk_before_suppress  count_cbk_after_suppress
# 2022-12-19          2022-12-19  2022-12-19                     26450931                    25445270                   26451654                  25445977
