# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show a "de")
    # (3.1) count_ip - The number of unique IP addresses in the file from specified IP address supplier (includes valid/non-valid and IPv4/IPv6)
    # (3.2) count_valid_ip - The number of unique IP addresses, in the file from specified IP address supplier, which are valid
    # (3.3) count_valid_ip4 - The number of unique IP addresses, in the file from specified IP address supplier, which are valid and in IPv4 format
    # (3.4) count_valid_ip6 - The number of unique IP addresses, in the file from specified IP address supplier, which are valid and in IPv6 format
    #......
    #...... (stat code has been left in for 4 to 7 incase we change mind and do want breakdown of lat/lon and timestamp supplied)
    #......
    # (8) DISTRIBUTION OF [UDPRN, IP_COUNT] - Each unique UDPRN is displayed next to the number of IP addresses associated with that particular UDPRN
    # (8.1) mean_ip_per_udprn - The mean number of IP addresses which each UDPRN has been linked to, using only the IP addresses from chosen IP supplier
    # (8.2) stddev_ip_per_udprn - The standard deviation around the mean_ip_per_udprn
    # (8.3) min_ip_per_udprn - The lowest number of IP addresses which a UDPRN has been linked to, using only the IP addresses from chosen IP supplier
    # (8.4) max_ip_per_udprn - The highest number of IP addresses which a UDPRN has been linked to, using only the IP addresses from chosen IP supplier
    # (9.1) count_udprn_ip - The number of unique UDPRNs which have at least 1 IP (includes valid/non-valid and IPv4/IPv6) address, from specified IP address supplier
    # (9.2) count_udprn_valid_ip - The number of unique UDPRNs which have at least 1 valid IP (IPv4 or IPv6) address, from specified IP address supplier
    # (9.3) count_udprn_valid_ip4 - The number of unique UDPRNs which have at least 1 valid IPv4 address, from specified IP address supplier
    # (9.4) count_udprn_valid_ip6 - The number of unique UDPRNs which have at least 1 valid IPv6 address, from specified IP address supplier

# Input: [ip, udprn] or [ip, cb_key_household]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: 5 MINS

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
import os
import sys
from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import col
from pyspark.sql.functions import count
from pyspark.sql.functions import mean
from pyspark.sql.functions import min
from pyspark.sql.functions import max
import pyspark.pandas as ps

# Import Addresses
scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
funcs = os.path.join(dir01, 'funcs')
sys.path.append(configs)
sys.path.append(funcs)
from stats_addresses import * 
from functions_stats import *

# Create Spark session
spark = SparkSession.builder.appName("from_ip_supplier_stats").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
clock = '🕒'
start_time = datetime.now()

# make uniform names for ip suppliers' files' columns
udprn_lab = 'udprn'
ip_lab = 'ip'
cbk_lab = 'cb_key_household'

stats_list = [] # each loop of stats will add an ip supplier's stats to this list. (will be a list of dictionaries)

ip_suppliers_dict2 = ip_suppliers_dict.copy()
del ip_suppliers_dict2['channel_view'] # dont need ChV ips in this dictionary
ip_suppliers_dict2['all'] = 'all' # Add 'all' to ip_suppliers_dict to get aggregate stats

# Empty dataframe for aggregating IP suppliers' data
schema = StructType([StructField(udprn_lab,StringType(),True),
                     StructField(ip_lab,StringType(),True),
                     StructField('ip_type',IntegerType(),True)])
df_agg = spark.createDataFrame(data=[], schema=schema) 
        # |udprn| ip|ip_type|
        # +-----+---+-------+
        # +-----+---+-------+

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import UDPRN:CBK lookup
udprn_cbk = spark.read.parquet(S03_stats_in2).select(col('UDPRN').alias(udprn_lab), 
                                                    'cb_key_household')\
                                                         .distinct()
        # |   udprn|   cb_key_household|
        # |10000022|3920606161181605888|

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#############
### STATS ###
#############

for ip_supplier in ip_suppliers_dict2:
    loop_start_time = datetime.now()
    ###################
    ### IMPORT DATA ###-----------------------------------------------------------------
    ###################
    print(f'{ip_supplier.title()} - Importing Data')
    if ip_supplier == 'all':
        df = df_agg   # on final loop, for 'all' ip suppliers, this aggregated dataframe will be used
    else:
        try:
            df = spark.read.parquet(S03_stats_in1_dict[ip_supplier])
        except:
            df = None
            print(f'\t\tException Occured - Importing {ip_supplier}')
    #
    ##################
    ### CLEAN DATA ###-----------------------------------------------------------------
    ##################
    print(f'{ip_supplier.title()} - Cleaning Data')
    if ip_supplier == 'unacast':
        try:
            df2 = df.select(cbk_lab,
                            ip_lab)
                    # |cb_key_household|           ip|
                    # |2449958491914240|1.132.106.239|
            df3 = df2.join(udprn_cbk, cbk_lab) # add on udprn from lookup table
                    # |  cb_key_household|          ip|  udprn|
                    # |102039245263208448|90.200.8.180|9119135|
            df4 = df3.select(udprn_lab, ip_lab).distinct() # drop cb_key_household column and dedup
                    # |  udprn|           ip|
                    # +-------+-------------+
                    # |9126046|81.158.62.234|
            df = df4
        except:
            print(f'\t\tException Occured - Cleaning {ip_supplier}')
    #
    # Add "ip_type" column and union to aggregate table (df_agg)
    if ip_supplier != 'all':
        try:
            df = add_ip_type_column(df, ip_col=ip_lab)
                    # |   udprn|            ip|ip_type|
                    # |53719801|188.220.197.36|   ipv4|
            df_agg = df_agg.unionByName(df, allowMissingColumns=True)   # add the ip suppliers dataframe to the aggregate dataframe, if its not the final 'all' run
        except:
            print(f"\t\tException Occured - Can't add ip_type column and move to aggregate table (for {ip_supplier} data)")
    # Cache for faster processing
    try:
        df.cache()
        print(f'\t\t\t{df.count():,} rows')
    except:
        pass
    #
    ##################
    ### STAT CALCS ###
    ##################
    #
    print(f'{ip_supplier.title()} - Calculating Stats')           
    # (1.1) date_of_calculation & (1.2) week_start
    stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
    #
    # (2) ip_supplier - The abbreviation for the name of the IP address supplier (e.g. Digital Element would show a "de")
    stat_name = 'ip_supplier'
    ip_supplier_acronym = ip_suppliers_dict2[ip_supplier]
    try:
        stats_data[stat_name] = ip_supplier_acronym
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (3.1) count_ip - The number of unique IP addresses in the file from specified IP address supplier (includes valid/non-valid and IPv4/IPv6)
    stat_name = 'count_ip'
    try:
        stats_data[stat_name] = df.select(ip_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (3.2) count_valid_ip - The number of unique IP addresses, in the file from specified IP address supplier, which are valid
    stat_name = 'count_valid_ip'
    try:
        df_valid_ip = df.filter(col('ip_type') != "invalid_ip")
        stats_data[stat_name] = df_valid_ip.select(ip_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #    
    # (3.3) count_valid_ip4 - The number of unique IP addresses, in the file from specified IP address supplier, which are valid and in IPv4 format
    stat_name = 'count_valid_ip4'
    try:
        df_valid_ipv4 = df.filter(col('ip_type') == "ipv4")
        stats_data[stat_name] = df_valid_ipv4.select(ip_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (3.4) count_valid_ip6 - The number of unique IP addresses, in the file from specified IP address supplier, which are valid and in IPv6 format
    stat_name = 'count_valid_ip6'
    try:
        df_valid_ipv6 = df.filter(col('ip_type') == "ipv6")
        stats_data[stat_name] = df_valid_ipv6.select(ip_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    print(f'\t\t\t#1 - #3.4 completed')
    #
    # (4) DISTRIBUTION OF [LAT, LON, IP, TIME_COUNT] - Each combination of [Lat, Lon, IP] pairings is displayed next to the number of time stamps [TIME_COUNT] associated with that pairing
    count_col = 'timestamp_count'
    latlon_ip_time_grouped = None
    distrib_df = None
    # TODO delete this hard code and add back in (4) to (5) if want distrib of lat/lon/time
    stats_data['mean_time_per_latlon_ip'] = 0
    stats_data['stddev_time_per_latlon_ip'] = 0
    stats_data['min_time_per_latlon_ip'] = 0
    stats_data['max_time_per_latlon_ip'] = 0
    stats_data['count_ip_latlon_time'] = 0
        # try:
        #     if ip_supplier != 'all':
        #         latlon_ip_time_grouped = df_valid_ip.groupby(ip_lab,lat_lab, lon_lab).agg(count(time_lab).alias(count_col))
        #             # |            ip|       lat|       lon|timestamp_count|
        #             # |  86.128.53.25| 50.115525|-5.5432903|             11|
        #         # SAVE DISTRIBUTION
        #         S03_stats_out2_edit = S03_stats_out2.replace("<>", ip_supplier_acronym)
        #         latlon_ip_time_grouped.write.mode('overwrite').parquet(S03_stats_out2_edit)
        #         distrib_df = spark.read.parquet(S03_stats_out2_edit).describe().select('summary', count_col)
        #     #
        # except:
        #     print(f"\t\tException Occured - Could not calculate DISTRIBUTION OF [LAT, LON, IP, TIME_COUNT] for {ip_supplier} data")
        #     latlon_ip_time_grouped = None
        #     distrib_df = None
        # #
        # # (4.1) mean_time_per_latlon_ip - The mean number of time stamps which each [Lat, Lon, IP] pairing has been linked to
        # stat_name = 'mean_time_per_latlon_ip'
        # try:
        #     stats_data[stat_name] = float(distrib_df.where(col('summary')=='mean').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (4.2) stddev_time_per_latlon_ip - The standard deviation around the mean_time_per_latlon_ip
        # stat_name = 'stddev_time_per_latlon_ip'
        # try:
        #     stats_data[stat_name] = float(distrib_df.where(col('summary')=='stddev').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (4.3) min_time_per_latlon_ip -The lowest number of timestamps which a [Lat, Lon, IP] pairing has been linked to
        # stat_name = 'min_time_per_latlon_ip'
        # try:
        #     stats_data[stat_name] = int(distrib_df.where(col('summary')=='min').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (4.4) max_time_per_latlon_ip - The highest number of timestamps which a [Lat, Lon, IP] pairing has been linked to
        # stat_name = 'max_time_per_latlon_ip'
        # try:
        #     stats_data[stat_name] = int(distrib_df.where(col('summary')=='max').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (5) count_ip_latlon_time - The number of unique [Lat, Lon, IP, timestamp] rows in the file from specified IP address supplier
        # stat_name = 'count_ip_latlon_time'
        # try:
        #     latlon_ip_time = df.select(lat_lab,lon_lab,ip_lab,time_lab).filter(col(time_lab).isNotNull()) # filter out rows in 'all' table with null in 'timestamp' column
        #     stats_data[stat_name] = latlon_ip_time.distinct().count() 
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # print(f'\t{ip_supplier_acronym} stats #4 - #5 completed') 
        # #
    # (6) DISTRIBUTION OF [LAT, LON, IP_COUNT] - Each combination of [Lat, Lon] pairings is displayed next to the number of IP addresses associated with that pairing
    count_col = 'ip_count'
    latlon_ip_grouped = None
    distrib_df = None
    # TODO delete this hard code and add back in (6) to (7) if want distrib of lat/lon
    stats_data['mean_ip_per_latlon'] = 0
    stats_data['stddev_ip_per_latlon'] = 0
    stats_data['min_ip_per_latlon'] = 0
    stats_data['max_ip_per_latlon'] = 0
    stats_data['count_ip_latlon'] = 0    
        # try:
        #     if ip_supplier != 'all':
        #         latlon_ip_grouped = df_valid_ip.groupby(lat_lab, lon_lab).agg(count(ip_lab).alias(count_col))
        #                 # |lat|lon|ip_count|
        #         # SAVE DISTRIBUTION OF [LAT, LON, IP_COUNT]
        #         S03_stats_out3_edit = S03_stats_out3.replace("<>", ip_supplier_acronym)
        #         latlon_ip_grouped.write.mode('overwrite').parquet(S03_stats_out3_edit)
        #         distrib_df = spark.read.parquet(S03_stats_out3_edit).describe().select('summary', count_col)
        #                 # |summary|  ip_count|
        #                 # +-------+----------+
        #                 # |  count|   5932755|
        #                 # |   mean|   113.083|
        #                 # | stddev|18813.2741|
        #                 # |    min|         1|
        #                 # |    max|  30471354|
        #     #
        # except:
        #     print(f"\t\tException Occured - Could not calculate DISTRIBUTION OF [LAT, LON, IP_COUNT] for {ip_supplier} data")
        #     latlon_ip_grouped = None
        #     distrib_df = None
        # # 
        # # (6.1) mean_ip_per_latlon - The mean number of IP addresses which each [Lat, Lon] pairing has been linked to, using only the IP addresses from chosen IP supplier
        # stat_name = 'mean_ip_per_latlon'
        # try:
        #     stats_data[stat_name] = float(distrib_df.where(col('summary')=='mean').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (6.2) stddev_ip_per_latlon - The standard deviation around the mean_ip_per_latlon
        # stat_name = 'stddev_ip_per_latlon'
        # try:
        #     stats_data[stat_name] = float(distrib_df.where(col('summary')=='stddev').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (6.3) min_ip_per_latlon - The lowest number of IP addresses which a [Lat, Lon] pairing has been linked to, using only the IP addresses from chosen IP supplier
        # stat_name = 'min_ip_per_latlon'
        # try:
        #     stats_data[stat_name] = int(distrib_df.where(col('summary')=='min').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (6.4) max_ip_per_latlon - The highest number of IP addresses which a [Lat, Lon] pairing has been linked to, using only the IP addresses from chosen IP supplier
        # stat_name = 'max_ip_per_latlon'
        # try:
        #     stats_data[stat_name] = int(distrib_df.where(col('summary')=='max').collect()[0][1])
        # except:
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data[stat_name] = 0
        # #
        # # (7) count_ip_latlon - The number of unique [device_lat, device_lon, ip_address] rows in the file from specified IP address supplier
        # stat_name = 'count_ip_latlon'
        # try:
        #     ip_latlon = df.select(lat_lab,lon_lab,ip_lab).filter(col(lat_lab).isNotNull()) # filter out rows in 'all' table with null in 'lat' column
        #     stats_data[stat_name] = ip_latlon.distinct().count() 
        # except:
        #     stats_data[stat_name] = 0
        #     print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        #     stats_data['count_ip_latlon_time'] = 0        
        # #
        # print(f'\t{ip_supplier_acronym} stats #6 - #7 completed') 
        # #
    # (8) DISTRIBUTION OF [UDPRN, IP_COUNT] - Each unique UDPRN is displayed next to the number of IP addresses associated with that particular UDPRN
    count_col = 'ip_count'
    udprn_grouped = None
    distrib_df = None
    try:
        udprn_grouped = df_valid_ip.groupby(udprn_lab).agg(count(ip_lab).alias(count_col))
                # |udprn|ip_count|
        # SAVE [UDPRN, IP_COUNT]
        S03_stats_out4_edit = S03_stats_out4.replace("<>", ip_supplier_acronym)
        udprn_grouped.write.mode('overwrite').parquet(S03_stats_out4_edit)
        distrib_df = spark.read.parquet(S03_stats_out4_edit).describe().select('summary', count_col)  
                # |summary| ip_count|
                # |  count|  8519820|
                # |   mean| 78.74527|
                # | stddev|1538.3422|
                # |    min|        1|
                # |    max|   449797|
        #
    except:
        print(f"\t\tException Occured - Could not calculate DISTRIBUTION OF [UDPRN, IP_COUNT] for {ip_supplier} data")        
    #
    # (8.1) mean_ip_per_udprn - The mean number of IP addresses which each UDPRN has been linked to, using only the IP addresses from chosen IP supplier
    stat_name = 'mean_ip_per_udprn'
    try:
        stats_data[stat_name] = float(distrib_df.where(col('summary')=='mean').collect()[0][1])
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (8.2) stddev_ip_per_udprn - The standard deviation around the mean_ip_per_udprn
    stat_name = 'stddev_ip_per_udprn'
    try:
        stats_data[stat_name] = float(distrib_df.where(col('summary')=='stddev').collect()[0][1])
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (8.3) min_ip_per_udprn - The lowest number of IP addresses which a UDPRN has been linked to, using only the IP addresses from chosen IP supplier
    stat_name = 'min_ip_per_udprn'
    try:
        stats_data[stat_name] = int(distrib_df.where(col('summary')=='min').collect()[0][1])
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (8.4) max_ip_per_udprn - The highest number of IP addresses which a UDPRN has been linked to, using only the IP addresses from chosen IP supplier
    stat_name = 'max_ip_per_udprn'
    try:
        stats_data[stat_name] = int(distrib_df.where(col('summary')=='max').collect()[0][1])
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    print(f'\t\t\t#8 - #8.4 completed')
    #
    # (9.1) count_udprn_ip - The number of unique UDPRNs which have at least 1 IP (includes valid/non-valid and IPv4/IPv6) address, from specified IP address supplier
    stat_name = 'count_udprn_ip'
    try:
        stats_data[stat_name] = df.select(udprn_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (9.2) count_udprn_valid_ip - The number of unique UDPRNs which have at least 1 valid IP (IPv4 or IPv6) address, from specified IP address supplier
    stat_name = 'count_udprn_valid_ip'
    try:
        stats_data[stat_name] = df_valid_ip.select(udprn_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (9.3) count_udprn_valid_ip4 - The number of unique UDPRNs which have at least 1 valid IPv4 address, from specified IP address supplier
    stat_name = 'count_udprn_valid_ip4'
    try:
        stats_data[stat_name] = df_valid_ipv4.select(udprn_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # (9.4) count_udprn_valid_ip6 - The number of unique UDPRNs which have at least 1 valid IPv6 address, from specified IP address supplier
    stat_name = 'count_udprn_valid_ip6'
    try:
        stats_data[stat_name] = df_valid_ipv6.select(udprn_lab).distinct().count()
    except:
        print(f"\t\tException Occured - Could not calculate {stat_name} for {ip_supplier} data")
        stats_data[stat_name] = 0
    #
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------# Append stats_data to stats_list
    # time split
    split_time = round((datetime.now() - loop_start_time).seconds / 60, 1)         
    print(f'{clock} {split_time} mins')
    print('\t','-'*50,'\n')   
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------# Append stats_data to stats_list
    # add stats to aggregate stats_list
    stats_list.append(stats_data)
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------# Append stats_data to stats_list
    # Remove df from cache
    try:
        df.unpersist()
    except:
        continue

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

# Export Stats as CSV
stats_psdf.to_csv(S03_stats_out1, emptyValue='')

# timings
script_time = round((datetime.now() - start_time).seconds / 60, 1)
print(f"{clock} S03_from_ip_supplier_stats: {script_time} mins")
       
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - df
    # |   UDPRN|                ip|
    # +--------+------------------+
    # |10000235|      86.175.41.60| 
    # |10000235|    86.140.221.143| 
    # |10000696|2a01:4c8:3f:f593::| 
    
# INPUT 2 - udprn_cbk
    # |   UDPRN|   cb_key_household|
    # +--------+-------------------+
    # |10013203|3920608729050906624|
    # |10031002|3920613923809656832|

# OUTPUT 1 - stats_psdf
    # |date_of_calculation|week_start|ip_supplier|count_ip|count_valid_ip|count_valid_ip4|count_valid_ip6|mean_time_per_latlon_ip|stddev_time_per_latlon_ip|min_time_per_latlon_ip|max_time_per_latlon_ip|count_ip_latlon_time|mean_ip_per_latlon|stddev_ip_per_latlon|min_ip_per_latlon|max_ip_per_latlon|count_ip_latlon| mean_ip_per_udprn|stddev_ip_per_udprn|min_ip_per_udprn|max_ip_per_udprn|count_udprn_ip|count_udprn_valid_ip|count_udprn_valid_ip4|count_udprn_valid_ip6|
    # +-------------------+----------+-----------+--------+--------------+---------------+---------------+-----------------------+-------------------------+----------------------+----------------------+--------------------+------------------+--------------------+-----------------+-----------------+---------------+------------------+-------------------+----------------+----------------+--------------+--------------------+---------------------+---------------------+
    # |         2023-11-17|2023-11-13|        all|14533299|      14533299|       12794339|        1738960|                      0|                        0|                     0|                     0|                   0|                 0|                   0|                0|                0|              0|6.2056803053395715| 127.50031916173792|               1|           37376|      20693289|            20693289|             19708421|              6851855|
    # |         2023-11-17|2023-11-13|         de|11492213|      11492213|        9889063|        1603150|                      0|                        0|                     0|                     0|                   0|                 0|                   0|                0|                0|              0|3.8673798922448457|  6.668964529106487|               1|             178|      20406634|            20406634|             19315193|              6684051|
    # |         2023-11-17|2023-11-13|         uc| 5527442|       5527442|        5385720|         141722|                      0|                        0|                     0|                     0|                   0|                 0|                   0|                0|                0|              0| 7.222001895683701| 220.90241952569698|               1|           37369|       6853464|             6853464|              6734145|               479787|

    # date_of_calculation	    17/11/2023	17/11/2023	17/11/2023
    # week_start	            13/11/2023	13/11/2023	13/11/2023
    # ip_supplier     	        all	        de	        uc
    # count_ip	                14,533,299	11,492,213	5,527,442
    # count_valid_ip	        14,533,299	11,492,213	5,527,442
    # count_valid_ip4	        12,794,339	9,889,063	5,385,720
    # count_valid_ip6	        1,738,960	1,603,150	141,722
    # mean_ip_per_udprn	        6.2	        3.9	        7.2
    # stddev_ip_per_udprn	    127.5	    6.7	        220.9
    # min_ip_per_udprn	        1	        1       	1
    # max_ip_per_udprn	        37,376	    178	        37,369
    # count_udprn_ip	        20,693,289	20,406,634	6,853,464
    # count_udprn_valid_ip	    20,693,289	20,406,634	6,853,464
    # count_udprn_valid_ip4	    19,708,421	19,315,193	6,734,145
    # count_udprn_valid_ip6	    6,851,855	6,684,051	479,787
