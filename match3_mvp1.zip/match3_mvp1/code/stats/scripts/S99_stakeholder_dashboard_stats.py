# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2) marketplace - The abreviation for the name of the Marketplace(s) (e.g. Pubmatic would show as "pubm")
    # (3.1) count_mkt_uid - The number of unique UIDs which are sent to the specified marketplace(s)
    # (3.2) 6m_mean_uid - The mean number of unique UIDs available for MarketPlaces.  Based off data from last 6 months
    # (3.3) alltime_mean_uid - The mean number of unique UIDs available for MarketPlaces. Based off all time data
    # (4.1) latest_uid_for_seg - The latest number of unique UIDs for the given segment
    # (4.2) alltime_mean_uid_for_seg - The mean number of unique UIDs for the given segment.  Based off all time data and at a Household Level

# Input: [marketplace, count_mkt_uid] & [S_Code, uid_count]
# Output: timestamp with stats as shown above

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
from datetime import date, timedelta
import pyspark.sql.functions as F
import ipaddress
from pyspark.sql.types import IntegerType
import pyspark.pandas as ps
import pandas as pd
import time
import os
import sys
from pyspark.sql import SparkSession

# Import addresses
scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)
from stats_addresses import * 

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
start_time = time.time()

stats_list = [] # for loop below will append stats for each marketplace

marketplaces_dict['all'] = 'all' # Add 'all' to marketplaces dictionary so for loop includes it

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Data
df_to_mkt_historic = spark.read.csv(S99_stats_in1, header=True) # read in to_mkt_stats for all historic weeks
df_to_mkt_historic = df_to_mkt_historic.toPandas() # convert pyspark dataframe to pandas
df_to_mkt_historic[['count_mkt_uid']] = df_to_mkt_historic[['count_mkt_uid']].apply(pd.to_numeric)  # convert count_mkt_uid to integer datatype

# Import Distribution Data
# Most recent distribution stats for marketplace
df_by_seg = spark.read.parquet(S99_stats_in2)
# Distribution stats across all dates for marketplace
df_by_seg_all = spark.read.parquet(S99_stats_in3)

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

################
### STATS 1 ####
################

for marketplace in marketplaces_dict:
    print(f'starting stats for {marketplace}')
    time_loop_start = time.time() # to record time for each loop
    #
    # (1.1) date_of_calculation & (1.2) week_start
    stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}
    #
    # (2) marketplace - The abreviation for the name of the Marketplace(s) (e.g. Pubmatic would show as "pubm")
    mkt_acronym = marketplaces_dict[marketplace]
    try:
        stats_data['marketplace'] = mkt_acronym
    except:
        stats_data['marketplace'] = 0
    #
    # (3.1) count_mkt_uid - The number of unique UIDs which are sent to the specified marketplace(s)
    # Filter data 
    condition_mkt = df_to_mkt_historic['marketplace'] == mkt_acronym
    condition_latest = df_to_mkt_historic['week_start'] == week_start_str
    df_to_mkt_latest = df_to_mkt_historic.loc[condition_mkt & condition_latest]
    try:
        stats_data['count_mkt_uid'] = df_to_mkt_latest['count_mkt_uid'].iloc[0]
    except:
        stats_data['count_mkt_uid'] = 0
    #
    # (3.2) 6m_mean_uid - The mean number of unique UIDs available for MarketPlaces.  Based off data from last 6 months
    df_to_1_mkt_historic = df_to_mkt_historic.loc[condition_mkt]
    six_months = 26 #(26 weeks)
    if len(df_to_1_mkt_historic)>=six_months: # if we have at least 6 months worth of data (26 weeks)
        try:
            stats_data['6m_mean_uid'] = df_to_1_mkt_historic.loc[:six_months,'count_mkt_uid'].mean()
        except:
            stats_data['6m_mean_uid'] = 0
    #
    # (3.3) alltime_mean_uid - The mean number of unique UIDs available for MarketPlaces. Based off all time data
    try:
        stats_data['alltime_mean_uid'] = df_to_1_mkt_historic.loc[:,'count_mkt_uid'].mean()
    except:
        stats_data['alltime_mean_uid'] = 0
    #
    # Append stats_data to stats_list
    stats_list.append(stats_data)    

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

################
### STATS 2 ####
################

print('starting stats for uid count per seg')
# (4.1) latest_uid_for_seg - The latest number of unique UIDs for the given segment
df_by_seg = df_by_seg.withColumnRenamed('uid_count', 'latest_uid_for_seg')
            # |   S_Code|latest_uid_for_seg|
            # +---------+------------------+
            # |S00000805|           6662895|
            # |S00000869|           1988539|

# (4.2) alltime_mean_uid_for_seg - The mean number of unique UIDs for the given segment.  Based off all time data and at a Household Level
df_by_seg_mean = df_by_seg_all.groupby('S_Code').agg(F.avg('uid_count').alias('alltime_mean_uid_for_seg'))
            # |   S_Code|alltime_mean_uid_for_seg|
            # +---------+------------------------+
            # |S00000502|             1.1070822E7|
            # |S00000883|               7867431.0|

# Combine latest and alltime_mean uid counts for each S_Code
df_uid_per_seg_count = df_by_seg.join(df_by_seg_mean, 'S_Code')
            # |   S_Code|latest_uid_for_seg|alltime_mean_uid_for_seg|
            # +---------+------------------+------------------------+
            # |S00000587|           7733842|               7733842.0|
            # |S00000415|           2126054|               2126054.0|

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################
# Combine Stats into PySpark.Pandas DataFrame
stats_psdf = ps.DataFrame.from_dict(stats_list)

# Export Stats as CSV
stats_psdf.to_csv(S99_stats_out1, emptyValue='')

# Export UID counts for segments
df_uid_per_seg_count.write.csv(path=S99_stats_out2, header="true", mode="overwrite")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - df_to_mkt_historic (S99_stats_in1)
    #   date_of_calculation  week_start marketplace  count_seg  count_seg_with_uid  count_mkt_uid  mean_uid_per_seg_mc  stddev_uid_per_seg_mc  min_uid_per_seg_mc  max_uid_per_seg_mc
    # 0          2022-12-19  2022-12-19        pubm        897                 897       11524648         3.430535e+06           3.041126e+06                   9            11501003
    # 1          2022-12-19  2022-12-19         all        917                 917       11524648         3.465556e+06           3.022970e+06                   9            11501003

# INPUT 2 - df_by_seg (S99_stats_in2)
    # |S_Code|latest_uid_for_seg|week_start|date_of_calculation|
    # +------+------------------+----------+-------------------+
    # |  S295|            919358|2023-09-04|         2023-09-08|
    # |  S939|           1717248|2023-09-04|         2023-09-08|

# INPUT 2 - df_by_seg_all (S99_stats_in3)
    # |S_Code|uid_count|week_start|date_of_calculation|
    # +------+---------+----------+-------------------+
    # |  S295|   919358|2023-09-04|         2023-09-08|
    # |  S939|  1717248|2023-09-04|         2023-09-08|

# OUTPUT 1 - stats_psdf (S99_stats_out1)
    #    date_of_calculation  week_start marketplace count_mkt_uid  alltime_mean_uid
    # 0          2023-09-08  2023-09-04        pubm      31481267        31481267.0
    # 1          2023-09-08  2023-09-04         all      31481267        31481267.0

# OUTPUT 2 - df_uid_per_seg_count (S99_stats_out2)
    # |S_Code|latest_uid_for_seg|week_start|date_of_calculation|alltime_mean_uid_for_seg|
    # +------+------------------+----------+-------------------+------------------------+
    # |   S87|           5229315|2023-09-11|         2023-09-11|               5964101.5|
    # |  S764|          10127129|2023-09-11|         2023-09-11|            1.15547895E7|

