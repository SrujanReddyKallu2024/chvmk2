# Code below gathers the following stats:
    # (1.1) date_of_calculation - The date when the stat script was run
    # (1.2) week_start - The date of Monday, for the week when the stat script was run
    # (2.1) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
    # (3.1) count_total_ip_chv_mk2 - The total number (not unique) of IP Addresses that are in this week's Channel View Mark 2 (ChV Mk2) file
    # (3.2) count_unique_ip_chv_mk2 - The number of unique IP Addresses that are in this week's Channel View Mark 2 (ChV Mk2) file
    # (4.1) count_total_cbk_chv_mk2 - The total number (not unique) of CB Key Households that are in this week's Channel View Mark 2 (ChV Mk2) file
    # (4.2) count_unique_cbk_chv_mk2 - The number of unique  CB Key Households that are in this week's Channel View Mark 2 (ChV Mk2) file
    # (5.1) count_fresh_ip_chv_mk2 - The number of unique IP Addresses that have been updated this week, for this week's Channel View Mark 2 (ChV Mk2) file
    # (5.2) count_fresh_cbk_chv_mk2 - The number of unique CB Key Households that have been updated this week, for this week's Channel View Mark 2 (ChV Mk2) file
    # (6.1) count_new_cbk_chv_mk2 - The number of unique CB Key Households that were not in the monthly Channel View records but have now been added to make Channel View Mark 2 (ChV Mk2) file
    # (7.1) pct_cv_cbk_in_chv - The percentage of unique Consumer View (Taxonomy) CB Key Households, which appear in this week's Channel View Mark 2 (ChV Mk2) file
    # (8.1) count_ip_from_chv_buff_only - The number of unique IP Address in Channel View Mark 2 (ChV Mk2) file, which were only supplied by the Channel View buffer list
    # (8.2) count_cbk_from_chv_buff_only - The number of unique CB Key Household in Channel View Mark 2 (ChV Mk2) file, which were only supplied by the Channel View buffer list

# Input: [chv_mk2]
# Output: timestamp with stats as shown above

# ESTIMATED TIME: <1 MINUTE

# TODO need to add in loop for ip_supplier to go through [all, de, uc, chv]

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Libraries
from datetime import date, timedelta
import pyspark.sql.functions as F
from pyspark.sql.functions import count
from pyspark.sql.types import IntegerType
import pyspark.pandas as ps
import time
import os
import sys
from pyspark.sql import SparkSession

scripts = os.path.dirname(__file__)
dir01 = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
sys.path.append(configs)

from stats_addresses import *  

# Fix environment warning message for pyspark.pandas
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1"

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Configuration
time_script_start = time.time()
stats_list = [] # for loop below will append stats for each ip supplier
data_flag_col = 'chv_de_flag'

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# Import Data
chv_mk2 = spark.read.parquet(S07_stats_in1).select('ip', 'cb_key_household', data_flag_col)
tax = spark.read.parquet(S07_stats_in2).select( 'cb_key_household')
chv = spark.read.csv(S07_stats_in3, header=True).select('ip_address', 'cb_key_household')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

##############
### STATS ####
##############

time_stats_start = time.time() # to record time for each loop

print(f"Pre Stats: {round(abs(time_stats_start - time_script_start),1)} secs")
    
# (1.1) date_of_calculation & (1.2) week_start
stats_data = {'date_of_calculation': str(today), 'week_start': week_start_str}

# (2.1) ip_supplier - The abbreviation for the name of the IP address supplier(s) (e.g. Digital Element would show a "de")
try:
    stats_data['ip_supplier'] = 'all'
except:
    stats_data['ip_supplier'] = 0
    
# (3.1) count_total_ip_chv_mk2 - The total number (not unique) of IP Addresses that are in this week's Channel View Mark 2 (ChV Mk2) file
try:
    stats_data['count_total_ip_chv_mk2'] = chv_mk2.count()
except:
    stats_data['count_total_ip_chv_mk2'] = 0

# (3.2) count_unique_ip_chv_mk2 - The number of unique IP Addresses that are in this week's Channel View Mark 2 (ChV Mk2) file
try:
    stats_data['count_unique_ip_chv_mk2'] = chv_mk2.groupby('ip').count().count()
except:
    print(f"\t\tException Occured - Could not calculate count_unique_ip_chv_mk2 for {ip_supplier} data")
    stats_data['count_unique_ip_chv_mk2'] = 0

# (4.1) count_total_cbk_chv_mk2 - The total number (not unique) of CB Key Households that are in this week's Channel View Mark 2 (ChV Mk2) file
try:
    stats_data['count_total_cbk_chv_mk2'] = chv_mk2.count()
except:
    print(f"\t\tException Occured - Could not calculate count_total_cbk_chv_mk2 for {ip_supplier} data")
    stats_data['count_total_cbk_chv_mk2'] = 0

# (4.2) count_unique_cbk_chv_mk2 - The number of unique  CB Key Households that are in this week's Channel View Mark 2 (ChV Mk2) file
try:
    stats_data['count_unique_cbk_chv_mk2'] = chv_mk2.groupby('cb_key_household').count().count()
except:
    print(f"\t\tException Occured - Could not calculate count_unique_cbk_chv_mk2 for {ip_supplier} data")
    stats_data['count_unique_cbk_chv_mk2'] = 0

# (5.1) count_fresh_ip_chv_mk2 - The number of unique IP Addresses that have been updated this week, for this week's Channel View Mark 2 (ChV Mk2) file
try:
    new_records = chv_mk2.where(F.col(data_flag_col) != 'chv')
    stats_data['count_fresh_ip_chv_mk2'] = new_records.groupby('ip').count().count()
except:
    print(f"\t\tException Occured - Could not calculate count_fresh_ip_chv_mk2 for {ip_supplier} data")
    stats_data['count_fresh_ip_chv_mk2'] = 0

# (5.2) count_fresh_cbk_chv_mk2 - The number of unique CB Key Households that have been updated this week, for this week's Channel View Mark 2 (ChV Mk2) file
try:
    stats_data['count_fresh_cbk_chv_mk2'] = new_records.groupby('cb_key_household').count().count()
except:
    print(f"\t\tException Occured - Could not calculate count_fresh_cbk_chv_mk2 for {ip_supplier} data")
    stats_data['count_fresh_cbk_chv_mk2'] = 0

# (6.1) count_new_cbk_chv_mk2 - The number of unique CB Key Households that were not in the monthly Channel View records but have now been added to make Channel View Mark 2 (ChV Mk2) file
try:
    latest_chv_cbks = chv.groupby('cb_key_household').count().drop(F.col('count')) # cb_key_households in latest ChV
    chv_mk2_cbks = chv_mk2.groupby('cb_key_household').count().drop(F.col('count')) # cb_key_households in ChV_Mk2
    newly_added_cbks = chv_mk2_cbks.join(latest_chv_cbks, 'cb_key_household', 'left_anti')# cb_key_households in ChV_Mk2 but not latest ChV
    stats_data['count_new_cbk_chv_mk2'] = newly_added_cbks.groupby('cb_key_household').count().count()
except:
    print(f"\t\tException Occured - Could not calculate count_new_cbk_chv_mk2 for {ip_supplier} data")
    stats_data['count_new_cbk_chv_mk2'] = 0

# (7.1) pct_cv_cbk_in_chv - The percentage of unique Consumer View (Taxonomy) CB Key Households, which appear in this week's Channel View Mark 2 (ChV Mk2) file
try:
    chv_cbk_count = chv_mk2.groupby('cb_key_household').count().count()
    cv_cbk_count = tax.groupby('cb_key_household').count().count()
    stats_data['pct_cv_cbk_in_chv'] = chv_cbk_count / cv_cbk_count
except:
    print(f"\t\tException Occured - Could not calculate pct_cv_cbk_in_chv for {ip_supplier} data")
    stats_data['pct_cv_cbk_in_chv'] = 0

# (8.1) count_ip_from_chv_buff_only - The number of unique IP Address in Channel View Mark 2 (ChV Mk2) file, which were only supplied by the Channel View buffer list
try:
    unique_ips_before_buffer = chv_mk2.where(F.col(data_flag_col)!='chv').groupby('ip').count().drop(F.col('count')) # IP Supplier's approved IPs 9,386,355
    buffer_ips               = chv_mk2.where(F.col(data_flag_col)=='chv').groupby('ip').count().drop(F.col('count')) # IPs from Buffer 2,148,126
    total_ips_after_buffer   = unique_ips_before_buffer.union(buffer_ips) # IPs from IP Suppliers and Buffer, not deduped 11,534,481
    unique_ips_after_buffer  = total_ips_after_buffer.groupby('ip').count().drop(F.col('count')) # IPs from IP Suppliers and Buffer, deduped 11,051,022
    ips_added_only_by_buffer = unique_ips_after_buffer.count() - unique_ips_before_buffer.count()
    stats_data['count_ip_from_chv_buff_only'] = ips_added_only_by_buffer
except:
    print(f"\t\tException Occured - Could not calculate count_ip_from_chv_buff_only for {ip_supplier} data")
    stats_data['count_ip_from_chv_buff_only'] = 0

# (8.2) count_cbk_from_chv_buff_only - The number of unique CB Key Household in Channel View Mark 2 (ChV Mk2) file, which were only supplied by the Channel View buffer list
try:
    unique_cbks_before_buffer = chv_mk2.where(F.col(data_flag_col)!='chv').groupby('cb_key_household').count().drop(F.col('count')) # IP Supplier's approved CB Key Households 
    buffer_cbks               = chv_mk2.where(F.col(data_flag_col)=='chv').groupby('cb_key_household').count().drop(F.col('count')) # CBKs from Buffer
    total_cbks_after_buffer   = unique_cbks_before_buffer.union(buffer_cbks) # CBKs from IP Suppliers and Buffer, not deduped
    unique_cbks_after_buffer  = total_cbks_after_buffer.groupby('cb_key_household').count().drop(F.col('count')) # CBKs from IP Suppliers and Buffer, deduped
    cbks_added_only_by_buffer = unique_cbks_after_buffer.count() - unique_cbks_before_buffer.count() # 653476
    stats_data['count_cbk_from_chv_buff_only'] = cbks_added_only_by_buffer
except:
    print(f"\t\tException Occured - Could not calculate count_cbk_from_chv_buff_only for {ip_supplier} data")
    stats_data['count_cbk_from_chv_buff_only'] = 0

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#####################
###  SAVE AS CSV  ###
#####################

# Combine Stats into PySpark.Pandas DataFrame
stats = {week_start: stats_data}
stats_psdf = ps.DataFrame.from_dict(stats, orient = 'index', columns=stats_data.keys())

# Export Stats as CSV
stats_psdf.to_csv(S07_stats_out1, emptyValue='')

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# script run times
script_duration = round((time.time() - time_script_start)/60, 1)
print(f"Stats for whole script:\t{script_duration} minutes")

# -------------------------------------------------------------------------------------------------------------------------------------------------------------

#######################
###  DATA PREVIEWS  ###
#######################

# INPUT 1 - chv_mk2.parquet
    # |           ip|  cb_key_household|chv_de_flag|
    # +-------------+------------------+-----------+
    # |104.28.214.13| 87882052159930368|         de|
    # |104.28.214.13| 87882052162027520|         de|

# INPUT 2 - taxonomy_suppress.parquet
    # +-------------------+
    # |   cb_key_household|
    # +-------------------+
    # |3920606161181605888|

# INPUT 3 - ChV
    # |   ip_address|  cb_key_household|
    # +-------------+------------------+
    # |164.40.215.68| 73092558836727808|
    # |82.132.234.73|113455384275976192|

# OUTPUT - stats_psdf - chv_mk2_stats__{week_start}.csv
    #            date_of_calculation  week_start  count_total_ip_chv_mk2  count_unique_ip_chv_mk2  count_total_cbk_chv_mk2  count_unique_cbk_chv_mk2  count_fresh_ip_chv_mk2  count_fresh_cbk_chv_mk2  count_new_cbk_chv_mk2  pct_cv_cbk_in_chv  count_ip_from_chv_buff_only  count_cbk_from_chv_buff_only
    # 2023-09-04          2023-09-06  2023-09-04                34879310                 11051022                 34879310                  14463415                 9386355                 13809939                1507652           0.540547                      1664667                        653476

    #            date_of_calculation  week_start  count_total_ip_chv_mk2  count_unique_ip_chv_mk2  count_total_cbk_chv_mk2  count_unique_cbk_chv_mk2  count_fresh_ip_chv_mk2  count_fresh_cbk_chv_mk2  count_new_cbk_chv_mk2  pct_cv_cbk_in_chv  count_ip_from_chv_buff_only  count_cbk_from_chv_buff_only
    # 2023-09-04          2023-09-08  2023-09-04                34879310                 11051022                 34879310                  14463415                 9386355                 13809939                1742699           0.540547                      1664667                        653476

    #            date_of_calculation  week_start  count_total_ip_chv_mk2  count_unique_ip_chv_mk2  count_total_cbk_chv_mk2  count_unique_cbk_chv_mk2  count_fresh_ip_chv_mk2  count_fresh_cbk_chv_mk2  count_new_cbk_chv_mk2  pct_cv_cbk_in_chv  count_ip_from_chv_buff_only  count_cbk_from_chv_buff_only
    # 2023-09-11          2023-09-11  2023-09-11                38625861                 13255431                 38625861                  15466205                 9415168                 13786686                1706276           0.577707                      3840263                       1679519
