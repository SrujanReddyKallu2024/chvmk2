Stats still to check:
# S04_check_vs_chv_stats.py
# S05_check_vs_pub_stats.py (including ip_suppress_stats.py)
# S06_ip_supplier_deletion_stats.py
# S07_chv_mk2_stats.py
# S08_to_uid_supplier_stats.py
# S09_from_uid_supplier_stats.py
# S10_combiner_stats.py
# S11_to_marketplace_stats.py
# S99_stakeholder_dashboard_stats.py
