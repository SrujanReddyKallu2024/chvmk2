from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import argparse
import sys
from pathlib import Path
import logging
from datetime import datetime, timedelta
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[1]))

from funcs import process_functions as func
from configs import process_adresses as conf, config_process as pconf


def logic_main(ctx, logger, mask, de_in_path, cip_in_path, de_keep_path, de_del_path, quick_stats_path, email_to):
    logger.info("running split de to delete and keep process")
    start_time = datetime.now()
    quick_stats=[]
    try:
        ## Read data
        try:
            de_df = ctx.read.parquet(de_in_path)
            de_count = de_df.count()
            logger.info(f"read de data from {de_in_path} with {de_count} records")

            cip_df = ctx.read.parquet(cip_in_path)
            cip_count = cip_df.count()
            logger.info(f"read cip optouts from {cip_in_path} with {cip_count} records")

            func.update_stats(quick_stats, "Load Inputs", f"read de data from {de_in_path} with {de_count:,} records and cip ip data from {cip_in_path} with {cip_count:,} records")
        except Exception as e:
            func.update_stats(quick_stats, "Load Inputs", f"unable to read in data: {e}")
            raise

        ## Process data
        try:            
            cip_df_fmt = (
                cip_df
                .select('host')
                .distinct()
                .withColumnRenamed('host', 'ip')
                .withColumn('flag_cip', F.lit('1'))
            )
            logger.info(f"formatted cip ip data to get unique ips, count: {cip_df_fmt.count()}")

            de_with_optouts = (
                de_df
                .join(cip_df_fmt, on='ip', how='left')
                .withColumn('flag_cip', F.when(F.col('flag_cip').isNull(), '0').otherwise('1'))
            )
            logger.info(f"joined de data with cip optouts to add optout flag")
                            
            de_del = (
                de_with_optouts
                .where(
                    (F.col('flag_chv') + F.col('flag_pubip') + F.col('flag_audip')== 0) | 
                    (F.col('flag_cip')== '1')
                )
            )
            logger.info(f"filtered de data to get records to delete, count: {de_del.count()}")

            de_keep = (
                de_with_optouts
                .where(
                    (F.col('flag_chv') + F.col('flag_pubip') + F.col('flag_audip')> 0) & 
                    (F.col('flag_cip')== '0')
                )
            )
            logger.info(f"filtered de data to get records to keep, count: {de_keep.count()}")

            func.update_stats(
                quick_stats, 
                "Process Data", 
                f"""
                joined de data with cip optouts to filter out records to delete and keep,
                keep count: {de_keep.count():,},
                delete count: {de_del.count():,},
                hhk to delete: {de_del.select('cb_key_household').distinct().count():,},
                ip to delete: {de_del.select('ip').distinct().count():,},
                hhk to keep: {de_keep.select('cb_key_household').distinct().count():,},
                ip to keep: {de_keep.select('ip').distinct().count():,}
                """
            )
        except Exception as e:
            func.update_stats(quick_stats, "Process Data", f"unable to process data: {e}")
            raise

        ## Write out data
        try:
            de_del.write.parquet(de_del_path, mode="overwrite")            
            de_keep.write.parquet(de_keep_path, mode="overwrite")            
            logger.info(f"wrote de keep data to {de_keep_path} and de delete data to {de_del_path}")
            func.update_stats(quick_stats, "Write Outputs", f"wrote de keep data to {de_keep_path} and de delete data to {de_del_path}")
        except Exception as e:
            func.update_stats(quick_stats, "Write Outputs", f"unable to write out data: {e}")
            raise

        success_flag = True
    except Exception as e:
        logger.error(f"error occurred: {e}")
        success_flag = False        
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        latest_alerts_df = func.compare_stats(logger, mask, quick_stats_path, alerts_df)
        latest_qstats_path = quick_stats_path.format(wsd=mask)
        latest_alerts_df.to_csv(latest_qstats_path, index=False)
        logger.info(f"wrote latest stats to {latest_qstats_path}")
        
        email_sub = f"***P035_4_Split - DE data split - {pconf.STATUS_EMOJIS['green']}***" if success_flag else f"***P035_4 - DE data split - {pconf.STATUS_EMOJIS['red']}***"
        func.send_teams_email(mask, email_sub, latest_alerts_df.to_html(index=False), email_to)
        end_time = datetime.now()
        duration = str(end_time-start_time).split('.')[0]
        logger.info(f"finished DE data split for {mask} in {duration}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("-m", "--mask", "week start date for which process runs in YYYY-MM-DD", default=conf.bweek)
    parser.add_argument("-dip", "--de_in_path", help="input path for de data", default=conf.P035_4_de_in1)
    parser.add_argument("-cip", "--cip_in_path", help="input path for cip optout data", default=conf.P035_4_ci_in2)
    parser.add_argument("-ddp", "--de_del_path", help="output path for de data to delete", default=conf.P035_4_de_out1)
    parser.add_argument("-dkp", "--de_keep_path", help="output path for de data to keep", default=conf.P035_4_de_out2)    
    parser.add_argument("-qsp", "--quick_stats_path", "path to the store quick stats data to compare", default=conf.P035_3_2_out3)
    parser.add_argument("-et", "--email_to", "path to the store quick stats data to compare", default=conf.EMAIL_TO)

    args = parser.parse_args()

    name = Path(__file__).stem
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    logger = pconf.LogConfig("{path}/log-{name}-{mask}.log".format(path=conf.LOG_DIR, name=name, mask=args.mask)).generate_logger(name)

    # process is triggered here
    logic_main(spark, logger, args.mask, args.de_in_path, args.cip_in_path, args.de_del_path, args.de_keep_path, args.quick_stats_path, args.email_to)

