
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession

import json
import math

from pyspark.ml.feature import Bucketizer
import numpy as np

from pyspark.sql.window import Window

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 


spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")


# Settings ------------------------------------------------------------------------------
script_code= 'P025' # For 'Quick Stats'
email_subject= '*** P025: INGEST AND PROCESS UNACAST ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['un_in1']  = P025_un_in1
address_dict['u_in2']   = P025_u_in2
address_dict['cv_in3']  = P025_cv_in3
address_dict['pub_in4'] = P025_pub_in4
address_dict['cp_in5']  = P025_cp_in5
address_dict['tax_in6'] = P025_tax_in6

#Output
address_dict['un_out1'] = P024_un_out1 #f'/user/unity/match2/unacast/{bweek}/process/unacast.parquet'
address_dict['un_out2'] = P025_un_out2 #f'/user/unity/match2/unacast/{bweek}/process/una06_8.parquet'
address_dict['un_out3'] = P025_un_out3 #f'/user/unity/match2/unacast/{bweek}/process/uc_lat_lon.parquet'
address_dict['un_out3_2']=P025_un_out3_2 #f'/user/unity/match2/unacast/{bweek}/process/udprn_lat_lon.parquet'
address_dict['un_out4'] = P025_un_out4 #f'/user/unity/match2/unacast/{bweek}/process/y01.parquet'
address_dict['un_out5'] = P025_un_out5 #f'/user/unity/match2/unacast/{bweek}/process/y02.parquet'
address_dict['un_out6'] = P025_un_out6 #f'/user/unity/match2/unacast/{bweek}/process/m1.parquet'
address_dict['un_out6_2']=P025_un_out6_2 #f'/user/unity/match2/unacast/{bweek}/process/m1_05.parquet'
address_dict['un_out7'] = P025_un_out7 #f'/user/unity/match2/unacast/{bweek}/process/unacast_hh_ip.parquet'
address_dict['un_out8'] = P025_un_out8 #f'/user/unity/match2/unacast/{bweek}/process/unacast_hh_ip_flags.parquet'


# Output test
# address_dict['un_out2'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/una06_8.parquet'
# address_dict['un_out3'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/uc_lat_lon.parquet'
# address_dict['un_out3_2']= f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/udprn_lat_lon.parquet'
# address_dict['un_out4'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/y01.parquet'
# address_dict['un_out5'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/y02.parquet'
# address_dict['un_out6'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/m1.parquet'
# address_dict['un_out6_2']=f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/m1_05.parquet'
# address_dict['un_out7'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/unacast_hh_ip.parquet'
# address_dict['un_out8'] = f'/user/unity/datascience/griffin/match2/unacast/{bweek}/process/unacast_hh_ip_flags.parquet'


# List of addresses to clean ------------------------------------------------------------
address_clean= [
    address_dict['un_out1'], 
    address_dict['un_out2'],
    address_dict['un_out3'],
    address_dict['un_out3_2'],
    address_dict['un_out4'],
    address_dict['un_out5'],
    address_dict['un_out6'],
    address_dict['un_out6_2']
]


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Clean Unacast data'
proc[3] =   'Find mean of lat lons'
proc[4] =   'Aggregate mean lat lons'
proc[5] =   'Process UDPRN file'
proc[6] =   'Apply geo matching and output'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Input: Number of rows:'
stats_name['2']= 'Input: Number of IPs:'
stats_name['3']= 'Input: Number of IDs:'
stats_name['4']= 'Output: Number of rows:'
stats_name['5']= 'Output: Number of IPs:'
stats_name['6']= 'Output: Number of HHs:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('ip_address').count().count()
    stats['3']= df1.groupby('identifier').count().count()
    stats['4']= df2.count()
    stats['5']= df2.groupby('ip').count().count()
    stats['6']= df2.groupby('cb_key_household').count().count()
    return stats



#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read Unacast files and output as parquet
    # Also, ead UDPRN file
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------        
        una02= spark.read.parquet(address_dict['un_in1'])
        #
        u01= spark.read.parquet(address_dict['u_in2'])
        dt01= spark.read.parquet(address_dict['tax_in6'])
        cv01= spark.read.csv(address_dict['cv_in3'], header= True)
        pub01= spark.read.parquet(address_dict['pub_in4'])
        cip01= spark.read.parquet(address_dict['cp_in5'])
       #---------------------------------------------------------------------------------------------------
    #
    # Check columns
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        una03= una02.where(F.col('ip_address').isNotNull())
        una04= una03.where((F.col('device_lat').isNotNull()) & (F.col('device_lon').isNotNull()))
        una05= una04.where(F.col('timestamp').isNotNull())
        #
        una05_2= una05.withColumnRenamed('ip_address', 'ip')
        #
        una06= una05_2 \
            .withColumn('device_lat', F.col('device_lat').cast('double')) \
            .withColumn('device_lon', F.col('device_lon').cast('double'))
        #
        una06_1= una06.groupby('identifier', 'ip') \
            .agg(F.mean('device_lat').alias('device_lat2'), F.mean('device_lon').alias('device_lon2'))
        #---------------------------------------------------------------------------------------------------
    #
    # Filter none id5s
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        una06_2= una06.select('identifier','ip','timestamp','device_lat','device_lon') \
            .join(una06_1, ['identifier', 'ip'], 'inner')
        #
        una06_3= una06_2.withColumn('dist', 6371000*2*F.asin(F.sqrt((F.sin(math.pi*(F.col('device_lat')- F.col('device_lat2'))/(2*180)))**2 \
            + F.cos(math.pi*F.col('device_lat')/180)*F.cos(math.pi*F.col('device_lat2')/180)*(F.sin(math.pi*(F.col('device_lon')- F.col('device_lon2'))/(2*180)))**2)))
        #
        una06_4= una06_3.where(F.col('dist')<= 50) ####
        #
        una06_5= una06_4.groupby('identifier', 'ip') \
            .agg(F.mean('device_lat').alias('device_lat2'), F.mean('device_lon').alias('device_lon2'))
        #
        una06_6= una06_4.select('identifier','ip','timestamp','device_lat','device_lon').join(una06_5, ['identifier', 'ip'], 'inner')
        #
        una06_7= una06_6.withColumn('dist', 6371000*2*F.asin(F.sqrt((F.sin(math.pi*(F.col('device_lat')- F.col('device_lat2'))/(2*180)))**2 \
            + F.cos(math.pi*F.col('device_lat')/180)*F.cos(math.pi*F.col('device_lat2')/180)*(F.sin(math.pi*(F.col('device_lon')- F.col('device_lon2'))/(2*180)))**2)))
        #
        una06_8= una06_7.where(F.col('dist')<= 50) 
        ####Release3 - updated geo matching
        una06_8_2 = (
            una06_8.groupby('identifier', 'ip')
	        .agg(F.mean('device_lat').alias('device_lat2'), F.mean('device_lon').alias('device_lon2'))
        )
        una06_8_3= una06_8.select('identifier','ip','timestamp','device_lat','device_lon').join(una06_8_2, ['identifier', 'ip'], 'inner')
        una06_8_4= (
            una06_8_3
            .withColumn(
                'dist', 
                6371000*2*F.asin(F.sqrt((F.sin(math.pi*(F.col('device_lat')- F.col('device_lat2'))/(2*180)))**2 + 
                F.cos(math.pi*F.col('device_lat')/180)*F.cos(math.pi*F.col('device_lat2')/180)*(F.sin(math.pi*(F.col('device_lon')- F.col('device_lon2'))/(2*180)))**2))
            )
        )
        una06_8_5= una06_8_4.where(F.col('dist')<= 40)
        #
        una06_8_5.write.parquet(address_dict['un_out2'], mode= 'overwrite')
        una06_9= spark.read.parquet(address_dict['un_out2'])
        #---------------------------------------------------------------------------------------------------
    #
    # Write parquet 
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        una06_10= una06_9 \
            .withColumn('device_lat2', F.round(F.col('device_lat2'), 7)) \
            .withColumn('device_lon2', F.round(F.col('device_lon2'), 7))
        #
        una07= una06_10.groupby('ip', 'device_lat2', 'device_lon2').count().drop('count')
        #
        una08= una07 # <--- consitency reasons (doesn't cost anything)
        una08.write.parquet(address_dict['un_out3'], mode= 'overwrite')
        una09= spark.read.parquet(address_dict['un_out3'])
        #---------------------------------------------------------------------------------------------------
    #
    # Write parquet 
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        u02= u01 \
            .withColumn('Lat', F.col('Lat').cast('double')) \
            .withColumn('Lon', F.col('Lon').cast('double'))
        #
        u03= u02.groupby('Lat', 'Lon').count().drop('count')
        #
        u04= u03.withColumn('id', F.monotonically_increasing_id())
        #
        u04.write.parquet(address_dict['un_out3_2'], mode= 'overwrite')
        u05= spark.read.parquet(address_dict['un_out3_2'])
        #---------------------------------------------------------------------------------------------------
    #
    # Write parquet 
    with doing_xy(process_num= 6):
        #---------------------------------------------------------------------------------------------------
        agg= u05.agg(
            F.min('Lat').alias('min_Lat'), 
            F.max('Lat').alias('max_Lat'),
            F.min('Lon').alias('min_Lon'), 
            F.max('Lon').alias('max_Lon')
        )
        #
        agg= agg.collect()
        #
        min_Lat= agg[0]['min_Lat']
        max_Lat= agg[0]['max_Lat']
        min_Lon= agg[0]['min_Lon']
        max_Lon= agg[0]['max_Lon']
        min_Lat
        max_Lat
        min_Lon
        max_Lon
        #
        by_lat= 0.0045 # <-- hardcoded, shouldn't need to change
        by_lon= 0.00925 # <-- hardcoded, shouldn't need to change
        #
        list_lat1= np.arange(min_Lat, max_Lat+ by_lat, by_lat).tolist()
        list_lat2= np.arange(min_Lat- by_lat/2, max_Lat+ by_lat, by_lat).tolist()
        #
        list_lon1= np.arange(min_Lon, max_Lon+ by_lon, by_lon).tolist()
        list_lon2= np.arange(min_Lon- by_lon/2, max_Lon+ by_lon, by_lon).tolist()
        #
        y01= Bucketizer(splits= list_lat1, inputCol= 'Lat', outputCol= 'List_Lat1').transform(u05)
        y01= Bucketizer(splits= list_lat2, inputCol= 'Lat', outputCol= 'List_Lat2').transform(y01)
        y01= Bucketizer(splits= list_lon1, inputCol= 'Lon', outputCol= 'List_Lon1').transform(y01)
        y01= Bucketizer(splits= list_lon2, inputCol= 'Lon', outputCol= 'List_Lon2').transform(y01)
        #
        y02= una09.where((F.col('device_lat2').between(min_Lat, max_Lat)) & (F.col('device_lon2').between(min_Lon, max_Lon)))
        y02= Bucketizer(splits= list_lat1, inputCol= 'device_lat2', outputCol= 'List_Lat1').transform(y02)
        y02= Bucketizer(splits= list_lat2, inputCol= 'device_lat2', outputCol= 'List_Lat2').transform(y02)
        y02= Bucketizer(splits= list_lon1, inputCol= 'device_lon2', outputCol= 'List_Lon1').transform(y02)
        y02= Bucketizer(splits= list_lon2, inputCol= 'device_lon2', outputCol= 'List_Lon2').transform(y02)
        #
        y01.write.parquet(address_dict['un_out4'], mode= 'overwrite')
        y02.write.parquet(address_dict['un_out5'], mode= 'overwrite')
        #
        y01= spark.read.parquet(address_dict['un_out4'])
        y02= spark.read.parquet(address_dict['un_out5'])
        #
        y01_1= spark.read.parquet(address_dict['un_out4']).select('id','Lat','Lon','List_Lat1','List_Lon1')
        y01_2= spark.read.parquet(address_dict['un_out4']).select('id','Lat','Lon','List_Lat2','List_Lon1')
        y01_3= spark.read.parquet(address_dict['un_out4']).select('id','Lat','Lon','List_Lat1','List_Lon2')
        y01_4= spark.read.parquet(address_dict['un_out4']).select('id','Lat','Lon','List_Lat2','List_Lon2')
        #
        y02_1= spark.read.parquet(address_dict['un_out5']).select('ip','device_lat2','device_lon2','List_Lat1','List_Lon1')
        y02_2= spark.read.parquet(address_dict['un_out5']).select('ip','device_lat2','device_lon2','List_Lat2','List_Lon1')
        y02_3= spark.read.parquet(address_dict['un_out5']).select('ip','device_lat2','device_lon2','List_Lat1','List_Lon2')
        y02_4= spark.read.parquet(address_dict['un_out5']).select('ip','device_lat2','device_lon2','List_Lat2','List_Lon2')
        #
        # 1_1 ----------------------- <-- also 1_2 etc
        m101= y02_1.join(y01_1, ['List_Lat1', 'List_Lon1'], 'inner')
        #
        m102= m101.withColumn('dist', 6371000*2*F.asin(F.sqrt((F.sin(math.pi*(F.col('device_lat2')- F.col('Lat'))/(2*180)))**2 \
            + F.cos(math.pi*F.col('device_lat2')/180)*F.cos(math.pi*F.col('Lat')/180)*(F.sin(math.pi*(F.col('device_lon2')- F.col('Lon'))/(2*180)))**2))) \
            .drop('Lat', 'Lon', 'List_Lat1', 'List_Lon1')
        #
        m103= m102.where(F.col('dist')<= 250)
        #
        windowDept = Window.partitionBy("ip").orderBy(F.col("dist"))
        m104= m103.withColumn("row", F.row_number().over(windowDept)).filter(F.col("row") <= 5)
        #
        m104.write.parquet(address_dict['un_out6'], mode= 'overwrite')
        m1= spark.read.parquet(address_dict['un_out6'])
        #
        # Join device_lat / lon
        m1_02= m1.join(una06_10.select('identifier','ip','timestamp','device_lat2','device_lon2'), ['ip','device_lat2', 'device_lon2'], 'inner')
        #
        m1_04= m1_02.join(u05, 'id', 'inner')
        #
        u01_2= u01 \
            .withColumn('Lat', F.col('Lat').cast('double')) \
            .withColumn('Lon', F.col('Lon').cast('double'))
        #
        m1_05= m1_04.join(u01_2, ['Lat', 'Lon'], 'inner')
        m1_05.write.parquet(address_dict['un_out6_2'])
        m1_06= spark.read.parquet(address_dict['un_out6_2'])
        #
        #
        dt02= dt01.where(F.col('flag_UDPRN').isNull()).groupby('cb_key_household', 'UDPRN').count().drop('count')
        #
        m1_10= dt02.select('UDPRN','cb_key_household').join(m1_06, 'UDPRN', 'inner')
        #
        # m1_11= m1_10.withColumn('timestamp2', F.substring(F.col('timestamp'), 1, 10))
        m1_11= (
            m1_10
            .withColumn('timestamp2', F.substring(F.col('timestamp'), 1, 10))
            # CREATE time of day (tod) [well, hour of day]
            .withColumn('tod', F.substring(F.col('timestamp'), 12, 2))
            # CREATE flag for 'non-office' hours.
            .withColumn('tod_flag', F.when(F.col('tod').between('08', '18'), 0).otherwise(1))
        )
        #m1_12= m1_11.groupby('ip', 'cb_key_household').agg(F.min(F.col('dist')).alias('dist'), F.min(F.col('timestamp2')).alias('first'), F.max(F.col('timestamp2')).alias('last'))
        m1_12= (
            m1_11
            .groupby('ip', 'cb_key_household')
            .agg(
                F.min(F.col('dist')).alias('dist'), 
                F.min(F.col('timestamp2')).alias('first'), 
                F.max(F.col('timestamp2')).alias('last'), 
                F.mean(F.col('tod_flag')).alias('tod_mean')
            )
        )
        #
        m1_12.write.parquet(address_dict['un_out7'], mode= 'overwrite')
        una01_2= spark.read.parquet(address_dict['un_out7'])
        #
        #----------------------------------------------------------------------------------------
        cv02= cv01.groupby('cb_key_household').count().drop('count')
        cv03= cv02.withColumn('flag_chv', F.lit('1'))
        #
        una02_2= una01_2.join(cv03, 'cb_key_household', 'left')
        #
        una03_2= una02_2.withColumn('flag_chv', \
            F.when(F.col('flag_chv').isNull(), F.lit('0'))
            .otherwise(F.lit('1'))
        )
        #
        una04= una03_2
        #
        #----------------------------------------------------------------------------------------
        today= datetime.date.today()
        today_180= today- datetime.timedelta(days= 180)
        today_180= today_180.strftime("%Y-%m-%d")
        #
        #----------------------------------------------------------------------------------------
        pub02= pub01.groupby('ip').agg(F.max('last_seen').alias('last_seen'), F.collect_set('publisherid').alias('publishers'))
        pub03= pub02.select('ip', F.from_unixtime(F.col("last_seen")).alias("x"), 'publishers')
        pub04= pub03.withColumn('Timestamp', F.substring('x', 1,10)).drop('x')
        #
        #----------------------------------------------------------------------------------------
        pub05= pub04.where(F.col('Timestamp')>= today_180)
        ip01= pub05.select('ip','publishers').distinct()
        #
        #----------------------------------------------------------------------------------------
        # Get unique list of ips
        cip02= cip01.groupby('host').count().drop('count').withColumnRenamed('host', 'ip')
        cip03= cip02.withColumn('flag_cip', F.lit('1'))
        #
        ip01_2= ip01.join(cip03, 'ip', 'left')
        ip01_3= ip01_2.where(F.col('flag_cip').isNull()).drop('flag_cip')
        #
        #----------------------------------------------------------------------------------------
        ip02= ip01_3.withColumn('flag_pubip', F.lit('1'))
        #
        flags01= una04.join(ip02, 'ip', 'left')
        flags02= flags01.withColumn('flag_pubip', \
            F.when(F.col('flag_pubip').isNull(), F.lit('0')) \
            .otherwise(F.lit('1'))
        )
        #
        flags03= flags02.where((F.col('flag_chv')=='1') | (F.col('flag_pubip')=='1'))
        #
        windowDept = Window.partitionBy("ip").orderBy(F.col("dist"))
        flags04= flags03.withColumn("row", F.row_number().over(windowDept)).filter(F.col("row") <= 3)
        #
        flags04.write.parquet(address_dict['un_out8'], mode= 'overwrite')
        flags05= spark.read.parquet(address_dict['un_out8'])
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(una02,flags05)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)


