from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import argparse
import sys
from pathlib import Path
import logging
from datetime import datetime, timedelta
import pandas as pd
import math
import numpy as np
from pyspark.ml.feature import Bucketizer

sys.path.append(str(Path(__file__).resolve().parents[1]))

from funcs import process_functions as func
from configs import process_adresses as conf, config_process as pconf


def format_uc_data(df):
    """
    Formats unacast data to get unique device ids and assign a flag with value 1
    """
    return(
        df
        .withColumnRenamed('ADVERTISERID', 'identifier')
        .withColumnRenamed('LATITUDE', 'device_lat')
        .withColumnRenamed('LONGITUDE', 'device_lon')
        .withColumnRenamed('TIMESTAMP', 'timestamp_unix')
        .withColumnRenamed('IPADDRESS', 'ip_address')
        .withColumn('timestamp', F.from_unixtime(F.substring('timestamp_unix', 1, 10)))
    )


def clean_uc_data(df):
    """
    Cleans unacast data by removing duplicates and null values
    """
    return(
        df
        .where(F.col('ip_address').isNotNull())
        .where((F.col('device_lat').isNotNull()) & (F.col('device_lon').isNotNull()))
        .where(F.col('timestamp').isNotNull())
        .withColumnRenamed('ip_address', 'ip')
        .withColumn('device_lat', F.col('device_lat').cast('double'))
        .withColumn('device_lon', F.col('device_lon').cast('double'))
    )


def apply_distance_filter(df, dist_filter):
    """
    Applies a distance filter to the unacast data to remove records that are too far apart
    """
    return (
        df
        .withColumn(
            'dist', 
            6371000*2*F.asin(F.sqrt((F.sin(math.pi*(F.col('device_lat')- F.col('device_lat2'))/(2*180)))**2 \
            + F.cos(math.pi*F.col('device_lat')/180)*F.cos(math.pi*F.col('device_lat2')/180)*(F.sin(math.pi*(F.col('device_lon')- F.col('device_lon2'))/(2*180)))**2))
        )
        .where(F.col('dist')<= dist_filter)
    )


def iterative_distance_filter(logger, df, iteration_filters):
    """
    Applies iterative distance filtering to unacast data
    
    Args:
        df: Input DataFrame
        logger: Logger instance
        iteration_filters: List of tuples [(distance_threshold, iteration_name), ...]
    
    Returns:
        Final filtered DataFrame
    """
    current_df = df
    
    for i, (distance_threshold, iteration_name) in enumerate(iteration_filters):
        logger.info(f"Starting {iteration_name} with distance threshold {distance_threshold}m")
        
        # Aggregate to get mean lat/lon per identifier and ip
        agg_df = (
            current_df
            .groupby('identifier', 'ip')
            .agg(F.mean('device_lat').alias('device_lat2'), F.mean('device_lon').alias('device_lon2'))
        )
        logger.info(f"{iteration_name}: aggregated unacast data to get unique identifier and ip combinations")

        # Join back to get mean values
        with_mean_df = (
            current_df
            .select('identifier','ip','timestamp','device_lat','device_lon')
            .join(agg_df, ['identifier', 'ip'], 'inner')
        )
        logger.info(f"{iteration_name}: joined aggregated data back to get mean lat/lon values per identifier and ip")

        # Apply distance filter
        filtered_df = apply_distance_filter(with_mean_df, distance_threshold)
        filtered_count = filtered_df.count()
        logger.info(f"{iteration_name}: applied distance filter to remove records more than {distance_threshold}m apart, updated count: {filtered_count}")
        
        current_df = filtered_df
    
    return current_df


def logic_main(
        ctx, logger, mask, uc_in_dir, tax_suppress_path, latest_cv_path, pub_path, cip_path, 
        temp_dir, udprn_path, aud_in_dir, out_path, quick_stats_path, email_to
    ):
    logger.info(f"running unacast preprocessing process for {mask}")
    start_time = datetime.now()
    quick_stats=[]
    try:
        ## Read data
        try:
            all_dates = func.get_valid_date_dirs(uc_in_dir)
            logger.info(f"found all dated dirs in {uc_in_dir}, count: {len(all_dates)}")

            edate= datetime.today()
            sdate= edate + timedelta(days= -7)
            dates_7 = [(sdate + timedelta(days=x)).strftime('%Y-%m-%d') for x in range((edate-sdate).days+1)]

            valid_dates = sorted(list(set(all_dates).intersection(set(dates_7))))
            logger.info(f"found all valid dated dirs in {uc_in_dir}, count: {len(valid_dates)}")

            if len(valid_dates)==0:
                raise Exception(f"no valid dated dirs found in {uc_in_dir}")            
            
            dateString = "{" + ",".join(valid_dates) + "}"
            uc_in_path = f"{uc_in_dir}/{dateString}/from_unacast__*.csv"
            uc_in_df = ctx.read.csv(uc_in_path, header=True)
            uc_in_count = uc_in_df.count()
            logger.info(f"read unacast data from {uc_in_path} with {uc_in_count} records")

            try:
                latest_optouts_path = func.latest_file(f"{uc_in_dir}/20*/process", "unacast_optouts_combined")
                uc_optouts_df = (
                    ctx.read.parquet(latest_optouts_path)
                    .drop('reported_date')
                    .withColumnRenamed("advertiserid", "identifier")
                    .select('grid','identifier')
                )
                uc_optouts_count = uc_optouts_df.count()
                logger.info(f"read latest unacast optouts from {latest_optouts_path} with {uc_optouts_count} records")
            except:
                uc_optouts_df = None
                uc_optouts_count = 0
                logger.info(f"no unacast optouts file found at {latest_optouts_path}, continuing without optouts")

            tax_suppress_df = ctx.read.parquet(tax_suppress_path)
            logger.info(f"read tax suppress data from {tax_suppress_path}")

            cv_df = ctx.read.parquet(latest_cv_path)
            logger.info(f"read latest cv data from {latest_cv_path}")

            pub_df = ctx.read.parquet(pub_path)
            logger.info(f"read publisher data from {pub_path}")

            cip_df = ctx.read.parquet(cip_path)
            logger.info(f"read cip data from {cip_path}")

            udprn_df = ctx.read.parquet(udprn_path)
            logger.info(f"read udprn data from {udprn_path}")

            func.update_stats(
                quick_stats, "Load Inputs", 
                f"""
                successfully read all input data, including:
                unacast data from {uc_in_path} with {uc_in_count:,} records,
                tax suppress data from {tax_suppress_path},
                latest cv data from {latest_cv_path},
                publisher data from {pub_path},
                cip data from {cip_path},
                udprn data from {udprn_path}
                """
            )
        except Exception as e:
            func.update_stats(quick_stats, "Load Inputs", f"unable to read in data: {e}")
            raise
        
        ## Format Data and apply distance filter
        try:
            if uc_optouts_df:
                uc_wo_optouts = uc_in_df.join(uc_optouts_df, on=['grid','identifier'], how='left_anti')
                uc_wo_optouts_count = uc_wo_optouts.count()
                logger.info(f"removed optouts from unacast data, updated count: {uc_wo_optouts_count}")
            else:
                uc_wo_optouts = uc_in_df                
                logger.info(f"no optouts to remove from unacast data")
            
            uc_cleaned = clean_uc_data(uc_wo_optouts).cache()
            uc_cleaned_count = uc_cleaned.count()
            logger.info(f"cleaned unacast data by removing null valued ips and device lat/lon with updated count: {uc_cleaned_count}")

            iteration_filters = [
                (50, "First iteration"), # (distance, iteration name)
                (50, "Second iteration"), 
                (40, "Third iteration")
            ]

            uc_filter_3_init = iterative_distance_filter(logger, uc_cleaned, iteration_filters)            
            logger.info(f"re-applied distance filter to unacast data to remove records that are more than 40m apart, updated count: {uc_filter_3_count}")
            uc_cleaned.unpersist()

            temp_path_ucfil = f"{temp_dir}/uc_filtered_temp_{mask}.parquet"
            uc_filter_3_init.write.parquet(temp_path_ucfil, mode='overwrite')
            logger.info(f"wrote intermediate unacast filtered data to {temp_path_ucfil}")
            uc_filter_3 = ctx.read.parquet(temp_path_ucfil)
            uc_filter_3_count = uc_filter_3.count()
            logger.info(f"read back intermediate unacast filtered data, final count: {uc_filter_3_count}")            

            uc_filter_fmt_init = (
                uc_filter_3
                .withColumn('device_lat2', F.round(F.col('device_lat2'), 7))
                .withColumn('device_lon2', F.round(F.col('device_lon2'), 7))                
            )
            uc_filter_fmt = (
                uc_filter_fmt_init
                .select('ip', 'device_lat2', 'device_lon2')
                .distinct()
            )
            uc_filter_fmt_count = uc_filter_fmt.count()
            logger.info(f"formatted final unacast filtered data to get unique ips with mean lat/lon rounded to 7 decimal places, final count: {uc_filter_fmt_count}")

            func.update_stats(
                quick_stats, "Format Data and apply distance filter", 
                f"""
                successfully formatted and applied distance filter to unacast data, including:
                removed optouts with updated count: {uc_wo_optouts_count:,},
                cleaned data with updated count: {uc_cleaned_count:,},
                applied distance filter 3 times to get filtered data with count: {uc_filter_3_count:,},
                formatted filtered data with updated count: {uc_filter_fmt_count:,}
                """
            )            
        except Exception as e:
            func.update_stats(quick_stats, "Format Data and apply distance filter", f"unable to format and filter data: {e}")
            raise
        
        ## Format Experian UDPRN-Lat/lon data
        try:
            udprn_df_fmt_init = (
                udprn_df
                .withColumn('Lat', F.col('Lat').cast('double'))
                .withColumn('Lon', F.col('Lon').cast('double'))
            )
            logger.info("formatted udprn data to cast lat/lon to double type")

            udprn_df_fmt = (
                udprn_df_fmt_init
                .select("Lat", "Lon")
                .distinct()
                .withColumn('id', F.monotonically_increasing_id())
            )
            logger.info("formatted udprn data to get unique lat/lon combinations")

            temp_path_ulat = f"{temp_dir}/udprn_lat_lon.parquet"
            udprn_df_fmt.write.parquet(temp_path_ulat, mode='overwrite')
            logger.info(f"formatted udprn data to get unique lat/lon combinations and wrote to {temp_path_ulat}")
            udprn_df_fmt = ctx.read.parquet(temp_path_ulat)            
            unique_latlon_count = udprn_df_fmt.count()            
            logger.info(f"read back intermediate data from {temp_path_ulat} and formatted udprn data to get unique lat/lon combinations, count: {unique_latlon_count}")

            udprn_agg = (
                udprn_df_fmt
                .agg(
                    F.min('Lat').alias('min_Lat'), 
                    F.max('Lat').alias('max_Lat'),
                    F.min('Lon').alias('min_Lon'), 
                    F.max('Lon').alias('max_Lon')
                )
            )
            logger.info("aggregated udprn data to get min and max lat/lon values")

            udprn_list = udprn_agg.collect()
            min_Lat= udprn_list[0]['min_Lat']
            max_Lat= udprn_list[0]['max_Lat']
            min_Lon= udprn_list[0]['min_Lon']
            max_Lon= udprn_list[0]['max_Lon']
            logger.info(f"udprn lat/lon ranges: min_Lat={min_Lat}, max_Lat={max_Lat}, min_Lon={min_Lon}, max_Lon={max_Lon}")

            by_lat= 0.0045 # <-- hardcoded, shouldn't need to change
            by_lon= 0.00925 # <-- hardcoded, shouldn't need to change
            list_lat1= np.arange(min_Lat, max_Lat+ by_lat, by_lat).tolist()
            list_lat2= np.arange(min_Lat- by_lat/2, max_Lat+ by_lat, by_lat).tolist()            
            list_lon1= np.arange(min_Lon, max_Lon+ by_lon, by_lon).tolist()
            list_lon2= np.arange(min_Lon- by_lon/2, max_Lon+ by_lon, by_lon).tolist()
            logger.info(f"created lat/lon grids with grid height (latitude degree): {by_lat} and width (longitude degree): {by_lon}")

            udprn_bucketed = Bucketizer(splits= list_lat1, inputCol= 'Lat', outputCol= 'List_Lat1').transform(udprn_df_fmt)
            udprn_bucketed= Bucketizer(splits= list_lat2, inputCol= 'Lat', outputCol= 'List_Lat2').transform(udprn_bucketed)
            udprn_bucketed= Bucketizer(splits= list_lon1, inputCol= 'Lon', outputCol= 'List_Lon1').transform(udprn_bucketed)
            udprn_bucketed= Bucketizer(splits= list_lon2, inputCol= 'Lon', outputCol= 'List_Lon2').transform(udprn_bucketed)
            logger.info("applied bucketizer to lat/lon values to assign grid values")
            
            uc_bucketed = uc_filter_fmt.where((F.col('device_lat2').between(min_Lat, max_Lat)) & (F.col('device_lon2').between(min_Lon, max_Lon)))
            uc_bucketed= Bucketizer(splits= list_lat1, inputCol= 'device_lat2', outputCol= 'List_Lat1').transform(uc_bucketed)
            uc_bucketed= Bucketizer(splits= list_lat2, inputCol= 'device_lat2', outputCol= 'List_Lat2').transform(uc_bucketed)
            uc_bucketed= Bucketizer(splits= list_lon1, inputCol= 'device_lon2', outputCol= 'List_Lon1').transform(uc_bucketed)
            uc_bucketed= Bucketizer(splits= list_lon2, inputCol= 'device_lon2', outputCol= 'List_Lon2').transform(uc_bucketed)
            logger.info("applied bucketizer to device lat/lon values to assign grid values")

            temp_udprn_path = f"{temp_dir}/udprn_bucketed.parquet"
            udprn_bucketed.write.parquet(temp_udprn_path, mode='overwrite')
            logger.info(f"wrote formatted udprn data to {temp_udprn_path}")
            temp_uc_path = f"{temp_dir}/y02.parquet"
            uc_bucketed.write.parquet(temp_uc_path, mode='overwrite')
            logger.info(f"wrote formatted uc data to {temp_uc_path}")

            udprn_bucketed = ctx.read.parquet(temp_udprn_path).cache()            
            uc_bucketed = ctx.read.parquet(temp_uc_path)            
            logger.info(f"read back bucketed udprn and uc data from {temp_udprn_path} with {udprn_bucketed.count()} records and {temp_uc_path} with {uc_bucketed.count()} records")

            udprn_bucketed_1 = udprn_bucketed.select('id','Lat','Lon','List_Lat1','List_Lon1')
            logger.info("extracted relevant columns from udprn data")

            uc_bucketed_1= uc_bucketed.select('ip','device_lat2','device_lon2','List_Lat1','List_Lon1')
            logger.info("extracted relevant columns from uc data")

            combined_df = uc_bucketed_1.join(udprn_bucketed_1, ['List_Lat1', 'List_Lon1'], 'inner')
            logger.info("joined uc and udprn data on List_Lat1 and List_Lon1")

            winspec = Window.partitionBy("ip").orderBy(F.col("dist"))
            combined_df_filtered = (
                combined_df
                .withColumn('dist', 6371000*2*F.asin(F.sqrt((F.sin(math.pi*(F.col('device_lat2')- F.col('Lat'))/(2*180)))**2 \
                + F.cos(math.pi*F.col('device_lat2')/180)*F.cos(math.pi*F.col('Lat')/180)*(F.sin(math.pi*(F.col('device_lon2')- F.col('Lon'))/(2*180)))**2))) \
                .drop('Lat', 'Lon', 'List_Lat1', 'List_Lon1')
                .where(F.col('dist')<= 250)
                .withColumn("row", F.row_number().over(winspec)).filter(F.col("row") <= 5)
            )
            logger.info("calculated distance between uc and udprn data and filtered to keep records with distance less than 250m, keeping up to 5 closest udprn records per ip")

            temp_path_cdf = f"{temp_dir}/m1.parquet"
            combined_df_filtered.write.parquet(temp_path_cdf, mode='overwrite')
            logger.info(f"wrote filtered combined data to {temp_path_cdf}")
            combined_df_filtered = ctx.read.parquet(temp_path_cdf)            
            logger.info(f"read back filtered combined data from {temp_path_cdf}")

            uc_init = (
                combined_df_filtered
                .join(
                    uc_filter_fmt_init
                    .select('identifier','ip','timestamp','device_lat2','device_lon2'),
                    ['ip','device_lat2', 'device_lon2'], 
                    'inner'
                )                
            )
            logger.info("joined bucketed data with initial formatted uc data")

            udrn_with_uc_1 = (
                uc_init
                .join(
                    udprn_df_fmt,
                    'id',
                    'inner'
                )
            )
            logger.info("joined bucketed and uc data with udprn data")

            udrn_with_uc_2 = (
                 udrn_with_uc_1
                .join(
                    udprn_df_fmt_init,
                    ['Lat', 'Lon'],
                    'inner'
                )
            )
            logger.info("joined combined, uc and udprn data back with initial udprn data to get full lat/lon values")
            temp_path_uu2 = f"{temp_dir}/m1_05.parquet"
            udrn_with_uc_2.write.parquet(temp_path_uu2, mode='overwrite')
            logger.info(f"wrote final combined data to {temp_path_uu2}")
            uc_udprn_before_suppress = ctx.read.parquet(temp_path_uu2)
            logger.info(f"read back final combined data from {temp_path_uu2} records")

            func.update_stats(
                quick_stats, "Format Experian UDPRN-Lat/lon data", 
                "bucketed udprn and uc data via grids to calculate distance between uc and udprn lat/lon values to filter to closest matches"
            )
        except Exception as e:
            func.update_stats(quick_stats, "Format Experian UDPRN-Lat/lon data", f"unable to format udprn data: {e}")

        ## Use UDPRN to assign to HHK
        try:
            tax_suppress_df_fmt = (
                tax_suppress_df
                .where(F.col('flag_UDPRN').isNull())
                .select('UDPRN', 'cb_key_household')
                .distinct()
            )
            logger.info("formatted tax suppress data to get unique udprn values to suppress")

            uc_udprn_after_suppress = (
                uc_udprn_before_suppress
                .join(tax_suppress_df_fmt, 'UDPRN', 'inner')
            )
            logger.info("suppressed uc_udprn data based on tax suppress criteria")

            uc_udprn_after_suppress_fmt = (
                uc_udprn_after_suppress
                .withColumn('timestamp2', F.substring(F.col('timestamp'), 1, 10)) 
                .withColumn('tod', F.substring(F.col('timestamp'), 12, 2)) # CREATE hour of day (tod)
                .withColumn('tod_flag', F.when(F.col('tod').between('08', '18'), 0).otherwise(1)) # CREATE flag for 'non-office' hours.
            )
            logger.info("formatted final uc_udprn data to create timestamp2, tod and tod_flag columns")

            temp_path_uusupressed = f"{temp_dir}/unacast_hh_ip.parquet"
            uc_udprn_after_suppress_fmt.write.parquet(temp_path_uusupressed, mode='overwrite')
            logger.info(f"wrote final uc_udprn data after tax suppress to {temp_path_uusupressed}")
            uc_udprn_after_suppress_fmt = ctx.read.parquet(temp_path_uusupressed)
            logger.info(f"read back final uc_udprn data from {temp_path_uusupressed}")

            cv_hhk = (
                cv_df
                .select("cb_key_household")
                .distinct()
                .withColumn('flag_chv', F.lit('1'))
            )
            logger.info("extracted unique cb_key_household values from cv_df and assigned a static flag")

            uc_with_hhk = (
                uc_udprn_after_suppress_fmt
                .join(
                    cv_hhk,
                    'cb_key_household',
                    'left'
                )
                .withColumn(
                    'flag_chv',
                    F.when(F.col('flag_chv').isNull(), F.lit('0'))
                    .otherwise(F.lit('1'))
                )
            )
            logger.info("joined uc_udprn data with cv_hhk data to attach cv household keys to UDPRNs")

            today = datetime.today()
            today_180= (today- timedelta(days= 180)).strftime('%Y-%m-%d')

            pub_df_fmt = (
                pub_df
                .groupby('ip')
                .agg(
                    F.max('last_seen').alias('last_seen'), 
                    F.collect_set('publisherid').alias('publishers')
                )
                .select('ip', F.from_unixtime(F.col("last_seen")).alias("x"), 'publishers')
                .withColumn('Timestamp', F.substring('x', 1,10)).drop('x')
                .where(F.col('Timestamp')>= today_180)
                .select('ip','publishers')
                .distinct()
            )
            logger.info("formatted publisher data to get unique ips with list of publishers seen in last 180 days")

            cip_df_fmt = (
                cip_df
                .select("host")
                .distinct()
                .withColumnRenamed("host", "ip")
                .withColumn('flag_cip', F.lit('1'))
            )
            logger.info("formatted cip data to get unique ips with flag_cip")

            pub_wo_optouts = (
                pub_df_fmt
                .join(cip_df_fmt, 'ip', 'left')
                .where(F.col('flag_cip').isNull())
                .drop('flag_cip')
                .withColumn('flag_pubip', F.lit('1'))
            )
            logger.info("removed cip optouts from publisher data to get pub_wo_optouts data")

            uc_hhk_with_pub_flag = (
                uc_with_hhk
                .join(pub_wo_optouts, 'ip', 'left')
                .withColumn('flag_pubip', \
                    F.when(F.col('flag_pubip').isNull(), F.lit('0')) \
                    .otherwise(F.lit('1'))
                )
            )
            logger.info("joined uc_with_hhk data with pub_wo_optouts data to assign publisher flags to ips")

            #AUDIGENT FLAGS
            all_dates = func.get_valid_date_dirs(aud_in_dir)
            logger.info(f"found all dated dirs in {aud_in_dir}, count: {len(all_dates)}")

            edate= datetime.today()
            sdate= edate + timedelta(days= -180)
            dates_180 = [(sdate + timedelta(days=x)).strftime('%Y-%m-%d') for x in range((edate-sdate).days)]

            valid_dates = sorted(list(set(all_dates).intersection(set(dates_180))))
            logger.info(f"found all valid dated dirs in {aud_in_dir}, count: {len(valid_dates)}")

            if len(valid_dates)==0:
                raise Exception(f"no valid dated dirs found in {aud_in_dir}")
            
            dateString = "{" + ",".join(valid_dates) + "}"
            aud_ip_path = f"{aud_in_dir}/{dateString}/ip_preprocessed*.parquet"
            aud_ip_df = ctx.read.parquet(aud_ip_path, mergeSchema=True)
            aud_ip_count = aud_ip_df.count()
            logger.info(f"read audigent ip data from {aud_ip_path} with {aud_ip_count} records")

            aud_ip_df_fmt = (
                aud_ip_df
                .select("ip")
                .distinct()
                .withColumn('flag_audip', F.lit('1'))
            )
            logger.info("formatted audigent ip data to get unique ips with flag_audip")

            uc_hhk_with_aud_flag = (
                uc_hhk_with_pub_flag
                .join(aud_ip_df_fmt, 'ip', 'left')
                .withColumn('flag_audip', F.when(F.col('flag_audip').isNull(), '0').otherwise(F.col('flag_audip')))
            )
            logger.info("joined uc with pub flag with aud ip data to assign audigent flags")

            func.update_stats(
                quick_stats, "Get HHK and Flags",
                f"""
                successfully assigned UDPRN to HHK and applied suppressions and flags,
                suppressed tax suppress data with updated count: {uc_udprn_after_suppress_fmt.count():,},
                cv flag records: {uc_with_hhk.where(F.col('flag_chv')==1).count():,},
                pub flag records: {uc_with_hhk.where(F.col('flag_pubip')==1).count():,},
                aud flag records: {uc_with_hhk.where(F.col('flag_audip')==1).count():,}
                """
            )
        except Exception as e:
            logger.error(f"Error occurred while updating stats: {e}")
        

        ## Write output
        try:
            winspec = Window.partitionBy("ip").orderBy(F.col("dist"))
            final_df = (
                uc_hhk_with_aud_flag
                .where((F.col('flag_chv') + F.col('flag_pubip') + F.col('flag_audip')))
                .withColumn("row", F.row_number().over(winspec))
                .filter(F.col("row") <= 3)                       
            )
            logger.info("filtered final data to keep up to 3 closest udprn records per ip")

            final_df.write.parquet(out_path, mode="overwrite")
            logger.info(f"wrote final output data to {out_path}")

            final_df = ctx.read.parquet(out_path)
            final_df_count = final_df.count()

            func.update_stats(
                quick_stats, "Write Final Output",
                f"""
                successfully wrote final output data with {final_df_count:,} records to {out_path}.
                uc input row count: {uc_in_count:,},
                uc input ip count: {uc_in_df.select('ip').distinct().count():,},
                uc input id count: {uc_in_df.select('identifier').distinct().count():,},
                uc optout row count: {uc_optouts_count:,},
                uc row count after optout removal: {uc_wo_optouts_count:,},
                uc ip count after optout removal: {uc_wo_optouts.select('ip').distinct().count():,},
                uc id count after optout removal: {uc_wo_optouts.select('identifier').distinct().count():,},
                uc output row count: {final_df_count:,},
                uc output ip count: {final_df.select('ip').distinct().count():,},
                uc output id count: {final_df.select('identifier').distinct().count():,}
                """
            )
        except Exception as e:
            func.update_stats(quick_stats, "Write Final Output", f"unable to write final output data: {e}")
            raise

        success_flag = True

    except Exception as e:
        success_flag = False
        logger.error(f"process failed: {e}")        
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        latest_alerts_df = func.compare_stats(logger, mask, quick_stats_path, alerts_df)
        latest_qstats_path = quick_stats_path.format(wsd=mask)
        latest_alerts_df.to_csv(latest_qstats_path, index=False)
        logger.info(f"wrote latest stats to {latest_qstats_path}")
        
        email_sub = f"***P025 - UC Preprocess - {pconf.STATUS_EMOJIS['green']}***" if success_flag else f"***P025 - UC Preprocess - {pconf.STATUS_EMOJIS['red']}***"
        func.send_teams_email(mask, email_sub, latest_alerts_df.to_html(index=False), email_to)
        end_time = datetime.now()
        duration = str(end_time-start_time).split('.')[0]
        logger.info(f"finished preprocessing UC data for {mask} in {duration}")


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", "week start date for which process runs in YYYY-MM-DD", default=conf.bweek)
    parser.add_argument("-uid", "--uc_in_dir", help="input directory for raw unacast data", default=conf.P025_un_in1)
    parser.add_argument("-tsp", "--tax_suppress_path", help="path to suppressed taxonomy data", default=conf.P025_tax_in6)
    parser.add_argument("-lcp", "--latest_cv_path", help="path containing monthly ip address data", default=conf.P025_cv_in3)
    parser.add_argument("-pp", "--pub_path", help="path to publisher data", default=conf.P025_pub_in4)
    parser.add_argument("-cp", "--cip_path", help="path to cip data", default=conf.P025_cp_in5)
    parser.add_argument("-td", "--temp_dir", help="temporary directory for intermediate files", default=conf.P025_un_out1)
    parser.add_argument("-up", "--udprn_path", help="path to experian udprn data", default=conf.P025_u_in2)
    parser.add_argument("-aid", "--aud_in_dir", help="input directory for audigent ip data", default=conf.P025_aud_in7)
    parser.add_argument("-op", "--out_path", help="output path for final processed data", default=conf.P025_un_out2)
    parser.add_argument("-qsp", "--quick_stats_path", help="path to write quick stats csv to", default=conf.P025_un_out3)
    parser.add_argument("-et", "--email_to", help="email address to send alerts to, comma delimited if multiple", default=conf.EMAIL_TO)
    args = parser.parse_args()

    args = parser.parse_args()

    name = Path(__file__).stem
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    logger = pconf.LogConfig("{path}/log-{name}-{mask}.log".format(path=conf.LOG_DIR, name=name, mask=args.mask)).generate_logger(name)

    # process is triggered here
    logic_main(
        spark, logger, args.mask, args.uc_in_dir, args.tax_suppress_path, args.latest_cv_path, 
        args.pub_path, args.cip_path, args.temp_dir, args.udprn_path, 
        args.aud_in_dir, args.out_path, args.quick_stats_path, args.email_to
    )


