from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import argparse
import sys
from pathlib import Path
import logging
from datetime import datetime, timedelta
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[1]))

from funcs import process_functions as func
from configs import process_adresses as conf, config_process as pconf


def format_ip_data(df):
    """
    Formats audigent ip data to get unique IPs and assign a flag with value 1
    """
    df_dd = df.select("id_value").distinct()
    return (
        df_dd
        .withColumn('flag_audip', F.lit('1'))
    )


def logic_main(ctx, logger, mask, aud_in_dir, de_pubip_path, out_path, quick_stats_path, email_to):
    logger.info(f"running audigent flag addition to de data process for {mask}")
    start_time = datetime.now()
    quick_stats=[]
    try:
        ## Read data
        try:
            all_dates = func.get_valid_date_dirs(aud_in_dir)
            logger.info(f"found all dated dirs in {aud_in_dir}, count: {len(all_dates)}")

            edate= datetime.today()
            sdate= edate + timedelta(days= -180)
            dates_180 = [(sdate + timedelta(days=x)).strftime('%Y-%m-%d') for x in range((edate-sdate).days)]

            valid_dates = sorted(list(set(all_dates).intersection(set(dates_180))))
            logger.info(f"found all valid dated dirs in {aud_in_dir}, count: {len(valid_dates)}")

            if len(valid_dates)==0:
                raise Exception(f"no valid dated dirs found in {aud_in_dir}")
            
            dateString = "{" + ",".join(valid_dates) + "}"
            aud_ip_path = f"{aud_in_dir}/{dateString}/ip_preprocessed*.parquet"
            aud_ip_df = ctx.read.parquet(aud_ip_path, mergeSchema=True)
            aud_ip_count = aud_ip_df.count()
            logger.info(f"read audigent ip data from {aud_ip_path} with {aud_ip_count} records")

            de_df = ctx.read.parquet(de_pubip_path)
            de_count = de_df.count()
            logger.info(f"read de data with publisher ip flag from {de_pubip_path} with {de_count} records")

            func.update_stats(quick_stats, "Load Inputs", f"read last 180 days worth of audigent data from {aud_in_dir} (latest date: {valid_dates[-1]}) with {aud_ip_count:,} records and latest DE with publisher ip flag from {de_pubip_path} with {de_count:,} records")
        except Exception as e:
            func.update_stats(quick_stats, "Load Inputs", f"unable to read in data: {e}")
            raise
        
        ## Process data
        try:
            aud_ip_df_fmt = format_ip_data(aud_ip_df)
            logger.info("extracted unique ips and assigned a static flag")

            de_enriched_df = (
                de_df
                .join(aud_ip_df_fmt, 'ip', 'left')
                .withColumn('flag_audip', F.when(F.col('flag_audip').isNull(), '0').otherwise(F.col('flag_audip')))
            ).cache()
            final_count = de_enriched_df.count()
            logger.info(f"enriched DE data with Audigent IP and flagged them for reference, count: {final_count}")

            de_enriched_df.write.parquet(out_path, mode="overwrite")
            logger.info("wrote output data to {out_path}")

            func.update_stats(
                quick_stats, "Process Data", 
                f"""
                    enriched DE data with Audigent IP and flagged them for reference, wrote out to {out_path}, 
                    record count: {final_count:,},
                    aud record count: {de_enriched_df.filter(F.col('flag_audip')=='1').count():,},
                    audigent ip count: {de_enriched_df.filter(F.col('flag_audip')=='1').select('ip').distinct().count():,},
                    audigent hhk count: {de_enriched_df.filter(F.col('flag_audip')=='1').select('cb_key_household').distinct().count():,},
                    only audigent ip count: {de_enriched_df.where((F.col('flag_chv')+F.col('flag_pubip')== 0) & (F.col('flag_audip')== '1')).select('ip').distinct().count():,},
                    only audigent hhk count: {de_enriched_df.where((F.col('flag_chv')+F.col('flag_pubip')== 0) & (F.col('flag_audip')== '1')).select('cb_key_household').distinct().count():,},
                    only audigent record count: {de_enriched_df.where((F.col('flag_chv')+F.col('flag_pubip')== 0) & (F.col('flag_audip')== '1')).count():,}
                """
            )
        except Exception as e:
            func.update_stats(quick_stats, "Process Data", f"unable to process data: {e}")
            raise

        success_flag = True

    except Exception as e:
        success_flag = False
        logger.error(f"process failed: {e}")        
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        latest_alerts_df = func.compare_stats(logger, mask, quick_stats_path, alerts_df)
        latest_qstats_path = quick_stats_path.format(wsd=mask)
        latest_alerts_df.to_csv(latest_qstats_path, index=False)
        logger.info(f"wrote latest stats to {latest_qstats_path}")
        
        email_sub = f"***P035_3_2 - Add Audigent IP to DE - {pconf.STATUS_EMOJIS['green']}***" if success_flag else f"***P035_3_2 - Add Audigent IP to DE - {pconf.STATUS_EMOJIS['red']}***"
        func.send_teams_email(mask, email_sub, latest_alerts_df.to_html(index=False), email_to)
        end_time = datetime.now()
        duration = str(end_time-start_time).split('.')[0]
        logger.info(f"finished audigent flag addition to DE data for {mask} in {duration}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("-m", "--mask", "week start date for which process runs in YYYY-MM-DD", default=conf.bweek)
    parser.add_argument("-aid", "--aud_in_dir", "directory containing audigent data", default=conf.P035_3_2_in1)
    parser.add_argument("-dpp", "--de_pubip_path", "path to the de data with publisher ip flag", default=conf.P035_3_2_in2)    
    parser.add_argument("-op", "--out_path", "path to the output data with the additional audigent ip flag", default=conf.P035_3_2_out2)
    parser.add_argument("-qsp", "--quick_stats_path", "path to the store quick stats data to compare", default=conf.P035_3_2_out3)
    parser.add_argument("-et", "--email_to", "path to the store quick stats data to compare", default=conf.EMAIL_TO)

    args = parser.parse_args()

    name = Path(__file__).stem
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    logger = pconf.LogConfig("{path}/log-{name}-{mask}.log".format(path=conf.LOG_DIR, name=name, mask=args.mask)).generate_logger(name)

    # process is triggered here
    logic_main(spark, logger, args.mask, args.aud_in_dir, args.de_pubip_path, args.out_path, args.quick_stats_path, args.email_to)



