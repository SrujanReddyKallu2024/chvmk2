
# P01
P01_dt_in1  = 'match2/test/wrong_test/December22_Digital_taxonomy.csv'

# P02_1
P02_1_dt_in1= 'match2/test/wrong_test/weekly_nmr/A16.20221205.csv'

# P02_2
P02_2_dt_in1= 'match2/test/wrong_test/dt_supp.parquet'

# P03
_03_ip_in1  = 'match2/test/wrong_test/ip.parquet'

# P04
_04_de_in1  = 'match2/test/wrong_test/from_de.csv'

# P05
_05_de_in1  = 'match2/test/wrong_test/de01_long.parquet'

# P06
_06_ip_in1  = 'match2/test/wrong_test/IP_Address_Data_Output_20221003.csv'

# P07
P07_ip_in1  = 'match2/test/wrong_test/ip_publishers.parquet'

# P08
P08_ip_in1  = 'match2/test/wrong_test/ip_all_agg_sup.parquet'

# P09
_09_id_in1  = 'match2/test/wrong_test/from_id5.parquet'

# P10
_10_join_in1= 'match2/test/wrong_test/de01_long.parquet'

# P11
_11_mc_in1= 'match2/test/wrong_test/MC.csv'

# P12
_12_dt_in1= 'match2/test/wrong_test/Digital_taxonomy.parquet'

# P14
_14_join_in1= 'match2/test/wrong_test/mc.parquet'

# P15
_15_join_in1= 'match2/test/wrong_test/MC_UID.parquet'

# P16
_16_dt_in1  = '/data/griffin/taxonomy/S_CODE_PUBMATIC2___.csv'
