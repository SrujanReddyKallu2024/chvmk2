# Receive notifications 0=No, 1=Yes
notifications= 1

# Email address of sender (use your own email if YOU are running it)
email= 'andrew.griffin@experian.com'

# Weekly run, Unit Test or Error Test
process_run= 0
# Weekly_run=   0
# Unit_Test=    1
# Error_Test=   2
# Quick run =   3

# base directory for input file and processing
base= '/user/unity/match2'

# directory containing the A16 nmr files
nmr_path= '/user/unity/v2/weekly_nmr'

# Publisher CIP directory
pub_cip_path= '/user/unity/v2/central_backlog/cip/*/'

# local directory path for file going to Digital Element 
de_path= '/data/griffin/output'

# CV directory path
cv_path= '/user/unity/v2/monthly_cv'

# week start date (leave missing for start of current week i.e. bweek= '')
# bweek = date of first Monday of THIS week 'YYYY-MM-DD':
# nweek = date of first Monday of NEXT week 'YYYY-MM-DD':
bweek= ''
nweek= ''
lweek= ''

#Taxonomy date:
# missing ('') for latest file
path_tax= ''

quick_stats_path= '/data/griffin/quick_stats'

STATUS_EMOJIS = {
        'green': '\U00002705',  # ✅
        'amber': '\U000026A0',  # ⚠️
        'red': '\U0000274C'     # ❌
    }

##Setting up logger
import logging
import logging.handlers

class LogConfig(object):
    LOGLEVEL = logging.DEBUG
    FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    LOGFILE = 'output.log'
    LOGSIZE = 10000000
    LOGLEVEL_FILE = logging.DEBUG
    #
    # easy overwrite logfile name
    def __init__(self, altfilename='output.log'):
        self.LOGFILE = altfilename
    #
    # generate the logging object
    def generate_logger(self, name):
        # initializing logger properties
        formatter = logging.Formatter(self.FORMAT)
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        handler.setLevel(self.LOGLEVEL)
        handler.setFormatter(formatter)
        # Add the log message handler to the logger
        file_handler = logging.handlers.RotatingFileHandler(
            self.LOGFILE,
            maxBytes=self.LOGSIZE,
            backupCount=5,
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(self.LOGLEVEL_FILE)
        logger.addHandler(file_handler)
        logger.addHandler(handler)
        return logger

