
# P01
P01_dt_in1  = 'match2/test/unit_test/December22_Digital_taxonomy.csv'
P01_dt_out1 = 'match2/test/unit_test/output/Digital_taxonomy/process/Digital_taxonomy.parquet'

# P02_1
P02_1_dt_in1  = 'match2/test/unit_test/weekly_nmr/A16.20221205.csv' 
P02_1_dt_in2  = 'match2/test/unit_test/output/Digital_taxonomy/process/Digital_taxonomy.parquet'
P02_1_dt_out1 = 'match2/test/unit_test/output/Digital_taxonomy/process/Taxonomy_Suppress.parquet'

# P02_2
P02_2_dt_in1  = 'match2/test/unit_test/output/Digital_taxonomy/process/Taxonomy_Suppress.parquet'
P02_2_dt_in2  = 'match2/test/unit_test/UDPRN_lat_lon.parquet'
P02_2_dt_out1 = 'match2/test/unit_test/process/to_de.csv'
P02_2_dt_out2 = '/data/griffin/test/unit_test'

# P03
_03_ip_in1  = 'match2/test/unit_test/ip.parquet'
_03_ip_out1 = 'match2/test/unit_test/output/ip/process/ip_publishers.parquet'

# P04_1
P04_1_de_in1  = 'match2/test/unit_test/from_de.csv'
P04_1_de_out1 = 'match2/test/unit_test/output/de/process/tmp.parquet'
P04_1_de_out2 = 'match2/test/unit_test/output/de/process/de01.parquet'

# P04_2
P04_2_de_in1  = 'match2/test/unit_test/output/de/process/de01.parquet'
P04_2_de_out1 = 'match2/test/unit_test/output/de/process/de01_long.parquet'

# P05
_05_de_in1  = 'match2/test/unit_test/output/de/process/de01_long.parquet'
_05_de_out1 = 'match2/test/unit_test/output/ip/process/ip_de.parquet'

# P06
_06_ip_in1  = 'match2/test/unit_test/IP_Address_Data_Output_20221003.csv'
_06_ip_out1 = 'match2/test/unit_test/output/ip/process/ip_cv.parquet'

# P07
_07_ip_in1  = 'match2/test/unit_test/output/ip/process/ip_publishers.parquet'
_07_ip_in2  = 'match2/test/unit_test/output/ip/process/ip_de.parquet'
_07_ip_in3  = 'match2/test/unit_test/output/ip/process/ip_cv.parquet'
_07_ip_out1 = 'match2/test/unit_test/output/ip/process/ip_all_agg.parquet'

# P07_2
P07_2_ip_in1  = 'match2/test/unit_test/master_optouts_cip_backlog_2022-12-12.parquet'
P07_2_ip_in2  = 'match2/test/unit_test/output/ip/process/ip_all_agg.parquet'
P07_2_ip_out1 = 'match2/test/unit_test/output/ip/process/ip_all_agg_sup.parquet'

# P08
P08_ip_in1     = '/user/unity/match2/test/unit_test/output/ip/process/ip_all_agg_sup.parquet'
P08_ip_out1    = '/user/unity/match2/test/unit_test/output/ip/process/to_de.csv'
P08_ip_out2    = '/data/griffin/test_unit'

# P09
_09_id_in1  = 'match2/test/unit_test/from_id5.parquet'
_09_id_out1 = 'match2/test/unit_test/output/id5/process/id5.parquet'

# P10
_10_join_in1= 'match2/test/unit_test/output/de/process/de01_long.parquet'
_10_join_in2= 'match2/test/unit_test/output/id5/process/id5.parquet'
_10_join_out1= 'match2/test/unit_test/output/join/agg_x03.parquet'

# P11
_11_mc_in1= 'match2/test/unit_test/MC.csv'
_11_dt_in2= 'match2/test/unit_test/output/Digital_taxonomy/process/Digital_taxonomy.parquet'
_11_mc_out1= 'match2/test/unit_test/output/Digital_taxonomy/mc.parquet'
_11_dt_out2= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_mc.parquet'

# P12
_12_dt_in1= 'match2/test/unit_test/output/Digital_taxonomy/process/Digital_taxonomy.parquet'
_12_dt_in2= 'match2/test/unit_test/output/Digital_taxonomy/mc.parquet'
_12_dt_in3= '/data/griffin/taxonomy/S_Code.csv'
_12_dt_out1= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_cb_key_hh.parquet'
_12_dt_out2= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_cb_key_hh_2.parquet'
_12_dt_out3= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_cb_key_hh_dd.parquet'
_12_dt_out4= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_mc.parquet'
_12_dt_out5= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_mc_dd.parquet'
_12_dt_out6= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_dd.parquet'
_12_dt_out7= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_mc_dd_ss.parquet'

# P14
_14_join_in1= 'match2/test/unit_test/output/Digital_taxonomy/mc.parquet'
_14_join_in2= 'match2/test/unit_test/output/join/agg_x03.parquet'
_14_join_out1= 'match2/test/unit_test/output/join/mc02.parquet'
_14_join_out2= 'match2/test/unit_test/output/join/MC_UID.parquet'

# P15
_15_join_in1= 'match2/test/unit_test/output/join/MC_UID.parquet'
_15_join_in2= 'match2/test/unit_test/output/Digital_taxonomy/process/dt_long_mc_dd_ss.parquet'
_15_join_out1= 'match2/test/unit_test/output/join/UID_Tax.parquet'

# P16
_16_dt_in1  = '/data/griffin/taxonomy/S_CODE_PUBMATIC.csv'
_16_dt_in2  = 'match2/test/unit_test/output/join/UID_Tax.parquet'
_16_dt_out1 = '/user/unity/datascience/match2/Digital_taxonomy/process/pubmatic.csv'
_16_dt_out2 = '/data/griffin/getmerge/temp.csv'
_16_dt_out3 = '/data/griffin/getmerge/pubmatic.tsv'

