# P01_Digital_Taxonomy_parquet.py
_01_dt_in1  = 'datascience/match2/ingest/Digital_taxonomy.csv'
_01_dt_out1 = 'datascience/match2/Digital_taxonomy/process/Digital_taxonomy.parquet'

# P01_2_Stats for Taxon
_01_Stats_in1= 'datascience/match2/Digital_taxonomy/process/Digital_taxonomy.parquet'

# P02_UDPRN_Lat_Lon
_02_dt_in1  = 'datascience/match2/Digital_taxonomy/process/Digital_taxonomy.parquet' 
_02_dt_in2  = 'datascience/match2/lat_lon/UDPRN_lat_lon.parquet'
_02_dt_out1 = 'datascience/match2/lat_lon/process/cb_key_lat_lon.parquet'
_02_dt_out2 = '/data/griffin/for_STS/to_de.csv'

# P03_IPs_publishers
_03_ip_in1  = 'v2/central_backlog/*/2024-11-12/preprocessed_data.parquet'
_03_ip_out1 = 'datascience/match2/ip/process/ip_providers.parquet'

# P04_DE_process
_04_de_in1  = 'datascience/match2/ingest/from_de.csv'
_04_de_out1 = 'datascience/match2/de/process/tmp.parquet'
_04_de_out2 = 'datascience/match2/de/process/de01.parquet'
_04_de_out3 = 'datascience/match2/de/process/de01_long.parquet'

# P05_IPs_DE
_05_de_in1  = 'datascience/match2/de/process/de01_long.parquet'
_05_de_out1 = 'datascience/match2/ip/process/ip_de.parquet'

# P06_IPs_CV
_06_ip_in1  = 'v2/monthly_cv/IP_Address_Data_Output_20221003.csv'
_06_ip_out1 = 'datascience/match2/ip/process/ip_cv.parquet'

# P07_IPs_all
_07_ip_in1  = 'datascience/match2/ip/process/ip_providers.parquet'
_07_ip_in2  = 'datascience/match2/ip/process/ip_de.parquet'
_07_ip_in3  = 'datascience/match2/ip/process/ip_cv.parquet'
_07_ip_out1 = 'datascience/match2/ip/process/ip_all_agg.parquet'

# P08_IP_list
_08_ip_in1  = 'datascience/match2/ip/process/ip_all_agg.parquet'
_08_ip_out1 = 'datascience/match2/ip/process/ip_list.parquet'
_08_ip_out2 = '/data/griffin/for_STS/to_id5.csv'

# P09_ID5_Ingest