
import os
import sys
import datetime
import sys
from pathlib import Path

parent_dir = str(Path(__file__).resolve().parents[2])

from config_process import *
from process_functions import *

EMAIL_TO = "emsactivatealerts@experian.com"
LOG_DIR = f"{parent_dir}/logs"

#- RUN LOGIC --------------------------------------------------------------------------

if process_run== 3:
    base= os.path.join(base, 'quick_run')


#- FIND LATEST VERSIONS OF FILES ------------------------------------------------------

if path_tax == '':
    path_tax = latest_file(os.path.join(base, 'taxonomy'), '202')

path_udprn  = latest_file(os.path.join(base, 'udprn'), '202')
#path_mc     = latest_file(os.path.join(base, 'mc'), '202')

file_cv         = latest_file(cv_path, 'IP_Address_Data_Output_')
file_nmr        = latest_file(nmr_path, 'A16.')
file_pub_cip    = latest_file(pub_cip_path, 'master_optouts_cip_backlog')


#- SET WEEK START DATES -------------------------------------------------------------

if bweek == '':
    bweek= last_Monday()

if nweek == '':
    nweek= next_Monday()


lweek= datetime.datetime.strptime(bweek, "%Y-%m-%d")-datetime.timedelta(days= 7)
lweek= lweek.strftime("%Y-%m-%d")


#- PATHS ------------------------------------------------------------------------------

# P010_1_Digital_Taxonomy_Ingest.py
P010_1_dt_in1  = os.path.join(path_tax, '*_Digital_taxonomy.txt')
P010_1_dt_out1 = os.path.join(path_tax, 'process', 'taxonomy.parquet')

# P010_2_Taxonomy_Process.py
P010_2_dt_in1  = os.path.join(path_tax, 'process', 'taxonomy.parquet')
P010_2_dt_in3  = '/data/griffin/S_Code.csv'
P010_2_dt_out1 = os.path.join(path_tax, 'process', 'dt_long_cb_key_hh.parquet')
P010_2_dt_out2 = os.path.join(path_tax, 'process', 'dt_long_cb_key_hh_2.parquet')
P010_2_dt_out3 = os.path.join(path_tax, 'process', 'S_Code_Dist.parquet')
P010_2_dt_out4 = os.path.join(path_tax, 'process', 'dt_long_cb_key_hh_s.parquet')

# P015_to_id5.py
# lweek= datetime.datetime.strptime(bweek, "%Y-%m-%d")-datetime.timedelta(days= 7)
# lweek= lweek.strftime("%Y-%m-%d")
P015_ip_in1  = os.path.join(base, '/user/unity/id_graph/uid', lweek, 'chv_mk2_180.parquet')
P015_ip_in2  = os.path.join(base, 'unacast', lweek, 'process', 'unacast_hh_ip_flags.parquet')
P015_ip_out1 = os.path.join(base, 'id5', bweek, 'to_id5.csv')
P015_ip_out2 = '/data/data_to_sts/temp'

# P020_1_Taxonomy_Suppression.py
P020_1_dt_in1  = file_nmr
P020_1_dt_in2  = os.path.join(path_tax, 'process', 'taxonomy.parquet')
P020_1_dt_out1 = os.path.join(base, 'process', bweek, 'taxonomy_suppress.parquet')

# P020_2
P020_2_dt_in1  = os.path.join(base, 'process', bweek, 'taxonomy_suppress.parquet')
P020_2_dt_in2  = os.path.join(path_udprn, 'udprn_lat_lon.parquet')
P020_2_dt_out1 = os.path.join(base, 'de', bweek, 'to_de.csv')
P020_2_dt_out2 = '/data/data_to_sts/temp'

# P024_UC_Remove_Optouts.py
P024_un_in1  = os.path.join(base, 'unacast')
P024_un_in2  = os.path.join(base, 'unacast', lweek, 'process', 'unacast_optouts_combined.parquet')
P024_un_out1 = os.path.join(base, 'unacast', bweek, 'process', 'unacast_optouts_combined.parquet')


# P025_UC_Preprocess.py
P025_un_in1  = os.path.join(base, 'unacast')
P025_un_in2  = os.path.join(P025_un_in1, "20*","process")
P025_u_in2   = os.path.join(path_udprn, 'udprn_lat_lon.parquet')
P025_cv_in3  = file_cv
P025_pub_in4 = '/user/unity/v2/central_backlog/*/*/preprocessed_data.parquet'
P025_cp_in5  = file_pub_cip
P025_tax_in6 = f'{base}/process/{bweek}/taxonomy_suppress.parquet'
P025_aud_in7 = "/user/unity/id_graph/audigent"
P025_un_out1     = os.path.join(base, 'unacast', bweek, 'process', 'unacast.parquet')
P025_un_out2     = os.path.join(base, 'unacast', bweek, 'process', 'una06_8.parquet')
P025_un_out3     = os.path.join(base, 'unacast', bweek, 'process', 'uc_lat_lon.parquet')
P025_un_out3_2   = os.path.join(base, 'unacast', bweek, 'process', 'udprn_lat_lon.parquet')
P025_un_out4     = os.path.join(base, 'unacast', bweek, 'process', 'y01.parquet')
P025_un_out5     = os.path.join(base, 'unacast', bweek, 'process', 'y02.parquet')
P025_un_out6     = os.path.join(base, 'unacast', bweek, 'process', 'm1.parquet')
P025_un_out6_2   = os.path.join(base, 'unacast', bweek, 'process', 'm1_05.parquet')
P025_un_out7     = os.path.join(base, 'unacast', bweek, 'process', 'unacast_hh_ip.parquet')
P025_un_out8     = os.path.join(base, 'unacast', bweek, 'process', 'unacast_hh_ip_flags.parquet')

# P030_1
P030_1_de_in1  = os.path.join(base, 'de', bweek, 'from_de*.csv*')
P030_1_de_out1 = os.path.join(base, 'process', bweek, 'temp.parquet')
P030_1_de_out2 = os.path.join(base, 'process', bweek, 'de01.parquet')

# P030_2B
P030_2B_de_in1  = os.path.join(base, 'process', bweek, 'de01.parquet')
P030_2B_de_out1 = os.path.join(base, 'process', bweek, 'de01_long.parquet')

# P35_1 Add CB_KEY_HOUSEHOLD
P035_1_dt_in1   = os.path.join(base, 'process', bweek, 'taxonomy_suppress.parquet')
P035_1_de_in2   = os.path.join(base, 'process', bweek, 'de01_long.parquet')
P035_1_de_out1  = os.path.join(base, 'process', bweek, 'DE_cb_key.parquet')

# P35_2 Add ChV match flag
P035_2_cv_in1   = file_cv
P035_2_de_in2   = os.path.join(base, 'process', bweek, 'DE_cb_key.parquet')
P035_2_de_out1  = os.path.join(base, 'process', bweek, 'DE_flag_chv.parquet')

# P35_3_1 Add Publisher IP match flag
P035_3_pub_in1  = '/user/unity/v2/central_backlog/*/*/preprocessed_data.parquet'
P035_3_de_in2   = os.path.join(base, 'process', bweek, 'DE_flag_chv.parquet')
P035_3_ci_in3   = file_pub_cip
P035_3_de_out1  = os.path.join(base, 'process', bweek, 'DE_flag_chv_pubip_temp.parquet')

# P35_3_2 Add Audigent Flag
P035_3_2_in1    = "/user/unity/id_graph/audigent"
P035_3_2_in2    = f'/user/unity/match2/process/{bweek}/DE_flag_chv_pubip_temp.parquet'
P035_3_2_out1   = '/user/unity/temp/temp_audigent.parquet'
P035_3_2_out2   = f'/user/unity/match2/process/{bweek}/DE_flag_chv_pubip.parquet'
P035_3_2_out3 = f"/data/griffin/quick_stats/P035_3_2"

# P35_4 Split file into keep and delete
P035_4_de_in1   = os.path.join(base, 'process', bweek, 'DE_flag_chv_pubip.parquet')
P035_4_ci_in2   = file_pub_cip
P035_4_de_out1  = os.path.join(base, 'process', bweek, 'DE_rows_for_deletion.parquet')
P035_4_de_out2  = os.path.join(base, 'process', bweek, 'DE_rows_to_keep.parquet')

# P36_1B Make ChV MK2
P036_1B_de_in1   = os.path.join(base, 'process', bweek, 'DE_rows_to_keep.parquet')
P036_1B_cv_in2   = file_cv
# P036_1_ci_in3   = file_pub_cip
P036_1B_uc_in1 = os.path.join(base, 'unacast', bweek, 'process', 'unacast_hh_ip_flags.parquet')
P036_1B_uc_in2 = os.path.join(base, 'unacast', lweek, 'process', 'unacast_hh_ip_flags.parquet')
P036_1B_cv_out1  = os.path.join(base, 'process', bweek, 'temp1_chv_mk2.parquet')
P036_1B_cv_out2  = os.path.join(base, 'process', bweek, 'chv_mk2.parquet')

# P040 Ingest ID5
P040_id_in1  = os.path.join(base, 'id5', bweek, 'from_id5*.parquet')
P040_0_id_in1  = "/user/unity/v2/helper_data_central/global_cmp_list.json"
P040_0_id_out1 = os.path.join(base, 'id5', bweek, f'id5_with_consent_{bweek}.parquet')
P040_0_id_out2 = os.path.join(base, 'id5', bweek, f'id5_without_consent_{bweek}.parquet')
P040_id_out1 = os.path.join(base, 'process', bweek, 'id5.parquet')
P040_id_out2 = os.path.join(base, 'process', bweek, 'id5_maids.parquet')
P040_id_out3 = os.path.join(base, 'process', bweek, 'id5_appnexusids.parquet')
P040_id_out4 = os.path.join(base, 'process', bweek, 'id5_ttdids.parquet')

# P050_1_Merge_ID5_DE.py
P050_1_mk1_in1     = os.path.join(base, 'process', bweek, 'chv_mk2.parquet')
P050_1_id5_in2     = os.path.join(base, 'process', bweek, 'id5.parquet')
P050_1_join_out1   = os.path.join(base, 'process', bweek, 'uid_hh.parquet')
P050_1_uid_out2    = os.path.join(base, 'process', bweek, 'uid_hh_dd.parquet')

# P050_2
#P050_2_join_in1 = os.path.join(base, 'process', bweek, 'de_cb_key.parquet')
#P050_2_join_in2 = os.path.join(base, 'process', bweek, 'id5.parquet')
#P050_2_join_out1= os.path.join(base, 'process', bweek, 'agg_x03.parquet')

# P050_3_UID_S_Code.py
P050_3_tax_in1  = os.path.join(path_tax, 'process', 'taxonomy.parquet')
P050_3_tax_in2  = os.path.join(path_tax, 'process', 'dt_long_cb_key_hh_s.parquet')
P050_3_uid_in3  = os.path.join(base, 'process', bweek, 'uid_hh_dd.parquet')
P050_3_seg_in4  = os.path.join(path_tax, 'process', 'S_Code_Dist.parquet')
P050_3_uid_out1 = os.path.join(base, 'process', bweek, 'uid_hh_pp.parquet')
P050_3_uid_out2 = os.path.join(base, 'process', bweek, 'uid_hh_pp_s_code.parquet')
P050_3_uid_out3 = os.path.join(base, 'process', bweek, 'uid_S_Code_initial.parquet')
P050_3_uid_out4 = os.path.join(base, 'process', bweek, 'uid_S_Code.parquet')
P050_3_uid_out5 = os.path.join(base, 'process', bweek, 'uid_s_code_cal.parquet')

# P051_1 Merge MAIDS DE
P051_1_md_in1  = f'/user/unity/match2/process/{bweek}/id5_maids.parquet'
P051_1_cv_in2  = f'/user/unity/id_graph/uid/{bweek}/chv_mk2_180.parquet'
P051_1_md_out1 = f'/user/unity/match2/process/{bweek}/maids_hh.parquet'

# P051_3 MAIDS S_Code
P051_3_md_in1   = f'/user/unity/match2/process/{bweek}/maids_hh.parquet'
P051_3_tx_in2   = os.path.join(path_tax, 'process', 'dt_long_cb_key_hh_s.parquet')
P051_3_md_out1  = f'/user/unity/match2/process/{bweek}/maids_s_code_cal.parquet'

# P052_1_ChV_S_Code.py
P052_1_cv_in1    = os.path.join(base, 'process', bweek, 'chv_mk2.parquet')
P052_1_tx_in2    = os.path.join(path_tax, 'process', 'dt_long_cb_key_hh_s.parquet')
P052_1_cv_out1   = os.path.join(base, 'process', bweek, 'chv_s_code_cal.parquet')

# P060
P060_join_in1   = os.path.join(base, 'process', bweek, 'MC_UID.parquet')
P060_join_in2   = os.path.join(base, 'process', bweek, 'dt_long_mc_dd_ss.parquet')
P060_join_out1  = os.path.join(base, 'process', bweek, 'UID_Tax.parquet')

# P070_Pubmatic
P070_uid_in1    = os.path.join(base, 'process', bweek, 'uid_s_code_cal.parquet')
P070_pub_in2    = '/data/griffin/S_CODE_PUBMATIC.csv'
P070_md_in3     = os.path.join(base, 'process', bweek, 'maids_s_code_cal.parquet')
P070_ip_in4     = os.path.join(base, 'process', bweek, 'chv_s_code_cal.parquet')
P070_id5_in5    = os.path.join(base, 'process', bweek, 'id5.parquet')
P070_md_in6     = os.path.join(base, 'process', bweek, 'id5_maids.parquet')
P070_pub_out1   = os.path.join(base, 'process', bweek, 'uid_s_code_pub.parquet')
P070_pub_out2   = os.path.join(base, 'process', bweek, 'maids_s_code_pub.parquet')
P070_pub_out3   = os.path.join(base, 'process', bweek, 'chv_s_code_pub.parquet')
P070_pub_out4   = os.path.join(base, 'marketplaces', 'pubmatic', bweek, 'pubmatic.parquet')

#P070_pub_out3   = os.path.join(base, 'marketplaces', 'pubmatic', bweek, 'pubmatic.csv')
#P070_pub_out4   = '/data/data_to_sts/temp/for_pubmatic.tsv'

# P075 Pubmatic Backup
P075_pub_path   = '/user/unity/match2/marketplaces/pubmatic'
P075_pub_out1   = os.path.join(base, 'process', bweek, 'uid_s_code_pub_all2.parquet')
P075_pub_out2   = os.path.join(base, 'process', bweek, 'uid_s_code_pub_all.parquet')
P075_pub_out3   = os.path.join(base, 'marketplaces', 'pubmatic', bweek, 'pubmatic.csv')
P075_pub_out4   = '/data/data_to_sts/temp/for_pubmatic.tsv'

# P070_1_Optimize_UID_S_Code
# P070_tax_in1    = os.path.join(base, 'process', bweek, 'uid_S_Code.parquet')
# P070_tax_out1   = os.path.join(base, 'process', bweek, 'uid_lookup.parquet')
# P070_tax_out2   = os.path.join(base, 'process', bweek, 'uid2_s_code.parquet')
# P070_tax_out3   = os.path.join(base, 'process', bweek, 'uid2_s_code2.parquet')

# P080_1
P080_1_ip_in1  =   'v2/central_backlog/*/*/preprocessed_data.parquet'
P080_1_ip_out1 =   os.path.join(base, 'process', bweek, 'ip_publishers.parquet')

# P080_2
P080_2_de_in1  = os.path.join(base, 'process', bweek, 'de01_long.parquet')
P080_2_de_out1 = os.path.join(base, 'process', bweek, 'ip_de.parquet')

# P080_3
P080_3_ip_in1     = file_cv
P080_3_ip_out1    = os.path.join(base, 'process', bweek, 'ip_cv.parquet')

# P080_4
P080_4_ip_in1  = os.path.join(base, 'process', bweek, 'ip_publishers.parquet')
P080_4_ip_in2  = os.path.join(base, 'process', bweek, 'ip_de.parquet')
P080_4_ip_in3  = os.path.join(base, 'process', bweek, 'ip_cv.parquet')
P080_4_ip_out1 = os.path.join(base, 'process', bweek, 'ip_all_agg.parquet')

# P080_5
P080_5_ip_in1  = file_pub_cip
P080_5_ip_in2  = os.path.join(base, 'process', bweek, 'ip_all_agg.parquet')
P080_5_ip_out1 = os.path.join(base, 'process', bweek, 'ip_all_agg_sup.parquet')

# P080_6
P080_6_ip_in1     = os.path.join(base, 'process', bweek, 'ip_all_agg_sup.parquet')
P080_6_ip_out1    = os.path.join(base, 'process', bweek, 'to_id5.csv')
P080_6_ip_out2    = '/data/data_to_sts/temp'




