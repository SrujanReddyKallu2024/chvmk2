
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession

#-----------------------------------------------
os.environ['PYSPARK_PYTHON'] = "./venv/bin/python3"
scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 
      

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

###################################################################



# Settings ------------------------------------------------------------------------------
script_code= 'P040_0' # For 'Quick Stats'
email_subject= '*** P040_0: INGEST ID5 FILE AND DECODE TCF ***'
tcf_col_name="consent_string" # add column name for tcf


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()
address_dict['id_in1']  = P040_id_in1
address_dict['id_in2']  = P040_0_id_in1
address_dict['id_out1'] = P040_0_id_out1
address_dict['id_out2'] = P040_0_id_out2
address_dict


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read parquet'
proc[2] =   'Check columns exist'
proc[3] =   'Filter invalid TCF consent strings'
proc[4] =   'Write parquets'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Number of Rows'
stats_name['2']= 'Number of IPs:'
stats_name['3']= 'Number of UIDs:'
stats_name['4']= 'Valid Records:'
stats_name['5']= 'TCF Optouts:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2,df3):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('ip').count().count()
    stats['3']= df1.groupby('uid').count().count()
    stats['4']= df2.count()
    stats['5']= df3.count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read raw id5 data
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        id01= spark.read.parquet(address_dict['id_in1'])
        #---------------------------------------------------------------------------------------------------
    #
    # Check columns
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        id02= id01.select('ip', 'household', 'uid', 'type_uid', 'timestamp', tcf_col_name)            
        #---------------------------------------------------------------------------------------------------
    #
    # Filter out tcf optouts
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        valid_cmpid_list = parse_cmpid_list(spark, address_dict['id_in2'])
        vl_broadcast = spark.sparkContext.broadcast(valid_cmpid_list)
        id02_with_maids = id02.where(F.col('type_uid').isin(['android','ios'])).withColumn("tcf_consent", F.lit('NA'))       
        id02_initial = parse_tcf(id02, tcf_col_name).cache()
        id02_initial.count()
        id02_with_check= identify_invalid_tcf(id02_initial, vl_broadcast.value)
        id02a= id02_with_check.union(id02_with_maids.select(id02_with_check.columns)).where(F.col('tcf_consent') != '0').cache()
        id02b= id02_with_check.where(F.col('tcf_consent') == '0').cache()
        # check if id02b count is more than 1% of original count
        if id02b.count() > 0.01*id02.count():
            body= f"{proc[3]}: TCF optouts are more than 1% of total records"
            email_subject = f"*** P040_0: *** - TCF optouts more than 1%"
            email_process(body, email_subject)
        #---------------------------------------------------------------------------------------------------
    #
    # Write parquet
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        id02a.write.parquet(address_dict['id_out1'], mode= 'overwrite')        
        #
        # id02b.write.parquet(address_dict['id_out2'], mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    #
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(id01,id02a,id02b)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)



