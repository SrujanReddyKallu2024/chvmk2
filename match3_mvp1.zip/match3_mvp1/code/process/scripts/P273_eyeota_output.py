
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps

import math

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 



# Settings ------------------------------------------------------------------------------
script_code= 'P273' # For 'Quick Stats'
email_subject= '*** P273: Eyeota Output ***'

org_name= 'experian'
org_id= 'r89cb20'
today= datetime.datetime.today().strftime('%Y%m%d')
counter= 0


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['in1_eye'] = f'/user/unity/match2/marketplaces/eyeota/{bweek}/for_eyeota.parquet'
#address_dict['in2_eye'] ='/user/unity/match2/marketplaces/eyeota/counter.csv'
# Output
address_dict['out1_eye'] = f'/user/unity/match2/marketplaces/eyeota/{bweek}/for_eyeota.csv'
address_dict['out2_eye'] = '/data/data_to_sts/temp/eyeota'
address_dict['out3_eye'] = f"{address_dict['out2_eye']}/for_eyeota.csv"


# Input Test
#address_dict['in1_eye'] = f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/{bweek}/for_eyeota.parquet'
#address_dict['in2_eye'] = '/user/unity/datascience/griffin/match2/marketplaces/eyeota/counter.csv'
# Output test
#address_dict['out1_eye'] = f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/{bweek}/for_eyeota.csv'
#address_dict['out2_eye'] = '/data/data_to_sts/temp/eyeota'
#address_dict['out3_eye'] = f"{address_dict['out2_eye']}/for_eyeota.csv"

# List of addresses to clean ------------------------------------------------------------
address_clean= []


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Find necessary number of partitions and output'
proc[3] =   'Output to local and rename'
proc[4] =   'Read in partitions to find number of rows in the individual parts'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= "Input: Number of rows:"
stats_name['2']= "Input: Number of ID5s:"
stats_name['3']= 'Number of parts:'
stats_name['4']= 'Number of parts in local:'
stats_name['5']= 'Max number of rows in a part:'
stats_name['6']= 'Min number of rows in a part:'
stats_name['7']= 'Mean number of rows in the parts:'
stats_name['8']= 'Std of number of rows in the parts:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,int1,int2,int3,int4,int5,int6):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('ID5').count().count()
    stats['3']= int1
    stats['4']= int2
    stats['5']= int3
    stats['6']= int4
    stats['7']= int5
    stats['8']= int6
    return stats
    


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read in files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        i01= spark.read.parquet(address_dict['in1_eye'])
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        row_count= i01.count()
        parts= math.ceil(row_count/ 1000000)
        #
        i01.repartition(parts).write.csv(address_dict['out1_eye'], header= False, sep= '|', compression= 'gzip', mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        # Output to local
        os.system(f"hdfs dfs -get {address_dict['out1_eye']} {address_dict['out2_eye']}")
        #
        #Get list of files from local
        lst= list_files_local(address_dict['out3_eye'], pattern='part-')
        lst_count= len(lst)
        #
        for count,x in enumerate(lst):
            sequence= str(count+counter+1).zfill(5)
            os.system(f"mv {address_dict['out3_eye']}/{x} {address_dict['out2_eye']}/{org_name}_{org_id}_{today}-{sequence}.csv.gz")
        #
        os.system(f"rm -r {address_dict['out3_eye']}")
        #---------------------------------------------------------------------------------------------------
    #
    # Read back in to calculate partition row counts
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        all_parts1= spark.read.csv(address_dict['out1_eye'])
        all_parts2= all_parts1.withColumn('partID', F.spark_partition_id()).groupby('partID').count()
        #
        all_parts3= all_parts2.agg(
            F.max('count').alias('max_rows'), \
            F.min('count').alias('min_rows'), \
            F.round(F.mean('count'),2).alias('mean_rows'), \
            F.round(F.stddev('count'),2).alias('std_rows')
        )
        all_parts4= all_parts3.collect()
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(i01, parts, lst_count, all_parts4[0]['max_rows'], all_parts4[0]['min_rows'], all_parts4[0]['mean_rows'], all_parts4[0]['std_rows'])
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)

