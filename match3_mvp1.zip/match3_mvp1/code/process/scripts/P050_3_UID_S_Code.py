import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#tax_in1= 'match2/taxonomy/2023-08-07/process/taxonomy.parquet'
#tax_in2= 'match2/taxonomy/2023-08-07/process/dt_long_cb_key_hh_s.parquet'
#uid_in3= 'match2/process/2023-08-28/uid_hh_dd.parquet'
#seg_in4= 'match2/taxonomy/2023-08-07/process/S_Code_Dist.parquet'
#uid_out1= 'match2/process/2023-08-28/uid_hh_pp.parquet'
#uid_out2= 'match2/process/2023-08-28/uid_hh_pp_s_code.parquet'
#uid_out3= 'match2/process/2023-08-28/uid_S_Code_initial.parquet'
#uid_out4= 'match2/process/2023-08-28/uid_S_Code.parquet'
#uid_out5= 'match2/process/2023-08-28/uid_s_code_cal.parquet'

tax_in1     = P050_3_tax_in1
tax_in2     = P050_3_tax_in2
uid_in3     = P050_3_uid_in3
seg_in4     = P050_3_seg_in4
uid_out1    = P050_3_uid_out1
uid_out2    = P050_3_uid_out2
uid_out3    = P050_3_uid_out3
uid_out4    = P050_3_uid_out4
uid_out5    = P050_3_uid_out5



email_subject= '*** P050_3: Create UID & Segment File ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n tax_in1 = {tax_in1}"
result= f"{result}\n\n tax_in2 = {tax_in2}"
result= f"{result}\n\n uid_in3 = {uid_in3}"
result= f"{result}\n\n seg_in4 = {seg_in4 }"
result= f"{result}\n\n uid_out1 = {uid_out1}"
result= f"{result}\n\n uid_out2 = {uid_out2}"
result= f"{result}\n\n uid_out3 = {uid_out3}"
result= f"{result}\n\n uid_out4 = {uid_out4}"
result= f"{result}\n\n uid_out5 = {uid_out5}"

##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Create UID Person Counts'
proc[3]= 'Join UIDs & Segments'
proc[4]= 'Dedup UIDs & Segments Combos'
proc[5]= 'Join on UID Person Counts'
proc[6]= 'Calibration'



#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        tax01= spark.read.parquet(tax_in1).select('cb_key_household', 'cb_key_db_person')
        hhs01= spark.read.parquet(tax_in2)
        j03= spark.read.parquet(uid_in3)
        S_Code_Dist= spark.read.parquet(seg_in4)
        S_Code= pd.read_csv('/data/griffin/S_Code.csv')
        ###
        ###
        # Make proxy version of j03 ---------------------------------------------
        #.Make new filenames --------------------------------------
        uid_in3_2= f'{os.path.dirname(uid_in3)}/uid_hh_dd_proxy.parquet'
        file_lucb= f'{os.path.dirname(uid_in3)}/lu102.parquet'
        file_luud= f'{os.path.dirname(uid_in3)}/lu202.parquet'
        uid_out4_2= f'{os.path.dirname(uid_in3)}/uid_s_code_cal_proxy.parquet'
        ###
        ###
        lu101= j03.groupby('cb_key_household').count().drop('count')
        lu101.cache()
        lu101.count()
        #
        w1= Window().orderBy('cb_key_household')
        lu102= lu101.withColumn('cb_key2',F.row_number().over(w1))
        lu102.write.parquet(file_lucb, mode= 'overwrite')
        lu103= spark.read.parquet(file_lucb)
        lu101.unpersist()
        ###
        ###
        lu201= j03.groupby('uid').count().drop('count')
        lu201.cache()
        lu201.count()
        #
        w2= Window().orderBy('uid')
        lu202= lu201.withColumn('uid2',F.row_number().over(w2))
        lu202.write.parquet(file_luud, mode= 'overwrite')
        lu203= spark.read.parquet(file_luud)
        lu201.unpersist()
        ###
        ###
        temp1= j03.join(lu103, 'cb_key_household', 'inner').drop('cb_key_household')
        temp2= temp1.join(lu203, 'uid', 'inner').drop('uid')
        temp2.write.parquet(uid_in3_2, mode= 'overwrite')
        j03_proxy= spark.read.parquet(uid_in3_2)
        #---------------------------------------------------------------------------------------------------
    
    # Create UID Person Counts
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        tax02= tax01.groupBy('cb_key_household').count().withColumnRenamed('count', 'PP_Total')
        # Join on proxy
        tax02= tax02.join(lu103, 'cb_key_household', 'inner').drop('cb_key_household')
        #
        uid_hh_pp= j03_proxy.join(tax02,'cb_key2', 'inner')
        uid_hh_pp2= uid_hh_pp.groupby('uid2').agg(F.sum('PP_Total').alias('PP_Total'))
        uid_hh_pp2.write.parquet(uid_out1, mode= 'overwrite')
        uid_hh_pp3= spark.read.parquet(uid_out1)
        #uid_hh_pp3.show()
        #---------------------------------------------------------------------------------------------------
        
    # Create flag
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        #Join on Proxy
        hhs01= hhs01.join(lu103, 'cb_key_household', 'inner').drop('cb_key_household')
        #
        j04= hhs01.select('cb_key2', 'S_Code', 'PP').join(j03_proxy, 'cb_key2', 'inner')
        j05= j04.join(tax02, 'cb_key2', 'inner')
        
        j05.write.parquet(uid_out2, mode= 'overwrite')
        j05_2= spark.read.parquet(uid_out2)
        #---------------------------------------------------------------------------------------------------
        
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        j06= j05_2.groupby('uid2', 'S_Code').agg(F.sum('PP').alias('PP'))
        
        j06.write.parquet(uid_out3, mode= 'overwrite')
        j07= spark.read.parquet(uid_out3)
        #---------------------------------------------------------------------------------------------------
        
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        j08= j07.join(uid_hh_pp3, 'uid2', 'inner')
        j08.write.parquet(uid_out4, mode= 'overwrite')
        j09= spark.read.parquet(uid_out4)

    with doing_xy(process_num= 6):
        #---------------------------------------------------------------------------------------------------
        tax_count= tax01.count()
        x2= S_Code_Dist.withColumn('Nat_Ratio', F.col('adults')/tax_count).select('S_Code', 'Nat_Ratio')
        
        uid_count= j09.groupby('uid2').count().count()
        j10= j09.join(x2, 'S_Code', 'inner')
        j11= j10.where(F.col('PP')/F.col('PP_Total')>= F.col('PP_Total')/16)
        
        #y= j11.groupby('S_Code').count()
        
        #j11.where(F.col('S_Code')=='S126').count()
        #y= y.sort('S_Code')
        #y.show()
        
        #y2= x2.join(y, 'S_Code', 'left').withColumn('Nat_Ratio2', F.col('count')/ uid_count)
        #y2= y2.withColumn('Nat_Ratio2', F.when(F.col('Nat_ratio2').isNull(),0).otherwise(F.col('Nat_Ratio2')))
        #y3= y2.withColumn('error', F.pow(F.col('Nat_Ratio')- F.col('Nat_Ratio2'), 2))
        #y4= y3.agg(F.mean('error'))
        #y4.show(truncate= False)
        
        #y.count()
        #j11.groupby('uid').count().count()
        #j11.groupby('S_Code').count().count()
        #j11.count()
        #j09.count()
        #y3.show()
        #y4= y3.sort(F.col('error').desc())
        #y4.show(200)
        #y3.show()
        #y3.count()
        #j11.show()
        #j11.count()
        
        #x= spark.read.parquet('match2/process/2023-08-07/uid_s_code.parquet')
        #x.show()
        
        j11_uq= j11.groupby('uid2').count().drop('count')
        j09_uq= j09.groupby('uid2').count().drop('count')
        
        miss01= j09_uq.join(j11_uq, 'uid2', 'left_anti')
        #miss01.count()
        #miss01.show()
        
        miss02= j10.join(miss01, 'uid2', 'inner')
        #miss02.count()
        #miss02.show()
        
        #check= j11.where((F.col('S_Code')== 'S9') | (F.col('S_Code')== 'S10'))
        #check2= check.groupby('uid').count()
        #check2.sort(F.col('count').desc()).show(truncate= False)
        
        #check2.where(F.col('count')>1).count()
        #check.where(F.col('uid')== 'ID5-0092S8sR3AZmvbtzDxLdyqAq0J0FFVnd7MpX2bY9BQ').show()
        #x2.where((F.col('S_Code')== 'S9') | (F.col('S_Code')== 'S10')).show()
        
        S_Code2= ps.from_pandas(S_Code)
        S_Code3= S_Code2.to_spark()
        S_Code4= S_Code3.withColumn('S_Code', F.regexp_replace('S_Code', r'^S[0]*', 'S'))
        #S_Code4.show()
        S_Code5= S_Code4.groupby('key').count().withColumnRenamed('count', 'C_Code_flag')
        #S_Code5.show()
        
        miss03= miss02.join(S_Code4, 'S_Code', 'inner')
        #miss03.count()
        #miss03.show()
        #miss03.groupby('uid').count().count()
        
        miss04= miss03.join(S_Code5, 'key', 'inner').cache()
        #miss04.count()
        
        miss05= miss04.where(F.col('C_Code_flag')> 1)
        #miss05.count()
        #miss05.groupby('uid').count().count()
        #miss05.show()
        
        lst= ["uid2", "key"]
        w1 = Window.partitionBy(lst).orderBy(F.col("PP").desc())
        miss06= miss05.withColumn("row",F.row_number().over(w1)).filter(F.col("row") == 1).drop("row")
        #miss06.count()
        #miss06
        #miss06.show()
        #miss07= miss06.sort('uid','key')
        #miss07.show()
        #miss07.groupby('uid').count().count()
        
        #j11.printSchema()
        
        # |-- S_Code: string (nullable = true)
        # |-- uid: string (nullable = true)
        # |-- PP: long (nullable = true)
        # |-- PP_Total: long (nullable = true)
        # |-- Nat_Ratio: double (nullable = true)
        
        miss08= miss06.select('S_Code', 'uid2', 'PP', 'PP_Total', 'Nat_Ratio')
        #miss08.show()
        
        all01= j11.union(miss08)
        
        #x2.show()
        
        all01.write.parquet(uid_out4_2, mode= 'overwrite')
        j12= spark.read.parquet(uid_out4_2)
        
        #j12.groupby('uid').count().count()
        #j12.groupby('S_Code').count().count()
        #j09.groupby('uid').count().count()
        #j12.show()
        
        #x=j12.where((F.col('S_Code')== 'S163') | (F.col('S_Code')== 'S164'))
        #x= x.sort('uid')
        #x.show(200, truncate= False)
        ###
        ###
        # Apply lookout to final file ------------------------------------------
        x01= lu203.join(j12, 'uid2', 'inner').drop('uid2')
        #x01.show()
        x01.write.parquet(uid_out5)
        #---------------------------------------------------------------------------------------------------
        
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P050_3_stats_prev
        
        stats_name['Tot']   = 'Total Number of Records:'
        stats_name['uid']   = 'Number of unique UIDs:'
        stats_name['code']  = 'Number of unique Segments:'
        #stats_name['IP1'] = 'Number of IPs to keep:'
        
        stats['Tot']    = j12.count()
        stats['uid']    = j12.groupby('uid2').count().count()
        stats['code']   = j12.groupby('S_Code').count().count()
        #stats['IP1'] = de_1.groupby('ip').count().count()
        
        stats_perc['Tot']   = round(stats['Tot']  / stats_prev['Tot'] - 1, 4)
        stats_perc['uid']    = round(stats['uid']   / stats_prev['uid'] - 1, 4)
        stats_perc['code']  = round(stats['code'] / stats_prev['code']- 1, 4)
        #stats_perc['IP1']    = round(stats['IP1'] / stats_prev['IP1']- 1, 4)
        
        stats_tl['Tot']= traffic_lights(stats_perc['Tot'])
        stats_tl['uid']= traffic_lights(stats_perc['uid'])
        stats_tl['code']= traffic_lights(stats_perc['code'])
        #stats_tl['IP1']= traffic_lights(stats_perc['IP1'])
        
        result= f"{result}\n\n{stats_tl['Tot']} {stats_name['Tot']} [{stats['Tot']: ,}] ({stats_perc['Tot']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['uid']} {stats_name['uid']} [{stats['uid']: ,}] ({stats_perc['uid']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['code']} {stats_name['code']} [{stats['code']: ,}] ({stats_perc['code']: 15.2%})"        
        #result= f"{result}\n\n{stats_tl['IP1']} {stats_name['IP1']} [{stats['IP1']: ,}] ({stats_perc['IP1']: 15.2%})"
        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except Exception as e:
        result= f"{result}\n\n{emoji['fail']} Stats failed {e}"
        email_process(result, email_subject)
    
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)
    raise

