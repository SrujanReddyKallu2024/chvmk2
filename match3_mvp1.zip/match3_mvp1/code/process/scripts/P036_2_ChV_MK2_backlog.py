
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps
from pyspark.sql.types import StringType, IntegerType

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 



# Settings ------------------------------------------------------------------------------
script_code= 'P036_2' # For 'Quick Stats'
email_subject= '*** P036_2: ChV MK2 Backlog ***'

# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['in1_chvmk2'] = f'/user/unity/match2/process/'
address_dict['in2_chv'] = file_cv
# Output
address_dict['out1_chvmk2'] = f'/user/unity/id_graph/uid/{bweek}/chv_mk2_180.parquet'
address_dict['out2_chvmk2'] = f'/user/unity/match2/process/{bweek}/chv_mk2_180.parquet'
address_dict['out3_chvmk2'] = f'/user/unity/id_graph/uid/{bweek}/chv_mk2_180_dd.parquet'
address_dict['out4_chvmk2'] = f'/user/unity/match2/process/{bweek}/chv_mk2_180_dd.parquet'

# # Input Test
# address_dict['in1_chvmk2'] = f'match2/process/'
# address_dict['in2_chv'] = file_cv
# # Output test
# address_dict['out1_chvmk2'] = f'/user/unity/datascience/griffin/id_graph/uid/{bweek}/chv_mk2_180.parquet'
# address_dict['out2_chvmk2'] = f'/user/unity/datascience/griffin/match2/process/{bweek}/chv_mk2_180.parquet'
# address_dict['out3_chvmk2'] = f'/user/unity/datascience/griffin/id_graph/uid/{bweek}/chv_mk2_180_dd.parquet'
# address_dict['out4_chvmk2'] = f'/user/unity/datascience/griffin/match2/process/{bweek}/chv_mk2_180_dd.parquet'


# List of addresses to clean ------------------------------------------------------------
address_clean= []


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Add latest Channelview'
proc[3] =   'Apply NMR & CIP'
proc[4] =   'Write 180 days to HDFS'
proc[5] =   'Write 180 dd days to HDFS'

# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= "Output: Number of rows:"
stats_name['2']= "Output: Number of HHs:"
stats_name['3']= 'Output: Number of IPs:'
stats_name['4']= 'Output: dd - Number of rows:'
stats_name['5']= 'Output: dd - Number of HHs:'
stats_name['6']= 'Output: dd - Number of IPs:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('cb_key_household').count().count()
    stats['3']= df1.groupby('ip').count().count()
    stats['4']= df2.count()
    stats['5']= df2.groupby('cb_key_household').count().count()
    stats['6']= df2.groupby('ip').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read in files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        today= datetime.date.today()
        today_180= today- datetime.timedelta(days= 180)
        today_180= today_180.strftime("%Y-%m-%d")
        #
        # Create list of dates
        bweek2= datetime.datetime.strptime(bweek, '%Y-%m-%d')
        list_dates= []
        for i in range(27):
            x= bweek2- datetime.timedelta(days= i*7)
            date= x.strftime('%Y-%m-%d')
            list_dates.append(date)
        
        #
        list_dates
        len(list_dates)
        #
        dates= "{"+','.join(list_dates)+"}"
        dates
        #
        chv_mk2_01= spark.read.parquet(f"{address_dict['in1_chvmk2']}/{dates}/chv_mk2.parquet")
        #
        cv01= spark.read.csv(address_dict['in2_chv'], header= True)
        #---------------------------------------------------------------------------------------------------
    #
    # Get counter
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        chv_mk2_02= chv_mk2_01.where(F.col('chv_de_flag')!= 'chv')
        #
        cv02= cv01.withColumnRenamed('ip_address', 'ip')
        #
        cv03= cv02.where(F.col('ip_date_of_capture')>= F.lit(today_180))
        #
        cv04= cv03.groupby('ip', 'cb_key_household').agg(F.min('ip_date_of_capture').alias('first_seen'), F.max('ip_date_of_capture').alias('last_seen'))
        #
        cv05= cv04 \
            .withColumn('ip_rank', F.lit(None).cast(IntegerType())) \
            .withColumn('ip_flag', F.lit(None).cast(StringType())) \
            .withColumn('flag_chv', F.lit(None).cast(StringType())) \
            .withColumn('flag_pubip', F.lit(None).cast(StringType())) \
            .withColumn('chv_de_flag', F.lit('chv'))
        #
        cv06= cv05.select('ip', 'cb_key_household', 'first_seen', 'last_seen', 'ip_rank', 'ip_flag', 'flag_chv', 'flag_pubip', 'chv_de_flag')
        #
        chv_mk2_03= chv_mk2_02.select(cv06.columns).union(cv06)
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        chv_mk2_04= nmr_apply(chv_mk2_03)
        chv_mk2_05= cip_apply(chv_mk2_04)
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        chv_mk2_06= chv_mk2_05.drop('ip_rank', 'ip_flag', 'flag_chv', 'flag_pubip')
        #
        chv_mk2_06.write.parquet(address_dict['out1_chvmk2'], mode= 'overwrite')
        chv_mk2_07= spark.read.parquet(address_dict['out1_chvmk2'])
        chv_mk2_07.write.parquet(address_dict['out2_chvmk2'], mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        chv_mk2_08= chv_mk2_07.groupby('cb_key_household', 'ip').agg(F.min('first_seen').alias('first_seen'), F.max('last_seen').alias('last_seen'))
        #
        chv_mk2_08.write.parquet(address_dict['out3_chvmk2'], mode= 'overwrite')
        chv_mk2_09= spark.read.parquet(address_dict['out3_chvmk2'])
        chv_mk2_09.write.parquet(address_dict['out4_chvmk2'], mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(chv_mk2_07, chv_mk2_09)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)


