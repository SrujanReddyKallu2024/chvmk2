
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 



# Settings ------------------------------------------------------------------------------
script_code= 'P270' # For 'Quick Stats'
email_subject= '*** P270: EYEOTA ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['in1_scodes']= '/data/marketplace_files/eyeota/standard/replace'
address_dict['in2_scodes_latest']= f"{address_dict['in1_scodes']}/{latest_file_local(address_dict['in1_scodes'], 'eyeota_standard_replace')}"
address_dict['in3_uid']= f'/user/unity/match2/process/{bweek}/uid_s_code_cal.parquet'

#Output
address_dict['out1_eye'] = f'/user/unity/match2/process/{bweek}/uid_s_code_eye.parquet'

# Output test
#address_dict['out1_eye'] = f'/user/unity/datascience/griffin/match2/process/{bweek}/uid_s_code_eye.parquet'


# List of addresses to clean ------------------------------------------------------------
address_clean= []


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Format and Subset S_Codes'
proc[3] =   'Join S_Code Subset to UIDs'
proc[4] =   'Write to HDFS'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= "Number of S_Codes with a 'Y':"
stats_name['2']= 'Number of rows in Input:'
stats_name['3']= 'Number of UIDs in Input:'
stats_name['4']= 'Number of S_Codes in Input:'
stats_name['5']= 'Number of rows in Output:'
stats_name['6']= 'Number of UIDs in Output:'
stats_name['7']= 'Number of S_Codes in Output:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2,df3):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df2.count()
    stats['3']= df2.groupby('uid').count().count()
    stats['4']= df2.groupby('S_Code').count().count()
    stats['5']= df3.count()
    stats['6']= df3.groupby('uid').count().count()
    stats['7']= df3.groupby('S_Code').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read in files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        scode01 = pd.read_csv(address_dict['in2_scodes_latest'])
        uid01   = spark.read.parquet(address_dict['in3_uid'])
        #---------------------------------------------------------------------------------------------------
    #
    # Format and Subset S_Codes
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        scode02= ps.from_pandas(scode01)
        scode03= scode02.to_spark()
        scode04= scode03.withColumn('s_code', F.regexp_replace('s_code', r'^S[0]*', 'S'))
        scode05= scode04.where(F.col('enabled')== 'Y')
        scode06= scode05.groupby('S_Code').count().drop('count')
        #
        #scode06= scode01[scode01["enabled"]== "Y"]
        #scode07= scode06['s_code'].tolist()
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        #j01= uid01.where(F.col('S_Code').isin(scode07))
        j01= uid01.join(F.broadcast(scode06), 's_code', 'inner')
        j02= j01.groupby('uid', 'S_Code').count().drop('count')
        #---------------------------------------------------------------------------------------------------
    #
    # Write out file
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        j02.write.parquet(address_dict['out1_eye'], mode= 'overwrite')
        j03= spark.read.parquet(address_dict['out1_eye'])
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(scode06,uid01,j03)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)



