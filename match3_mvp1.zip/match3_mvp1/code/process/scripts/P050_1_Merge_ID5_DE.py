
# MAKE MORE THAN ONE SCRIPT

import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#mk1_in1     = 'match2/process/2023-08-28/chv_mk2.parquet'
#id5_in2     = 'match2/process/2023-08-28/id5.parquet'
#join_out1   = 'match2/process/2023-08-28/uid_hh.parquet'
#uid_out2    = 'match2/process/2023-08-28/uid_hh_dd.parquet'

mk1_in1     = P050_1_mk1_in1
id5_in2     = P050_1_id5_in2
join_out1   = P050_1_join_out1
uid_out2    = P050_1_uid_out2


email_subject= '*** P050_1: Merge ID5 & ChV_MK2 ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n mk1_in1 = {mk1_in1}"
result= f"{result}\n\n id5_in2 = {id5_in2}"
result= f"{result}\n\n join_out1 = {join_out1}"
result= f"{result}\n\n uid_out2 = {uid_out2}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Merge ID5 & ChV_MK2'
proc[3]= 'Dedup IP & HH Combos'

#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        mk01= spark.read.parquet(mk1_in1)
        id01= spark.read.parquet(id5_in2)
        #dt08= spark.read.parquet(dt_in3)
        #---------------------------------------------------------------------------------------------------
    
    
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        # NEED TO ADD NEAREST DATE MATCHING FOR ID5 TO MK2
        #-------------------------------------------------
        id02= id01.withColumn('Timestamp2', F.from_unixtime(F.col("Timestamp")))
        id03= id02.select('ip', 'uid', 'Timestamp2')
        
        j01= mk01.join(id03, 'ip', 'inner')
        # Add code to apply timestamp filter
        
        j01.write.parquet(join_out1, mode= 'overwrite')
        j02= spark.read.parquet(join_out1)
        #---------------------------------------------------------------------------------------------------
    
    
    # Create CHV MK2
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        j03= j02.groupby('cb_key_household', 'uid').count().drop('count')
        j03.write.parquet(uid_out2, mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
        
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P050_1_stats_prev
        
        stats_name['HH0'] = 'Number of HHs'
        stats_name['IP0'] = 'Number of UIDs'
        #stats_name['HH1'] = 'Number of HHs from ChV'
        #stats_name['IP1'] = 'Number of IPs from ChV'
        #stats_name['HH2'] = 'Number of HHs from DE'
        #stats_name['IP2'] = 'Number of IPs from DE'
        
        stats['HH0'] = j02.groupby('cb_key_household').count().count()
        stats['IP0'] = j02.groupby('uid').count().count()
        #stats['HH1'] = all02.where(F.col('chv_de_flag')== 'chv').groupby('cb_key_household').count().count()
        #stats['IP1'] = all02.where(F.col('chv_de_flag')== 'chv').groupby('ip').count().count()
        #stats['HH2'] = all02.where(F.col('chv_de_flag')== 'de').groupby('cb_key_household').count().count()
        #stats['IP2'] = all02.where(F.col('chv_de_flag')== 'de').groupby('ip').count().count()
        
        stats_perc['HH0']  = round(stats['HH0'] / stats_prev['HH0'] - 1, 4)
        stats_perc['IP0']  = round(stats['IP0'] / stats_prev['IP0'] - 1, 4)
        #stats_perc['HH1']  = round(stats['HH1'] / stats_prev['HH1']- 1, 4)
        #stats_perc['IP1']  = round(stats['IP1'] / stats_prev['IP1']- 1, 4)
        #stats_perc['HH2']  = round(stats['HH2'] / stats_prev['HH2']- 1, 4)
        #stats_perc['IP2']  = round(stats['IP2'] / stats_prev['IP2']- 1, 4)
        
        stats_tl['HH0']= traffic_lights(stats_perc['HH0'])
        stats_tl['IP0']= traffic_lights(stats_perc['IP0'])
        #stats_tl['HH1']= traffic_lights(stats_perc['HH1'])
        #stats_tl['IP1']= traffic_lights(stats_perc['IP1'])
        #stats_tl['HH2']= traffic_lights(stats_perc['HH2'])
        #stats_tl['IP2']= traffic_lights(stats_perc['IP2'])
        
        result= f"{result}\n\n{stats_tl['HH0']} {stats_name['HH0']} [{stats['HH0']: ,}] ({stats_perc['HH0']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['IP0']} {stats_name['IP0']} [{stats['IP0']: ,}] ({stats_perc['IP0']: 15.2%})"        
        #result= f"{result}\n\n{stats_tl['HH1']} {stats_name['HH1']} [{stats['HH1']: ,}] ({stats_perc['HH1']: 15.2%})"        
        #result= f"{result}\n\n{stats_tl['IP1']} {stats_name['IP1']} [{stats['IP1']: ,}] ({stats_perc['IP1']: 15.2%})"
        #result= f"{result}\n\n{stats_tl['HH2']} {stats_name['HH2']} [{stats['HH2']: ,}] ({stats_perc['HH2']: 15.2%})"        
        #result= f"{result}\n\n{stats_tl['IP2']} {stats_name['IP2']} [{stats['IP2']: ,}] ({stats_perc['IP2']: 15.2%})"
        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)

