
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#de_in1  = 'match2/de/2022-12-19/from_de__*.csv'
#de_out1 = 'match2/process/2022-12-19/tmp.parquet'
#de_out2 = 'match2/process/2022-12-19/de01.parquet'

cv_in1  = P035_2_cv_in1
de_in2  = P035_2_de_in2
de_out1 = P035_2_de_out1


email_subject= '*** P035_2: CREATE CHV FLAG ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n de_in1 = {cv_in1}"
result= f"{result}\n\n de_out1 = {de_in2}"
result= f"{result}\n\n de_out2 = {de_out1}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Create flag'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        cv01= spark.read.csv(cv_in1, header= True)
        de01= spark.read.parquet(de_in2)
        
    # Create flag
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        cv02= cv01.groupby('cb_key_household').count().drop('count')
        cv03= cv02.withColumn('flag_chv', F.lit('1'))
        
        de02= de01.join(cv03, 'cb_key_household', 'left')
        
        de03= de02.withColumn('flag_chv', \
            F.when(F.col('flag_chv').isNull(), F.lit('0'))
            .otherwise(F.lit('1'))
        )
        
        # de04= de03.select('cb_key_household', 'UDPRN', 'ip', 'ip_rank', 'ip_flag', 'flag_chv', 'last_seen')
        de04= de03.select('cb_key_household', 'UDPRN', 'ip', 'ip_rank', 'ip_flag', 'flag_chv', F.col('location_first_seen').alias('first_seen'), 'last_seen', 'observations')
        
        de04.write.parquet(de_out1, mode= 'overwrite')
        
        de05= spark.read.parquet(de_out1)
        
    # QUICK STATS
    try:
#---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P035_2_stats_prev
        
        stats_name['CHV']   = 'Number of ChV HHs'
        stats_name['DE']    = 'Number of DE HHs (with an IP)'
        stats_name['BOTH']  = 'Number of HHs on DE and ChV:'
        
        stats['CHV']    = cv01.groupby('cb_key_household').count().count()
        stats['DE']     = de01.groupby('cb_key_household').count().count()
        stats['BOTH']   = de05.where(F.col('flag_chv')== '1').groupby('cb_key_household').count().count()
        
        stats_perc['CHV']   = round(stats['CHV']  / stats_prev['CHV'] - 1, 4)
        stats_perc['DE']    = round(stats['DE']   / stats_prev['DE'] - 1, 4)
        stats_perc['BOTH']  = round(stats['BOTH'] / stats_prev['BOTH']- 1, 4)
        
        stats_tl['CHV']= traffic_lights(stats_perc['CHV'])
        stats_tl['DE']= traffic_lights(stats_perc['DE'])
        stats_tl['BOTH']= traffic_lights(stats_perc['BOTH'])
        
        result= f"{result}\n\n{stats_tl['CHV']} {stats_name['CHV']} [{stats['CHV']: ,}] ({stats_perc['CHV']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['DE']} {stats_name['DE']} [{stats['DE']: ,}] ({stats_perc['DE']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['BOTH']} {stats_name['BOTH']} [{stats['BOTH']: ,}] ({stats_perc['BOTH']: 15.2%})"        
        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)






