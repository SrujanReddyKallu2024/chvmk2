
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import pandas as pd
import contextlib                                                               
from pyspark.sql import SparkSession

#-------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run== 0:
    from weekly_run import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 


spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#-------------------------------------------------

# Process Health parquet
import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

simpleData = [("James","Sales","NY",90000,34,10000), \
    ("Michael","Sales","NY",86000,56,20000), \
    ("Robert","Sales","CA",81000,30,23000), \
    ("Maria","Finance","CA",90000,24,23000) \
  ]

columns= ["employee_name","department","state","salary","age","bonus"]
df = spark.createDataFrame(data = simpleData, schema = columns)
df.printSchema()
df.show(truncate=False)




#--------------------------------------------------

now= datetime.datetime.now()
now= now.strftime("%Y-%m-%d %H:%M:%S")
now= f">>> timestamp: {now}"
now= f"{now}\n\n@Activate"

email_process(now, '*** START PROCESS ***')


