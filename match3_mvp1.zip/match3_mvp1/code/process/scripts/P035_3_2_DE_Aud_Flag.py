#*********************************************************
# *** THIS SCRIPT SHOULD RUN BETWEEN P035_3 and P035_4 ***
#*********************************************************

'''
* Add column 'flag_audip' to /user/unity/match2/process/{bweek}/DE_flag_chv_pubip.parquet
set('flag_audip')= {'0', '1'}

* Script has been tested on in2= DE_rows_to_keep.parquet in a Pyspark Shell.
Teams report is turned off (by email_subject= '--- P035_3_2: ADD AUDIGENT IP FLAG ***')
Email was sent and stats worked.

* Might need to make a change to stats['7'] and stats['8'] calculations

* The final script should overwrite DE_flag_chv_pubip.parquet (so that we don't have to change inputs to other processes)
'''



import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession


spark = SparkSession.builder.appName("P035_3_2").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 


# Settings ------------------------------------------------------------------------------
script_code= 'P035_3_2' # For 'Quick Stats'
email_subject= '*** P035_3_2: ADD AUDIGENT IP FLAG ***' #CHANGE TO '*** P035_3_2: ADD AUDIGENT IP FLAG ***'


# Dictionary of addresses ---------------------------------------------------------------

# P035_3_2_in1    = "/user/unity/id_graph/audigent"
# P035_3_2_in2    = f'/user/unity/match2/process/{bweek}/DE_flag_chv_pubip.parquet'
# P035_3_2_out1   = '/user/unity/temp/temp_audigent.parquet'
# P035_3_2_out2   = f'/user/unity/match2/process/{bweek}/DE_flag_chv_pubip.parquet'



address_dict= dict()

# Input
address_dict['in1'] = P035_3_2_in1
address_dict['in2'] = P035_3_2_in2

# Output
address_dict['out1'] = P035_3_2_out1
address_dict['out2'] = P035_3_2_out2


# List of addresses to clean ------------------------------------------------------------
address_clean= [address_dict['out1']]


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Make Input file Strings'
proc[2] =   'Read data'
proc[3] =   'Unique IPs'
proc[4] =   'Create Flag'
proc[5] =   'Output'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Count of All Unique Audigent IPs:'
stats_name['2']= 'Count of Audigent IPs in DE:'
stats_name['3']= 'Count of Audigent HHs in DE:'
stats_name['4']= 'Count of DE Rows with Audigent Flag:'
stats_name['5']= 'Count of Added DE IPs:'
stats_name['6']= 'Count of Added DE HHs:'
stats_name['7']= 'Count of Added DE Rows'

# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2):
    stats= dict()
    stats['1']= df1.count() #ip04
    stats['2']= df2.where(F.col('flag_audip')== '1').groupby('ip').count().count()
    stats['3']= df2.where(F.col('flag_audip')== '1').groupby('cb_key_household').count().count()
    stats['4']= df2.where(F.col('flag_audip')== '1').count()
    stats['5']= df2.where((F.col('flag_chv')+F.col('flag_pubip')== 0) & (F.col('flag_audip')== '1')).groupby('ip').count().count()
    stats['6']= df2.where((F.col('flag_chv')+F.col('flag_pubip')== 0) & (F.col('flag_audip')== '1')).groupby('cb_key_household').count().count()
    stats['7']= df2.where((F.col('flag_chv')+F.col('flag_pubip')== 0) & (F.col('flag_audip')== '1')).count()
    return stats


# Functions -----------------------------------------------------------------------------

# Utility Functions -----------------

def list_files(path, pattern=''):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    '''
    import subprocess
    import re
    files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    return y


# Script Specific Functions ---------

def get_file_list_string(lst, dates):
    #
    tmplst01=[]
    for x in lst:
        for y in dates:
            if y in x:
                tmplst01.append(x)
                break
    #
    tmpset02= set(tmplst01)
    tmplst03= list(tmpset02)
    tmplst04= [os.path.basename(x) for x in tmplst03]
    #
    str01= ','.join(tmplst04)
    return str01


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # GET INPUT FILE STRING
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        existing_date_dirs = get_valid_date_dirs(address_dict['in1'])
        #
        edate= datetime.date.today()
        sdate= edate + datetime.timedelta(days= -180)
        all_dates= [(sdate+datetime.timedelta(days=x)).strftime('%Y-%m-%d') for x in range((edate-sdate).days)]
        #
        valid_dates = sorted(list(set(existing_date_dirs).intersection(set(all_dates))))
        dateString = "{" + ",".join(valid_dates) + "}"
        #---------------------------------------------------------------------------------------------------
    #
    # READ DATA
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------        
        ip02 = spark.read.parquet(f"{address_dict['in1']}/{dateString}/ip_preprocessed*.parquet", mergeSchema= True)
        #
        de01= spark.read.parquet(address_dict['in2'])
        #---------------------------------------------------------------------------------------------------
    #
    # UNIQUE IPs
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------        
        #
        ip03= ip02.select(F.col('id_value').alias('ip'))
        ip04= ip03.select("ip").distinct()
        ip04.cache()
        ip04.count()
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE FLAG
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        ip05= ip04.withColumn('flag_audip', F.lit('1'))
        #
        de02= de01.join(ip05, 'ip', 'left')
        de03= de02.withColumn('flag_audip', F.when(F.col('flag_audip').isNull(), '0').otherwise(F.col('flag_audip')))
        #---------------------------------------------------------------------------------------------------
    #
    # OUTPUT
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        de03.write.parquet(address_dict['out1'], mode= 'overwrite')
        de04= spark.read.parquet(address_dict['out1'])
        de04.write.parquet(address_dict['out2'], mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(ip04, de04)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)



