
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from timeit import default_timer as timer
import datetime
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

script_code= 'P070'

#uid_in1= 'match2/process/2023-08-28/uid_s_code.parquet'
#pub_in2= '/data/griffin/S_CODE_PUBMATIC.csv'
#pub_out1= 'match2/process/2023-08-28/uid_s_code_pub.parquet'
#pub_out2= '/user/unity/match2/marketplaces/pubmatic/2023-08-28/pubmatic.parquet'
#pub_out3= '/user/unity/match2/marketplaces/pubmatic/2023-08-28/pubmatic.csv'
#pub_out4= '/data/data_to_sts/temp/for_pub.tsv'

uid_in1     = P070_uid_in1
pub_in2     = P070_pub_in2 
md_in3      = P070_md_in3
ip_in4      = P070_ip_in4
id5_in5     = P070_id5_in5
md_in6      = P070_md_in6
pub_out1    = P070_pub_out1 
pub_out2    = P070_pub_out2
pub_out3    = P070_pub_out3
pub_out4    = P070_pub_out4

#pub_out3    = P070_pub_out3 
#pub_out4    = P070_pub_out4 

#pub_out1= '/user/unity/datascience/griffin/x1.parquet'
#pub_out2= '/user/unity/datascience/griffin/x2.parquet'


email_subject= '*** P070: Output for Pubmatic ***'


#--------------------------------------------------------
# old_pub= ''

# if old_pub== '':
    # lweek= datetime.datetime.strptime(bweek, "%Y-%m-%d")-datetime.timedelta(days= 7)
    # lweek= lweek.strftime("%Y-%m-%d")
    # old_pub= f'/user/unity/match2/marketplaces/pubmatic/{lweek}/pubmatic.parquet'
#--------------------------------------------------------

result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n uid_in1  = {uid_in1}"
result= f"{result}\n\n pub_in2  = {pub_in2}"
result= f"{result}\n\n pub_out1 = {pub_out1}"
result= f"{result}\n\n pub_out2 = {pub_out2}"
result= f"{result}\n\n pub_out3 = {pub_out3}"
result= f"{result}\n\n pub_out4 = {pub_out4}"
#result= f"{result}\n\n pub_out4 = {pub_out4}"
#result= f"{result}\n\n old_pub = {old_pub}"

##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Pubmatic Segment list to Spark'
proc[3]= 'Join Segment list to Data'
proc[4]= 'Transpose Data'
proc[5]= 'Enrich IP with UID/MAIDS segments'
proc[6]= 'Union all sources and write output'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        j12= spark.read.parquet(uid_in1)
        md01= spark.read.parquet(md_in3)
        ip01= spark.read.parquet(ip_in4)
        P_Code= pd.read_csv(pub_in2)
        #old01= spark.read.parquet(old_pub)
        #---------------------------------------------------------------------------------------------------
    #
    # Create flag
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        P_Code2= ps.from_pandas(P_Code)
        P_Code3= P_Code2.to_spark()
        P_Code4= P_Code3.withColumn('S_Code', F.regexp_replace('S_Code', r'^S[0]*', 'S'))
        #---------------------------------------------------------------------------------------------------
    #
    # Create flag
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        j12_2= j12.join(F.broadcast(P_Code4), 'S_Code', 'inner')
        j12_2.write.parquet(pub_out1, mode= 'overwrite')
        j12_3= spark.read.parquet(pub_out1)
        #
        md02= md01.join(F.broadcast(P_Code4), 'S_Code', 'inner')
        md02.write.parquet(pub_out2, mode= 'overwrite')
        md03= spark.read.parquet(pub_out2)
        #---------------------------------------------------------------------------------------------------
    #
    #
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        j14= j12_3.groupby('uid').agg(F.collect_list('S_Code').alias('S_Code'))
        j15= j14.withColumn('SEGID', F.concat_ws(',', 'S_Code')).drop('S_Code').withColumnRenamed('uid','USERID')
        #
        j16= j15 \
            .withColumn('DPID', F.lit(857)) \
            .withColumn('IP', F.lit('')) \
            .withColumn('COUNTRY', F.lit('GB')) \
            .withColumn('UIDTYPE', F.lit('4'))
        j17= j16.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
        #
        md04= md03.groupby('maids').agg(F.collect_list('S_Code').alias('S_Code'))
        md05= md04.withColumn('SEGID', F.concat_ws(',', 'S_Code')).drop('S_Code').withColumnRenamed('maids','USERID')
        #
        md06= md05 \
            .withColumn('DPID', F.lit(857)) \
            .withColumn('IP', F.lit('')) \
            .withColumn('COUNTRY', F.lit('GB')) \
            .withColumn('UIDTYPE', F.lit('1'))
        md07= md06.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')

        #---------------------------------------------------------------------------------------------------
    #
    #
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        # Enrich IP records with segments from UID/MAIDS where IPs match
        id5 = spark.read.parquet(id5_in5)
        maids = spark.read.parquet(md_in6)
        w = Window.partitionBy('ip').orderBy(F.col('timestamp2').desc())

        # Helper function to get latest segment by IP
        def get_latest_seg_by_ip(id_df, seg_df, seg_alias):
            seg_renamed = seg_df.withColumnRenamed('USERID', 'uid').drop('IP')
            joined = id_df.join(seg_renamed, 'uid', 'inner')
            with_ts = joined.withColumn('timestamp2', F.from_unixtime(F.col("timestamp")))
            latest = with_ts.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")
            return latest.select('ip', 'SEGID').withColumnRenamed('SEGID', seg_alias)

        seg_from_uid = get_latest_seg_by_ip(id5, j17, 'SEGID_A')
        seg_from_maids = get_latest_seg_by_ip(maids, md07, 'SEGID_B')

        # Join IP data with segments, prioritize: UID > MAIDS \
        ip02 = ip01.join(seg_from_uid, on="ip", how="left").join(seg_from_maids, on="ip", how="left")
        ip03 = ip02.withColumn("SEGID", 
            F.coalesce(F.col("SEGID_A"), F.col("SEGID_B"), F.col("SEGID")))
							  
        ip04 = ip03.select('DPID', 'USERID', 'SEGID', 'IP', 'COUNTRY', 'UIDTYPE', 'cb_key_household')
        ip04.write.parquet(pub_out3, mode= 'overwrite')
        ip05 = spark.read.parquet(pub_out3).drop('cb_key_household')
        #---------------------------------------------------------------------------------------------------
    #
    #
    with doing_xy(process_num= 6):
        j17_2= j17.union(md07)
        j17_3 = j17_2.union(ip05)
        j17_3.write.parquet(pub_out4, mode= 'overwrite')
        j18= spark.read.parquet(pub_out4)
    '''  
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        #old01= spark.read.csv('/user/unity/match2/marketplaces/pubmatic/2023-08-07/pubmatic.csv')
        old01= spark.read.parquet('/user/unity/match2/marketplaces/pubmatic/2023-08-07/pubmatic2.parquet')
        old01= old01.withColumnRenamed('_c1', 'USERID')
        #x.count()
        
        old02= spark.read.csv('datascience/andy/for_pub.txt', header= True, sep= '\t')
        old01_2= old01.groupby('USERID').count().drop('count')
        old02_2= old02.groupby('USERID').count().drop('count')
        
        old= old01_2.union(old02_2)
        #old.show()
        old= old.groupby('USERID').count().drop('count')
        
        new= j18.groupby('USERID').count().drop('count')
        new= new.withColumn('flag', F.lit(1))
        
        both= old.join(new, 'USERID', 'left')
        both.show()
        
        del01= both.where(F.col('flag').isNull()).drop('flag')
        del01.count()
        
        del01= old.join(new, 'USERID', 'left_anti')
        del01.count()
        del01.show()
        
        del02= del01 \
            .withColumn('DPID', F.lit(857)) \
            .withColumn('IP', F.lit('')) \
            .withColumn('COUNTRY', F.lit('GB')) \
            .withColumn('UIDTYPE', F.lit('4')) \
            .withColumn('SEGID', F.lit(''))
        del03= del02.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
        del03.show()
        '''
        #---------------------------------------------------------------------------------------------------
        
    # with doing_xy(process_num= 6):
        # #---------------------------------------------------------------------------------------------------
        # # Add data from 3 week ago
        # bweek= 
        # pweek3= minus_days(bweek, 21)
        # old02= old01.select('USERID').join(j18.select('USERID'), 'USERID', 'left_anti')
        # old02.count()
        # #
        # old03= old02 \
            # .withColumn('DPID', F.lit(857)) \
            # .withColumn('IP', F.lit('')) \
            # .withColumn('COUNTRY', F.lit('GB')) \
            # .withColumn('UIDTYPE', F.lit('4')) \
            # .withColumn('SEGID', F.lit(''))
        # old04= old03.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
        # old04.show()
        # #---------------------------------------------------------------------------------------------------
    
    # with doing_xy(process_num= 7):
        # #---------------------------------------------------------------------------------------------------
        # #j19= j18.union(old04)
        # j19= j18
        # j19.show()
        # j19.write.csv(pub_out3, header= False, sep= '\t', mode= 'overwrite')
        # j20= spark.read.csv(pub_out3, header= False, sep= '\t')
        
        # #j20.show()
        # #j20.where(F.col('_c2').isNull()).count()
        # #j20.groupby('_c1').count().count()
        # #---------------------------------------------------------------------------------------------------
        
    # with doing_xy(process_num= 8):
        # #---------------------------------------------------------------------------------------------------
        # os.system(f"hdfs dfs -getmerge {pub_out3} {pub_out4}")
        #
        # dir_temp= '/data/data_to_sts/temp'
        # file_temp= 'for_pubmatic.tsv'
        # dpid= '857'
        # pub_request= 'replaceseg'
        # dir_final= '/data/data_to_sts/marketplaces/pubmatic'
        #
        # os.system(
            # "cd " + dir_temp + "\n" \
            # "timestamp=$(date +%s%3N)\n" \
            # "md5=$(md5sum " + file_temp + " | awk '{ print $1 }')\n" \
            # "filename=" + dpid + "_" + pub_request + "_${timestamp}_${md5}.tsv.gz\n" \
            # "gzip " + file_temp + "\n" \
            # "mv " + file_temp + ".gz ${filename}\n" \
            # #"mv ${filename} " + dir_final
        # )
        # #---------------------------------------------------------------------------------------------------
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        #
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        #
        stats_name['tot']   = 'Number of Records:'
        stats_name['uid']   = 'Number of UIDs:'
        stats_name['code']  = 'Number of Segments'
        #stats_name['IP1']  = 'Number of IPs to keep:'
        #
        stats['tot']    = j18.count()
        stats['uid']    = j18.groupby('USERID').count().count()
        stats['code']   = j12_3.groupby('S_Code').count().count()
        #stats['IP1'] = de_1.groupby('ip').count().count()
        #
        if stats_prev!= '':
            stats_perc['tot']   = round(stats['tot']  / stats_prev['tot'] - 1, 4)
            stats_perc['uid']   = round(stats['uid']   / stats_prev['uid'] - 1, 4)
            stats_perc['code']  = round(stats['code'] / stats_prev['code']- 1, 4)
            #stats_perc['IP1']  = round(stats['IP1'] / stats_prev['IP1']- 1, 4)
            #
            stats_tl['tot']     = traffic_lights(stats_perc['tot'])
            stats_tl['uid']     = traffic_lights(stats_perc['uid'])
            stats_tl['code']    = traffic_lights(stats_perc['code'])
            #stats_tl['IP1']    = traffic_lights(stats_perc['IP1'])
            #
            result= f"{result}\n\n{stats_tl['tot']} {stats_name['tot']} [{stats['tot']: ,}] ({stats_perc['tot']: 15.2%})"        
            result= f"{result}\n\n{stats_tl['uid']} {stats_name['uid']} [{stats['uid']: ,}] ({stats_perc['uid']: 15.2%})"        
            result= f"{result}\n\n{stats_tl['code']} {stats_name['code']} [{stats['code']: ,}] ({stats_perc['code']: 15.2%})"        
            #result= f"{result}\n\n{stats_tl['IP1']} {stats_name['IP1']} [{stats['IP1']: ,}] ({stats_perc['IP1']: 15.2%})"
        else:
            stats_perc['tot']   = '-.--'
            stats_perc['uid']   = '-.--'
            stats_perc['code']  = '-.--'
            #stats_perc['IP1']  = '-.--'
            #
            stats_tl['tot']     = traffic_lights(0)
            stats_tl['uid']     = traffic_lights(0)
            stats_tl['code']    = traffic_lights(0)
            #stats_tl['IP1']    = traffic_lights(0)
            #
            result= f"{result}\n\n{stats_tl['tot']} {stats_name['tot']} [{stats['tot']: ,}] ({stats_perc['tot']}%)"        
            result= f"{result}\n\n{stats_tl['uid']} {stats_name['uid']} [{stats['uid']: ,}] ({stats_perc['uid']}%)"        
            result= f"{result}\n\n{stats_tl['code']} {stats_name['code']} [{stats['code']: ,}] ({stats_perc['code']}%)"        
            #result= f"{result}\n\n{stats_tl['IP1']} {stats_name['IP1']} [{stats['IP1']: ,}] ({stats_perc['IP1']}%)"
        #
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)

