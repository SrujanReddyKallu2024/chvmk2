
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import pandas as pd
import contextlib                                                               
from pyspark.sql import SparkSession
#import pyspark.pandas as ps

import subprocess
import re

bweek= '2023-09-18'
tax_in1     = f'match2/process/{bweek}/uid_s_code_cal.parquet'
tax_out1    = f'match2/process/{bweek}/uid_lookup.parquet'
tax_out2    = f'match2/process/{bweek}/uid2_s_code.parquet'
tax_out3    = f'match2/process/{bweek}/uid2_s_code2.parquet'

tax_in1
tax_out1
tax_out2
tax_out3

x01= spark.read.parquet(tax_in1)
x01.count()
x01.show()
x01.groupby('uid').count().count()
x01.groupby('S_Code').count().count()

uid01= x01.groupby('uid').count().drop('count')
uid02= uid01.sort('uid')
uid03= uid02.withColumn('uid2', (F.monotonically_increasing_id()))
uid03.printSchema()
uid03.groupby('uid2').count().count()
uid03.groupby('uid').count().count()
uid03.write.parquet(tax_out1, mode= 'overwrite')
uid04= spark.read.parquet(tax_out1)
uid04.show()

x02= x01.withColumn('S_Code', F.regexp_replace('S_Code', r'^S[0]*', '').cast("integer"))
#x02.show()

x03= x02.join(uid04, 'uid', 'inner')
#x03.show()
#x03.groupby('uid').count().count()
#x03.groupby('uid2').count().count()
x04= x03.select('uid2', 'S_Code')
x04.write.parquet(tax_out2, mode= 'overwrite')
x05= spark.read.parquet(tax_out2)
x05.printSchema()
x05.count()
x05.show()
x05.groupby('uid2').count().count()
x05.groupby('S_Code').count().count()
x05.printSchema()
#x05.groupby('uid2').count().count()
#x05.groupby('uid2', 'S_Code').count().count()
#x05.groupby('S_Code').count().count()

start_all= timer()
x05.write \
    .partitionBy("S_Code") \
    .mode("overwrite") \
    .parquet(tax_out3)
end_all= timer()
time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
time_all


