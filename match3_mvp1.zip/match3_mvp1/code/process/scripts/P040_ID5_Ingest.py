
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession

#-----------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 
      

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

###################################################################



# Settings ------------------------------------------------------------------------------
script_code= 'P040' # For 'Quick Stats'
email_subject= '*** P040: INGEST CONSENTED ID5 FILE FOR PROCESS ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()
if file_exists(P040_0_id_out1)==0:
    address_dict['id_in1']  = P040_0_id_out1
else:
    address_dict['id_in1']  = P040_id_in1
address_dict['id_out1'] = P040_id_out1
address_dict['id_out2'] = P040_id_out2
address_dict['id_out3'] = P040_id_out3
address_dict['id_out4'] = P040_id_out4
address_dict


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read parquet'
proc[2] =   'Check columns exist'
proc[3] =   'Subset by type_uid'
proc[4] =   'Write parquets'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Number of Rows'
stats_name['2']= 'Number of IPs:'
stats_name['3']= 'Number of UIDs:'
stats_name['4']= 'Number of Rows (id5UID):'
stats_name['5']= 'Number of IPs (id5UID):'
stats_name['6']= 'Number of UIDs (id5UID):'
stats_name['7']= 'Number of Rows (MAIDS):'
stats_name['8']= 'Number of IPs (MAIDS):'
stats_name['9']= 'Number of UIDs (MAIDS):'
stats_name['10']= 'Number of Rows (AppNexus):'
stats_name['11']= 'Number of IPs (AppNexus):'
stats_name['12']= 'Number of UIDs (AppNexus):'
stats_name['13']= 'Number of Rows (TradeDesk):'
stats_name['14']= 'Number of IPs (TradeDesk):'
stats_name['15']= 'Number of UIDs (TradeDesk):'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2,df3,df4,df5):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('ip').count().count()
    stats['3']= df1.groupby('uid').count().count()
    stats['4']= df2.count()
    stats['5']= df2.groupby('ip').count().count()
    stats['6']= df2.groupby('uid').count().count()
    stats['7']= df3.count()
    stats['8']= df3.groupby('ip').count().count()
    stats['9']= df3.groupby('uid').count().count()
    stats['10']= df4.count()
    stats['11']= df4.groupby('ip').count().count()
    stats['12']= df4.groupby('uid').count().count()
    stats['13']= df5.count()
    stats['14']= df5.groupby('ip').count().count()
    stats['15']= df5.groupby('uid').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read Digital Taxonomy
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        try:
            id01= spark.read.parquet(address_dict['id_in1'])
        except Exception as e:
            print(f"unable to read output of P040_0: {e}")
            sys.exit()
        #---------------------------------------------------------------------------------------------------
    #
    # Check columns
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        id02= id01.select('ip', 'household', 'uid', 'type_uid', 'timestamp')
        #---------------------------------------------------------------------------------------------------
    #
    # Filter none id5s
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        # ID5 ids
        id03= id02.where(F.col('type_uid') == 'id5UID')
        # Maids
        id03_2= id02.where(F.col('type_uid').isin(['android','ios']))
        # AppNexus        
        id03_3= id02.where(F.col('type_uid') == 'AppNexus')
        # Tradedesk
        id03_4= id02.where(F.col('type_uid') == 'TradeDesk')
        #---------------------------------------------------------------------------------------------------
    #
    # Write parquet 
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        id03.write.parquet(address_dict['id_out1'], mode= 'overwrite')
        id04= spark.read.parquet(address_dict['id_out1'])
        #
        id03_2.write.parquet(address_dict['id_out2'], mode= 'overwrite')
        id04_2= spark.read.parquet(address_dict['id_out2'])
        #
        id03_3.write.parquet(address_dict['id_out3'], mode= 'overwrite')
        id04_3= spark.read.parquet(address_dict['id_out3'])
        #
        id03_4.write.parquet(address_dict['id_out4'], mode= 'overwrite')
        id04_4= spark.read.parquet(address_dict['id_out4'])
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(id01,id04,id04_2,id04_3,id04_4)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)



