
# Apply Pubmatic CIPS 

import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#de_in1  = 'match2/de/2022-12-19/from_de__*.csv'
#de_out1 = 'match2/process/2022-12-19/tmp.parquet'
#de_out2 = 'match2/process/2022-12-19/de01.parquet'

pub_in1 =   P035_3_pub_in1
de_in2  =   P035_3_de_in2
ci_in3  =   P035_3_ci_in3
de_out1 =   P035_3_de_out1


email_subject= '*** P035_3: CREATE PUBMATIC IP FLAG ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n de_in1 = {pub_in1}"
result= f"{result}\n\n de_out1 = {de_in2}"
result= f"{result}\n\n de_out2 = {de_out1}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Create date 180 days ago'
proc[3]= 'Convert Unix datetime'
proc[4]= 'Apply date'
proc[5]= 'Apply CIP'
proc[6]= 'Create flag and create parquet'

#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        pub01= spark.read.parquet(pub_in1)
        de01= spark.read.parquet(de_in2)
        #de01= spark.read.parquet('match2/process/2023-09-04/DE_rows_to_keep.parquet').drop('flag_pubip')
        cip01= spark.read.parquet(ci_in3)
    
    # Find date 180 days ago
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        today= datetime.date.today()
        today_180= today- datetime.timedelta(days= 180)
        today_180= today_180.strftime("%Y-%m-%d")
    
    # Convert datetime from unixtime
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        pub02= pub01.groupby('ip').agg(F.max('last_seen').alias('last_seen'), F.collect_set('publisherid').alias('publishers'))
        pub03= pub02.select('ip', F.from_unixtime(F.col("last_seen")).alias("x"), 'publishers')
        pub04= pub03.withColumn('Timestamp', F.substring('x', 1,10)).drop('x')
    
    # Apply date
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        pub05= pub04.where(F.col('Timestamp')>= today_180)
        ip01= pub05.select('ip','publishers').distinct()
    
    # Apply CIP
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        # Get unique list of ips
        cip02= cip01.groupby('host').count().drop('count').withColumnRenamed('host', 'ip')
        cip03= cip02.withColumn('flag_cip', F.lit('1'))
        
        ip01_2= ip01.join(cip03, 'ip', 'left')
        ip01_3= ip01_2.where(F.col('flag_cip').isNull()).drop('flag_cip')
    
    # Create Pubmatic flag
    with doing_xy(process_num= 6):
        #---------------------------------------------------------------------------------------------------
        ip02= ip01_3.withColumn('flag_pubip', F.lit('1'))
        
        flags01= de01.join(ip02, 'ip', 'left')
        flags02= flags01.withColumn('flag_pubip', \
            F.when(F.col('flag_pubip').isNull(), F.lit('0'))
            .otherwise(F.lit('1'))
        )
        
        flags02.write.parquet(de_out1, mode= 'overwrite')
        flags03= spark.read.parquet(de_out1)
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P035_3_stats_prev
        
        stats_name['PUB']   = 'Number of PUB IPs:'
        stats_name['DE']    = 'Number of DE IPs (not on ChV):'
        stats_name['BOTH']  = 'Number of DE IPs matched:'
        stats_name['HH']    = 'Number of HHs added:'
        
        stats['PUB']    = ip02.count()
        stats['DE']     = de01.where(F.col('flag_chv')== '0').groupby('ip').count().count()
        stats['BOTH']   = flags03.where((F.col('flag_chv')== '0') & (F.col('flag_pubip')== '1')).groupby('ip').count().count()
        stats['HH']     = flags03.where((F.col('flag_chv')== '0') & (F.col('flag_pubip')== '1')).groupby('cb_key_household').count().count()
        
        stats_perc['PUB']   = round(stats['PUB']  / stats_prev['PUB'] - 1, 4)
        stats_perc['DE']    = round(stats['DE']   / stats_prev['DE'] - 1, 4)
        stats_perc['BOTH']  = round(stats['BOTH'] / stats_prev['BOTH']- 1, 4)
        stats_perc['HH']    = round(stats['HH'] / stats_prev['HH']- 1, 4)
        
        stats_tl['PUB']= traffic_lights(stats_perc['PUB'])
        stats_tl['DE']= traffic_lights(stats_perc['DE'])
        stats_tl['BOTH']= traffic_lights(stats_perc['BOTH'])
        stats_tl['HH']= traffic_lights(stats_perc['HH'])
        
        result= f"{result}\n\n{stats_tl['PUB']} {stats_name['PUB']} [{stats['PUB']: ,}] ({stats_perc['PUB']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['DE']} {stats_name['DE']} [{stats['DE']: ,}] ({stats_perc['DE']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['BOTH']} {stats_name['BOTH']} [{stats['BOTH']: ,}] ({stats_perc['BOTH']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['HH']} {stats_name['HH']} [{stats['HH']: ,}] ({stats_perc['HH']: 15.2%})"
        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
        
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)

