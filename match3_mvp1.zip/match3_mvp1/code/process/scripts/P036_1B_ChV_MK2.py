
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 



# Settings ------------------------------------------------------------------------------
script_code= 'P036_1' # For 'Quick Stats'
email_subject= '*** P036_1: MAKE WEEKLY CHV MK2 ***'

# lweek= minus_days(bweek, 7)
# lweek


# Dictionary of addresses ---------------------------------------------------------------

address_dict= dict()

# Input
address_dict['de_in1']  = P036_1B_de_in1 #os.path.join(base, 'process', bweek, 'DE_rows_to_keep.parquet')
address_dict['cv_in2']  = file_cv
#address_dict['ci_in3']  = file_pub_cip
address_dict['uc_in4']  = P036_1B_uc_in1 #f'/user/unity/match2/unacast/{bweek}/process/unacast_hh_ip_flags.parquet'
address_dict['uc_in5']  = P036_1B_uc_in2 #f'/user/unity/match2/unacast/{lweek}/process/unacast_hh_ip_flags.parquet'

# Output
address_dict['cv_out1'] = P036_1B_cv_out1 #f'/user/unity/match2/process/{bweek}/temp1_chv_mk2.parquet'
address_dict['cv_out2'] = P036_1B_cv_out2 #f'/user/unity/match2/process/{bweek}/chv_mk2.parquet'

# Output test
#address_dict['cv_out1'] = f'/user/unity/datascience/griffin/match2/process/{bweek}/temp1_chv_mk2.parquet'
#address_dict['cv_out2'] = f'/user/unity/datascience/griffin/match2/process/{bweek}/chv_mk2.parquet'


# List of addresses to clean ------------------------------------------------------------
address_clean= [
    address_dict['cv_out1']
]


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Create date ranges'
proc[2] =   'Read in files'
proc[3] =   'Add Chv'
proc[4] =   'Add UC'
proc[5] =   'Apply NMR and CIP'
proc[6] =   'Write to HDFS'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Number of rows before NMR & CIP:'
stats_name['2']= 'Number of HHs before NMR & CIP:'
stats_name['3']= 'Number of IPs before NMR & CIP:'
stats_name['4']= 'Number of rows after NMR & CIP:'
stats_name['5']= 'Number of HHs after NMR & CIP:'
stats_name['6']= 'Number of IPs after NMR & CIP:'
stats_name['7']= 'Number of HHs from Chv:'
stats_name['8']= 'Number of HHs from DE:'
stats_name['9']= 'Number of HHs from UC'
stats_name['10']= 'Number of IPs from Chv:'
stats_name['11']= 'Number of IPs from DE:'
stats_name['12']= 'Number of IPs from UC:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('cb_key_household').count().count()
    stats['3']= df1.groupby('ip').count().count()
    stats['4']= df2.count()
    stats['5']= df2.groupby('cb_key_household').count().count()
    stats['6']= df2.groupby('ip').count().count()
    stats['7']= df2.where(F.col('chv_de_flag')== 'chv').groupby('cb_key_household').count().count()
    stats['8']= df2.where(F.col('chv_de_flag')== 'de').groupby('cb_key_household').count().count()
    stats['9']= df2.where(F.col('chv_de_flag')== 'uc').groupby('cb_key_household').count().count()
    stats['10']= df2.where(F.col('chv_de_flag')== 'chv').groupby('ip').count().count()
    stats['11']= df2.where(F.col('chv_de_flag')== 'de').groupby('ip').count().count()
    stats['12']= df2.where(F.col('chv_de_flag')== 'uc').groupby('ip').count().count() 
    return stats



#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Set up dates
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        # first_seen= datetime.datetime.strptime(bweek, "%Y-%m-%d")-datetime.timedelta(days= 6)
        # first_seen= first_seen.strftime("%Y-%m-%d")
        # last_seen=  bweek
        # first_seen
        # last_seen
        #
        # Change to 180 days - done
        chv_cutoff= datetime.date.today()- datetime.timedelta(days= 180)
        chv_cutoff= chv_cutoff.strftime("%Y-%m-%d")
        chv_cutoff
        #---------------------------------------------------------------------------------------------------
    #
    # Read files
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        de01= spark.read.parquet(address_dict['de_in1'])
        #
        cv01= spark.read.csv(address_dict['cv_in2'], header= True)
        #cip01= spark.read.parquet(address_dict['ci_in3'])
        #
        uc01= spark.read.parquet(address_dict['uc_in4'])
        uc02= spark.read.parquet(address_dict['uc_in5'])

        ## Adding changes for audigent
        if 'flag_audip' not in uc02.columns:
            uc02 = uc02.withColumn('flag_audip', F.lit(None).cast(StringType()))


        #---------------------------------------------------------------------------------------------------
    #
    # Create CHV MK2
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        #ChannelView
        cv01_2= cv01.where(F.col('ip_date_of_capture')>= chv_cutoff)
        #
        cv02= cv01_2.groupby('ip_address','cb_key_household') \
            .agg( \
                    F.min('ip_date_of_capture').alias('first_seen'), \
                    F.max('ip_date_of_capture').alias('last_seen') \
            ).withColumnRenamed('ip_address', 'ip')
        #
        # Add time stamp first seen / last seen
        #
        # DE ----------------------------------------------------------
        # de02= de01 \
            # .withColumn('first_seen', F.lit(first_seen)) \
            # .withColumn('last_seen', F.lit(last_seen))
        #
        # de02= de01.withColumn('first_seen', F.date_add(F.col('last_seen'), -7))
        #
        de03= de01.select('ip', 'cb_key_household', 'first_seen', 'last_seen', 'ip_rank', 'ip_flag', 'flag_chv', 'flag_pubip', 'publishers', 'flag_audip') ## Adding changes for audigent
        #
        cv03= (
            cv02
            .withColumn('ip_rank', F.lit(None).cast(IntegerType()))
            .withColumn('ip_flag', F.lit(None).cast(StringType()))
            .withColumn('flag_chv', F.lit(None).cast(StringType()))
            .withColumn('flag_pubip', F.lit(None).cast(StringType()))
            .withColumn('flag_audip', F.lit(None).cast(StringType())) ## Adding changes for audigent
            .withColumn('publishers', F.array(F.lit(None)))
        )
        #
        cv04= cv03.withColumn('chv_de_flag', F.lit('chv'))
        de04= de03.withColumn('chv_de_flag', F.lit('de'))
        #
        all01= cv04.unionByName(de04)
    #
    # Add Unicast.
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        uc03= uc01.unionByName(uc02)
        #
        uc04= (
            uc03
            .groupby('ip', 'cb_key_household')
            .agg(
                F.max('flag_chv').alias('flag_chv'),
                F.max('flag_pubip').alias('flag_pubip'),
                F.max('flag_audip').alias('flag_audip'),  ## Adding changes for audigent
                F.min('first').alias('first'), \
                F.max('last').alias('last'), \
                F.collect_set('publishers').alias('publishers')
            )
        )   
        #
        uc05= uc04 \
            .withColumn('ip_rank', F.lit(None).cast(IntegerType())) \
            .withColumn('ip_flag', F.lit(None).cast(StringType())) \
            .withColumn('chv_de_flag', F.lit('uc'))
        #
        uc06= uc05 \
            .withColumnRenamed('first', 'first_seen') \
            .withColumnRenamed('last', 'last_seen')
        #
        uc07= uc06.select('ip', 'cb_key_household', 'first_seen', 'last_seen', 'ip_rank', 'ip_flag', 'flag_chv', 'flag_pubip', 'flag_audip', 'chv_de_flag', F.array_distinct(F.flatten(F.col('publishers'))).alias('publishers')) ## Adding changes for audigent
        #
        all02= (
            all01
            .unionByName(uc07)
            .withColumn(
                "publishers",
                F.when(
                    (F.col("publishers").isNull()) | (F.size(F.col("publishers")) == 0) | (F.size(F.array_except(F.col("publishers"), F.array(F.lit(None)))) == 0),
                    None
                ).otherwise(F.col("publishers"))
            )
        )
        #
        all02.write.parquet(address_dict['cv_out1'], mode= 'overwrite')
        all03= spark.read.parquet(address_dict['cv_out1'])
        #---------------------------------------------------------------------------------------------------
    #
    # Apply nmr and cip
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        #cip02= cip01.groupby('host').count().drop('count').withColumnRenamed('host', 'ip')
        #cip03= cip02.withColumn('flag_cip', F.lit('1'))
        #
        #all01_2= all01.join(cip03, 'ip', 'left')
        #all01_3= all01_2.where(F.col('flag_cip').isNull()).drop('flag_cip')
        #all01_2.count()
        #all01_3.count()
        #all02= all01_3
        #
        #all01.write.parquet(cv_out1, mode= 'overwrite')
        #cvmk01= spark.read.parquet(cv_out1)
        #all03= all02.sort('cb_key_household')
        #all03.show()
        #
        # Apply nmr function
        all04= nmr_apply(all03)
        # Apply cip function
        all05= cip_apply(all04)
        #
        #---------------------------------------------------------------------------------------------------
    #
    # Output
    with doing_xy(process_num= 6):
        #---------------------------------------------------------------------------------------------------
        all05.write.parquet(address_dict['cv_out2'], mode= 'overwrite')
        all06= spark.read.parquet(address_dict['cv_out2'])
        #---------------------------------------------------------------------------------------------------
    #
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(all03,all06)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)  
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #    
    # Clean up
    clean_up_hdfs(address_clean)
#
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)

