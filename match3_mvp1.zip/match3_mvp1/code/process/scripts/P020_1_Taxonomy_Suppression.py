
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import pandas as pd
import contextlib                                                               
from pyspark.sql import SparkSession
import json

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")


##################################################################

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 


###################################################################

start_all= timer()

script_code= "P020_1"

# File locations in/out
#dt_in1  = '/user/unity/v2/weekly_nmr/A16.20221205.csv' 
#dt_in2  = '/user/unity/datascience/match2/Digital_taxonomy/process/Digital_taxonomy_perm.parquet'
#dt_out1 = '/user/unity/datascience/match2/Digital_taxonomy/process/Taxonomy_Suppress.parquet'

dt_in1  = P020_1_dt_in1
dt_in2  = P020_1_dt_in2
dt_out1 = P020_1_dt_out1


email_subject= '*** P020_1: NMR/CIP SUPPRESSION OF TAXONOMY ***'

result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n dt_in1 = {dt_in1}"
result= f"{result}\n\n dt_in2 = {dt_in2}"
result= f"{result}\n\n dt_out1 = {dt_out1}"

##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in A16, Taxonomy'
proc[2]= 'Join Sup HHs to Taxonomy'
proc[3]= 'Find sup UDPRNs and join to Taxonomy'
proc[4]= 'Write Taxonomy with Sup flags to parquet'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

result= f'{result}\n\n--- PROCESS HEALTH ---------------------------------'

try:
    # Read in A16 and Taxonmy
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        A01= spark.read.csv(dt_in1, header= True)
        
        dt01= spark.read.parquet(dt_in2) \
            .select('cb_key_db_person', 'cb_key_household', 'UDPRN')
        #---------------------------------------------------------------------------------------------------
    
    # Accumulate A16 to cb_key_hh and join to Taxonomy
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        sup01= A01.groupby('cb_key_household').count().drop('count')
        sup02= sup01.withColumn('flag_hh', F.lit(1))
        sup03= dt01.join(sup02, 'cb_key_household', 'left')
        #---------------------------------------------------------------------------------------------------
    
    # Find UDPRNs and merge back to Taxonomy
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        sup04= sup03.where(F.col('flag_hh') == 1)
        sup05= sup04.groupby('UDPRN').count().drop('count')
        sup06= sup05.withColumn('flag_UDPRN', F.lit(1))
        sup07= sup03.join(sup06, 'UDPRN', 'left')
        #---------------------------------------------------------------------------------------------------
    
    # Write out to parquet.
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        sup07.write.parquet(dt_out1, mode= 'overwrite')
        sup08= spark.read.parquet(dt_out1)
        #---------------------------------------------------------------------------------------------------
    
    # QUICK STATS CREATION:
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        # quick stats input
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        
        stats_name['Total_A16'] = 'Number of Rows in A16:'
        stats_name['Total_dt']  = 'Number of Rows in Taxonomy:'
        stats_name['hh']        = 'Number of HHs matched:'
        stats_name['udprn']     = 'Total no. of UDPRNs suppressed:'
        stats_name['Total_hhs'] = 'Total no. of HHs suppressed:'
        stats_name['Total_pp']  = 'Total no. of People suppressed:'
        
        stats['Total_A16']  = A01.count()
        stats['Total_dt']   = dt01.count()
        stats['hh']         = sup04.groupby('cb_key_household').count().count()
        stats['udprn']      = sup05.count()
        stats['Total_hhs']  = sup08.where(F.col('flag_UDPRN')==1).groupby('cb_key_household').count().count()
        stats['Total_pp']   = sup08.where(F.col('flag_UDPRN')==1).groupby('cb_key_db_person').count().count()
        
        stats_perc['Total_A16'] = round(stats['Total_A16']  / stats_prev['Total_A16'] - 1, 4)
        stats_perc['Total_dt']  = round(stats['Total_dt']   / stats_prev['Total_dt']- 1, 4)
        stats_perc['hh']        = round(stats['hh']         / stats_prev['hh'] - 1, 4)
        stats_perc['udprn']     = round(stats['udprn']      / stats_prev['udprn'] - 1, 4)
        stats_perc['Total_hhs'] = round(stats['Total_hhs']  / stats_prev['Total_hhs'] - 1, 4)
        stats_perc['Total_pp']  = round(stats['Total_pp']   / stats_prev['Total_pp'] - 1, 4)
        
        stats_tl['Total_A16']= traffic_lights(stats_perc['Total_A16'])
        stats_tl['Total_dt']= traffic_lights(stats_perc['Total_dt'])
        stats_tl['hh']= traffic_lights(stats_perc['hh'])
        stats_tl['udprn']= traffic_lights(stats_perc['udprn'])
        stats_tl['Total_hhs']= traffic_lights(stats_perc['Total_hhs'])
        stats_tl['Total_pp']= traffic_lights(stats_perc['Total_pp'])
        
        result= f"{result}\n\n{stats_tl['Total_A16']} {stats_name['Total_A16']} [{stats['Total_A16']: ,}] ({stats_perc['Total_A16']: 15.2%})"
        result= f"{result}\n\n{stats_tl['Total_dt']} {stats_name['Total_dt']} [{stats['Total_dt']: ,}] ({stats_perc['Total_dt']: 15.2%})"
        result= f"{result}\n\n{stats_tl['hh']} {stats_name['hh']} [{stats['hh']: ,}] ({stats_perc['hh']: 15.2%})"
        result= f"{result}\n\n{stats_tl['udprn']} {stats_name['udprn']} [{stats['udprn']: ,}] ({stats_perc['udprn']: 15.2%})"
        result= f"{result}\n\n{stats_tl['Total_hhs']} {stats_name['Total_hhs']} [{stats['Total_hhs']: ,}] ({stats_perc['Total_hhs']: 15.2%})"
        result= f"{result}\n\n{stats_tl['Total_pp']} {stats_name['Total_pp']} [{stats['Total_pp']: ,}] ({stats_perc['Total_pp']: 15.2%})"    
        
        # Backup stats
        
        quick_stats_backup(quick_stats_path, script_code, bweek,stats)
       
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)



