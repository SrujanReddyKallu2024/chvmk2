
# MAKE MORE THAN ONE SCRIPT

import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

from pyspark.sql.window import Window

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 
      

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

###################################################################



# Settings ------------------------------------------------------------------------------
script_code= 'P051_1' # For 'Quick Stats'
email_subject= '*** P051_1: MERGE MAIDS WITH CHV_MK2 (Backlog) ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()
address_dict['md_in1']  = P051_1_md_in1
address_dict['cv_in2']  = P051_1_cv_in2
address_dict['md_out1'] = P051_1_md_out1
address_dict


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Do join and subset'
proc[3] =   'Pick best matches'
proc[4] =   'Write parquets'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Number of Rows:'
stats_name['2']= 'Number of MAIDS:'
stats_name['3']= 'Number of HHs:'



# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('maids').count().count()
    stats['3']= df1.groupby('cb_key_household').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read Digital Taxonomy
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        md01= spark.read.parquet(address_dict['md_in1'])
        de01= spark.read.parquet(address_dict['cv_in2'])
        #---------------------------------------------------------------------------------------------------
    #
    # Check columns
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        md02= md01.withColumn('timestamp', F.from_unixtime('timestamp', 'yyyy-MM-dd'))
        md03= md02.select('ip', F.col('uid').alias('maids'), 'timestamp')
        #
        j01= de01.join(md03, 'ip', 'inner')
        #
        j02= j01 \
            .withColumn('date_diff', \
            F.when(F.col('timestamp').between(F.col('first_seen'), F.col('last_seen')), F.lit(0)) \
            .otherwise(F.least(F.abs(F.datediff('timestamp','first_seen')),F.abs(F.datediff('timestamp','last_seen'))))
        )
        #
        j03= j02.where(F.col('date_diff')<= 7)
        #---------------------------------------------------------------------------------------------------
    #
    # Filter none id5s
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        j04= j03.groupby('maids', 'cb_key_household', 'ip').count().drop('count')
        j04_2= j04.groupby('maids', 'cb_key_household').count().withColumnRenamed('count', 'count_ip')
        #
        j05= j03.groupby('maids', 'cb_key_household', 'chv_de_flag').count().drop('count')
        j05_2= j05.groupby('maids', 'cb_key_household').count().withColumnRenamed('count', 'count_flag')
        #
        j06= j03.groupby('maids', 'cb_key_household').agg(F.mean('date_diff').alias('mean'), F.min('date_diff').alias('min'))
        j06_2= j03.groupby('maids', 'cb_key_household').count().withColumnRenamed('count', 'count_all')
        #
        j07= j04_2.join(j05_2, ['maids', 'cb_key_household'], 'inner')
        j08= j07.join(j06_2, ['maids', 'cb_key_household'], 'inner')
        j09= j08.join(j06, ['maids', 'cb_key_household'], 'inner')
        #
        w1 = Window.partitionBy('maids').orderBy(F.col('count_flag').desc(),F.col('count_ip').desc(),F.col('min'),F.col('mean'),F.col('count_all'))
        j10= j09.withColumn("row",F.row_number().over(w1)).filter(F.col("row")<= 3)
        #
        w1 = Window.partitionBy('cb_key_household').orderBy(F.col('count_flag').desc(),F.col('count_ip').desc(),F.col('min'),F.col('mean'),F.col('count_all').desc())
        j11= j10.withColumn("row",F.row_number().over(w1)).filter(F.col("row")<= 50)
        #---------------------------------------------------------------------------------------------------
    #
    # Write parquet 
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        j11.write.parquet(address_dict['md_out1'], mode= 'overwrite')
        j12= spark.read.parquet(address_dict['md_out1'])
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(j12)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        result= f"{result}\n\nUIDType should be ok"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)




