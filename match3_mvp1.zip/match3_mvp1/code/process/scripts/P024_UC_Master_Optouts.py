
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession

import json
import math

from pyspark.ml.feature import Bucketizer
import numpy as np

from pyspark.sql.window import Window
import argparse

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 


spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")


# Settings ------------------------------------------------------------------------------
script_code= 'P024' # For 'Quick Stats'
email_subject= '*** P024: INGEST UNACAST OPTOUTS AND CREATE MASTER***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['un_in1']  = P024_un_in1 #directory containing this week's raw unacast optout files #f'/user/unity/match2/unacast/<datestr>
address_dict['un_in2']  = P024_un_in2 #last week's unacast combined optout file #f'/user/unity/match2/unacast/{lweek}/process/unacast_optouts_combined.parquet'


#Output
address_dict['un_out1'] = P024_un_out1 #f'/user/unity/match2/unacast/{bweek}/process/unacast_optouts_combined.parquet'


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Format Data'
proc[3] =   'Write Files'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Input: Number of Optout rows this week:'
stats_name['2']= 'Input: Number of Optout IDs this week:'
stats_name['3']= 'Input: Number of Optout rows last week:'
stats_name['4']= 'Input: Number of Optout IDs last week:'
stats_name['5']= 'Input: Number of Optout rows combined'
stats_name['6']= 'Input: Number of Optout IDs combined:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2,df3):
    stats= dict()
    stats['1']= df1.count() if df1 else 0
    stats['2']= df1.groupby('grid','advertiserid').count().count() if df1 else 0
    stats['3']= df2.count() if df2 else 0
    stats['4']= df2.groupby('grid','advertiserid').count().count() if df2 else 0
    stats['5']= df3.count() if df3 else 0
    stats['6']= df3.groupby('grid','advertiserid').count().count() if df3 else 0
    return stats



#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read in raw unacast data and optout files for bweek
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        now= datetime.datetime.now()
        nowdate = now.strftime("%Y-%m-%d")
        nowdate
        # Create list of dates
        pdays= {}
        for i in range(0,8):
            pdays[i]= minus_days(nowdate, i)
        
        pdays
        #
        pdayslst= list(pdays.values())
        pdayslst
        #
        datestr= ",".join(pdayslst)
        datestr
        datestr= f'{{{datestr}}}'
        datestr
        #
        try:
            new_column_names = ["grid", "advertiserid", "reported_date"]
            opt01 = spark.read.option("delimiter", "|").csv(f"{address_dict['un_in1']}/{datestr}/from_unacast_optout__*.csv.gz")
            opt01 = opt01.toDF(*new_column_names)
        except:
            opt01 = 0
            email_process("No Optout File received from Unacast this week", subject="Unacast Optout Ingestion", mail_to="emsactivatealerts@experian.com")
            

        try:
            # Read in previous week's optout file
            prev_opt= spark.read.parquet(address_dict['un_in2'])
        except:
            prev_opt = 0
            
        #
       #---------------------------------------------------------------------------------------------------
    #
    # Combine this week's optouts with previous week's optouts if it exists
    with doing_xy(process_num= 2):
        if opt01: 
            if prev_opt:
                # Combine with previous optouts
                opt02 = prev_opt.unionByName(opt01).dropDuplicates()
            else:
                opt02 = opt01
        elif prev_opt:
            # If no optout file received this week, but there is a previous optout file, use that
            opt02 = prev_opt
        else:
            # If no optout file received this week, and no previous optout file, set to 0
            opt02 = 0

        #add a flag in optout data
        if opt02:
            opt03= opt02.select("grid", "advertiserid", "reported_date").dropDuplicates()
        else:
            opt03 = 0
        #---------------------------------------------------------------------------------------------------
    #
    # Write data only if there is any addition to previous optout file
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        if opt01 or (prev_opt and opt01):
            opt03.write.parquet(address_dict['un_out1'], mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    #   
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(opt01,prev_opt,opt03)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except Exception as e:
        result= f"{result}\n\n{emoji['fail']} Stats failed - {e}"
        email_process(result, email_subject)
#
except Exception as e:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]} \n\n {e}"
    email_process(result, email_subject)


