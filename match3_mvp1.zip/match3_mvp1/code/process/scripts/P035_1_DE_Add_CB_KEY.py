
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#de_in1  = 'match2/de/2022-12-19/from_de__*.csv'
#de_out1 = 'match2/process/2022-12-19/tmp.parquet'
#de_out2 = 'match2/process/2022-12-19/de01.parquet'

dt_in1  = P035_1_dt_in1
de_in2  = P035_1_de_in2
de_out1 = P035_1_de_out1


email_subject= '*** P035_1: MERGE ON CB_KEY TO DE FILE ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n de_in1 = {dt_in1}"
result= f"{result}\n\n de_out1 = {de_in2}"
result= f"{result}\n\n de_out2 = {de_out1}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Merge on cb_key'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        dt01= spark.read.parquet(dt_in1)
        de01= spark.read.parquet(de_in2)
        
    # Do join
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        dt02= dt01.groupby('cb_key_household', 'UDPRN').count().drop('count')
        de02= dt02.join(de01, 'UDPRN', 'inner')
        de02.write.parquet(de_out1, mode= 'overwrite')
        de03= spark.read.parquet(de_out1)
        
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P035_1_stats_prev
        
        stats_name['HH0'] = 'Number of HHs on Taxonomy:'
        stats_name['HH1'] = 'Number of HHs on DE:'
        
        stats['HH0'] = dt01.groupby('cb_key_household').count().count()
        stats['HH1'] = de03.groupby('cb_key_household').count().count()
        
        stats_perc['HH0']   = round(stats['HH0']  / stats_prev['HH0'] - 1, 4)
        stats_perc['HH1']   = round(stats['HH1']   / stats_prev['HH1'] - 1, 4)
        
        stats_tl['HH0']= traffic_lights(stats_perc['HH0'])
        stats_tl['HH1']= traffic_lights(stats_perc['HH1'])
        
        result= f"{result}\n\n{stats_tl['HH0']} {stats_name['HH0']} [{stats['HH0']: ,}] ({stats_perc['HH0']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['HH1']} {stats_name['HH1']} [{stats['HH1']: ,}] ({stats_perc['HH1']: 15.2%})"        
        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)






