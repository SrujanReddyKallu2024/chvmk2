
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import pandas as pd
import contextlib                                                               
from pyspark.sql import SparkSession
import json

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

script_code= 'P020_2'

# File locations in/out
#dt_in1  = '/user/unity/datascience/match2/Digital_taxonomy/process/Taxonomy_Suppress.parquet' 
#dt_in2  = '/user/unity/datascience/match2/lat_lon/UDPRN_lat_lon.parquet'
#dt_out1= '/user/unity/datascience/match2/process/to_de.csv'
#dt_out2= '/data/griffin/output'

dt_in1  = P020_2_dt_in1
dt_in2  = P020_2_dt_in2
dt_out1 = P020_2_dt_out1
dt_out2 = P020_2_dt_out2

result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n dt_in1: {dt_in1}"
result= f"{result}\n\n dt_in2: {dt_in2}"
result= f"{result}\n\n dt_out1: {dt_out1}"
result= f"{result}\n\n dt_out2: {dt_out2}"

email_subject= '*** P020_2: OUTPUT FILE FOR DE TO LOCAL ***'


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read Taxonomy suppression flag file'
proc[2]= 'Read UDPRN Lat/Lon lookup'
proc[3]= 'Select cb_key & UDPRN'
proc[4]= 'Agg. to cb_key + UDPRN'
proc[5]= 'Merge Lat/Lon to cb_key'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

result= f'{result}\n\n--- PROCESS HEALTH ---------------------------------'

try:
    # Read in taxanony
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        dts01= spark.read.parquet(dt_in1)
        UDPRN01= spark.read.parquet(dt_in2)
        #---------------------------------------------------------------------------------------------------
    
    # Read in UDPRN+Lat+Lon
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        dts02= dts01.where(F.col('flag_UDPRN').isNull())
        dts03= dts02.groupBy('UDPRN').count().drop('count')
        #---------------------------------------------------------------------------------------------------
    
    # Keep cb_key_household and UDPRN
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        UDPRN02= dts03.join(UDPRN01,'UDPRN','inner')
        
        UDPRN03= UDPRN02 \
            .withColumnRenamed('Lat', 'Latitude') \
            .withColumnRenamed('Lon', 'Longitude')
        
        UDPRN04= UDPRN03.select('UDPRN', 'Latitude', 'Longitude')
        #---------------------------------------------------------------------------------------------------
    
    # Accumulate to cb_key_household (and UDPRN)
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        UDPRN04.write.csv(dt_out1, header= True, mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    
    # Join Lat/Lon to cb_key_household
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        now= datetime.datetime.now()
        nowdate = now.strftime("%Y-%m-%d")
        
        dt_out3= os.path.join(dt_out2, 'temp.csv')
        dt_out4= os.path.join(dt_out2, f'to_de__{nowdate}.csv')
        
        os.system(f"hdfs dfs -getmerge {dt_out1} {dt_out3}")
        os.system("awk 'BEGIN{f=\"\"}{if($0!=f){print $0}if(NR==1){f=$0}}' " + dt_out3 + " > " + dt_out4)
        os.system(f"rm {dt_out3}")
        #---------------------------------------------------------------------------------------------------
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        
        stats_name['Tax']   = 'Taxonomy, no. of Rows:'
        stats_name['UDPRN'] = 'UDPRN, no. of Rows:'
        stats_name['Out']   = 'Output, no. of Rows:'
        
        stats['Tax']    = dts01.count()
        stats['UDPRN']  = UDPRN01.count()
        stats['Out']    = UDPRN04.count()
        
        stats_perc['Tax'] = round(stats['Tax']      / stats_prev['Tax'] - 1, 4)
        stats_perc['UDPRN']= round(stats['UDPRN']   / stats_prev['UDPRN']- 1, 4)
        stats_perc['Out'] = round(stats['Out']      / stats_prev['Out'] - 1, 4)
        
        stats_tl['Tax']= traffic_lights(stats_perc['Tax'])
        stats_tl['UDPRN']= traffic_lights(stats_perc['UDPRN'])
        stats_tl['Out']= traffic_lights(stats_perc['Out'])
        
        result= f"{result}\n\n{stats_tl['Tax']} {stats_name['Tax']} [{stats['Tax']: ,}] ({stats_perc['Tax']: 15.2%})"
        result= f"{result}\n\n{stats_tl['UDPRN']} {stats_name['UDPRN']} [{stats['UDPRN']: ,}] ({stats_perc['UDPRN']: 15.2%})"
        result= f"{result}\n\n{stats_tl['Out']} {stats_name['Out']} [{stats['Out']: ,}] ({stats_perc['Out']: 15.2%})"
        
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)



