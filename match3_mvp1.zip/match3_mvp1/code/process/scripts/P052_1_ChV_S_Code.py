import os
import sys
from code.process.funcs.process_functions import email_process
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("P052_1_ChV_S_Code.py").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs  = os.path.join(dir01, 'configs')
dictions = os.path.join(dir01, 'dictionaries')
funcs    = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0, 3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run == 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all = timer()

chv01_in1 = P052_1_cv_in1
tax01_in1 = P052_1_tx_in2
ip_out1   = P052_1_cv_out1

script_code = 'P052_1'
email_subject = '*** P052_1: ChV_S_Code ***'

result = '--- FILES ----------------------------------------------'
result = f"{result}\n\n chv01_in1 = {chv01_in1}"
result = f"{result}\n\n tax01_in1 = {tax01_in1}"
result = f"{result}\n\n ip_out1 = {ip_out1}"

#--------------------------------------------------------

# Dictionary of Process labels
proc = dict()
proc[1] = 'Read in files'
proc[2] = 'Collapse S_Codes by HH and merge to ChV'
proc[3] = 'Preprocess and write out file'

# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('IP').count().count()
    stats['3']= df1.groupby('SEGID').count().count()
    return stats

#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result = f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num = 1):
        #------------------------------------------------------------------------------------------------
        tax01 = spark.read.parquet(tax01_in1)
        chv01 = spark.read.parquet(chv01_in1).select('cb_key_household', 'ip')

    with doing_xy(process_num = 2):
        tax02 = tax01.groupBy('cb_key_household').agg(F.concat_ws(",", F.collect_list("S_Code")).alias("SEGID"))
        j01 = chv01.join(tax02, 'cb_key_household', 'inner')

    with doing_xy(process_num = 3):
        j02 = j01.withColumn('DPID', F.lit(857)) \
			     .withColumnRenamed('ip', 'IP') \
			     .withColumn('COUNTRY', F.lit('GB')) \
			     .withColumn('UIDTYPE', F.lit('45')) \
			     .withColumn('USERID', F.lit(''))

        j03 = j02.select('DPID', 'USERID', 'SEGID', 'IP', 'COUNTRY', 'UIDTYPE', 'cb_key_household')
        j03.write.parquet(ip_out1, mode= 'overwrite')
        
# CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result = f"{result}\n\n{headers['qstats']}"

        # Loads stats from previous run (max 2 weeks ago)
        stats_prev = stats_prev_load(quick_stats_path, script_code, bweek)

        # Use function to create this weeks stats
        stats = quick_stats_definitions(j03)

        # Percentage change
        stats_perc, stats_tl, result = quick_stats(stats, stats_name, stats_prev, result)

        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        
        end_all = timer()
        time_all = str(datetime.timedelta(seconds = round(end_all - start_all, 0)))
        
        result = f"{result}\n\n{headers['time']}"
        result = f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result = f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)

except:
    result = f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)