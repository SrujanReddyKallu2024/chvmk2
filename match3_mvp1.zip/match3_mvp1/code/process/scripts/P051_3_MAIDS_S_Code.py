
# MAKE MORE THAN ONE SCRIPT

import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

from pyspark.sql.window import Window

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 
      

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

###################################################################



# Settings ------------------------------------------------------------------------------
script_code= 'P051_3' # For 'Quick Stats'
email_subject= '*** P051_3: MERGE S_CODES TO MAIDS ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()
address_dict['md_in1']  = P051_3_md_in1
address_dict['tx_in2']  = P051_3_tx_in2
address_dict['md_out1'] = P051_3_md_out1
address_dict


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Do join and dedup'
proc[3] =   'Write parquet'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Number of Rows:'
stats_name['2']= 'Number of MAIDS:'
stats_name['3']= 'Number of S_Codes:'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('maids').count().count()
    stats['3']= df1.groupby('S_Code').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read Digital Taxonomy
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        j12= spark.read.parquet(address_dict['md_in1'])
        tax01= spark.read.parquet(address_dict['tx_in2'])
        #---------------------------------------------------------------------------------------------------
    #
    # Check columns
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        j14= j12.select('cb_key_household', 'maids')
        j15= tax01.select('cb_key_household','S_Code').join(j14, 'cb_key_household', 'inner')
        j16= j15.groupby('maids','S_Code').count().drop('count')
        #---------------------------------------------------------------------------------------------------
    #
    # Filter none id5s
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        j16.write.parquet(address_dict['md_out1'], mode= 'overwrite')
        j17= spark.read.parquet(address_dict['md_out1']) 
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(j17)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)




