

import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#de_in1  = 'match2/de/2022-12-19/from_de__*.csv'
#de_out1 = 'match2/process/2022-12-19/tmp.parquet'
#de_out2 = 'match2/process/2022-12-19/de01.parquet'

de_in1  = P035_4_de_in1
ci_in2  = P035_4_ci_in2
de_out1 = P035_4_de_out1
de_out2 = P035_4_de_out2


email_subject= '*** P035_4: SPLIT DE TO DELETE & KEEP ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n de_in1 = {de_in1}"
result= f"{result}\n\n ci_in2 = {ci_in2}"
result= f"{result}\n\n de_out1 = {de_out1}"
result= f"{result}\n\n de_out2 = {de_out2}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read in files'
proc[2]= 'Create CIP flag'
proc[3]= 'Subset by flags'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        de01= spark.read.parquet(de_in1)
        #de01= spark.read.parquet('match2/process/2023-09-04/DE_rows_to_keep.parquet').drop('flag_pubip')
        cip01= spark.read.parquet(ci_in2)
    
    # Apply CIPS
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        cip02= cip01.groupby('host').count().drop('count').withColumnRenamed('host', 'ip')
        cip03= cip02.withColumn('flag_cip', F.lit('1'))
        
        de02= de01.join(cip03, 'ip', 'left')
        de03= de02 \
            .withColumn('flag_cip', F.when(F.col('flag_cip').isNull(), '0') \
            .otherwise('1'))
    
    # Create flag
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        de_0= de03.where((F.col('flag_chv') + F.col('flag_pubip') + F.col('flag_audip')== 0) | (F.col('flag_cip')== '1'))
        de_1= de03.where((F.col('flag_chv') + F.col('flag_pubip') + F.col('flag_audip')> 0) & (F.col('flag_cip')== '0'))
        
        de_0.write.parquet(de_out1, mode= 'overwrite')
        de_1.write.parquet(de_out2, mode= 'overwrite')
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P035_4_stats_prev
        
        stats_name['HH0'] = 'Number of HHs to be deleted:'
        stats_name['IP0'] = 'Number of IPs to be deleted:'
        stats_name['HH1'] = 'Number of HHs to keep:'
        stats_name['IP1'] = 'Number of IPs to keep:'
        
        stats['HH0'] = de_0.groupby('cb_key_household').count().count()
        stats['IP0'] = de_0.groupby('ip').count().count()
        stats['HH1'] = de_1.groupby('cb_key_household').count().count()
        stats['IP1'] = de_1.groupby('ip').count().count()
        
        stats_perc['HH0']   = round(stats['HH0']  / stats_prev['HH0'] - 1, 4)
        stats_perc['IP0']    = round(stats['IP0']   / stats_prev['IP0'] - 1, 4)
        stats_perc['HH1']  = round(stats['HH1'] / stats_prev['HH1']- 1, 4)
        stats_perc['IP1']    = round(stats['IP1'] / stats_prev['IP1']- 1, 4)
        
        stats_tl['HH0']= traffic_lights(stats_perc['HH0'])
        stats_tl['IP0']= traffic_lights(stats_perc['IP0'])
        stats_tl['HH1']= traffic_lights(stats_perc['HH1'])
        stats_tl['IP1']= traffic_lights(stats_perc['IP1'])
        
        result= f"{result}\n\n{stats_tl['HH0']} {stats_name['HH0']} [{stats['HH0']: ,}] ({stats_perc['HH0']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['IP0']} {stats_name['IP0']} [{stats['IP0']: ,}] ({stats_perc['IP0']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['HH1']} {stats_name['HH1']} [{stats['HH1']: ,}] ({stats_perc['HH1']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['IP1']} {stats_name['IP1']} [{stats['IP1']: ,}] ({stats_perc['IP1']: 15.2%})"
        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)

