
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#------------------------------------------------------------

scripts = os.path.dirname(__file__)
#/data/griffin/Process03/scripts
dir01 = os.path.split(scripts)[0]
#drr01= '/data/griffin/Process03/


configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 


#------------------------------------------------------------

# Input and Output locations
#dt_in1= '/user/unity/datascience/match2/ingest/Digital_taxonomy.csv'
#dt_out1= '/user/unity/datascience/match2/Digital_taxonomy/process/Digital_taxonomy.parquet'
dt_in1  = P010_1_dt_in1
dt_out1 = P010_1_dt_out1

result= '--- FILES ---'
result= f"{result}\n\n dt_in1: {dt_in1}"
result= f"{result}\n\n dt_out1: {dt_out1}"


email_subject= '*** P010_1: INGEST TAXONOMY ***'


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1] =   'Read text file'
proc[2] =   'Remove spaces from column names'
proc[3] =   'Write parquet'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

result= f'{result}\n\n--- PROCESS HEALTH ---'

try:
    # Read Digital Taxonomy
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        dt01= spark.read.csv(dt_in1, sep='|', header= True)
        #---------------------------------------------------------------------------------------------------
        
    # Replace spaces in column names
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        dt02= dt01.select([F.col(col).alias(col.replace(' ', '_')) for col in dt01.columns])
        #---------------------------------------------------------------------------------------------------
        
    # Write parquet 
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        dt02.write.parquet(dt_out1, mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
        
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS ---"
        
        stats_prev= P010_1_stats_prev
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        
        dt02= spark.read.parquet(dt_out1).select('cb_key_household', 'UDPRN').cache()
        dt03= spark.read.parquet(dt_out1)
        
        stats_name['total']     = 'Number of Rows:'
        stats_name['cb_key']    = 'Number of cb_keys:'
        stats_name['udprn']     = 'Number of UDPRNs:'
        
        stats['total']  = dt02.count()
        stats['cb_key'] = dt02.groupby('cb_key_household').count().count()
        stats['udprn']  = dt02.groupby('UDPRN').count().count()
        
        stats_perc['total'] = round(stats['total'] / stats_prev['total'] - 1, 4)
        stats_perc['cb_key']= round(stats['cb_key']/ stats_prev['cb_key']- 1, 4)
        stats_perc['udprn'] = round(stats['udprn'] / stats_prev['udprn'] - 1, 4)
        
        stats_tl['total']= traffic_lights(stats_perc['total'])
        stats_tl['cb_key']= traffic_lights(stats_perc['cb_key'])
        stats_tl['udprn']= traffic_lights(stats_perc['udprn'])
        
        result= f"{result}\n\n{stats_tl['total']} {stats_name['total']} [{stats['total']: ,}] ({stats_perc['total']: 15.2%})"
        result= f"{result}\n\n{stats_tl['cb_key']} {stats_name['cb_key']} [{stats['cb_key']: ,}] ({stats_perc['cb_key']: 15.2%})"
        result= f"{result}\n\n{stats_tl['udprn']} {stats_name['udprn']} [{stats['udprn']: ,}] ({stats_perc['udprn']: 15.2%})"
        #---------------------------------------------------------------------------------------------------
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)



