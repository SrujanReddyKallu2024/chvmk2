import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps
from pyspark.sql.types import StringType, IntegerType
import time

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")


#= NOTES ==========================================================================================

'''
For this script to be of use:
"P030_1_de_in1  = os.path.join(base, 'de', bweek, 'from_de*.csv*')" 
Needs to be changed to ...
"P030_1_de_in1  = os.path.join(base, 'de_fix', bweek, 'from_de*.csv*')"
in process_adresses.py
'''

#= SETTINGS =======================================================================================

bweek= '' 

# infolder01= '/user/unity/datascience/griffin/de'
# outfolder01= '/user/unity/datascience/griffin/de_bkp'
# outfolder02= '/user/unity/datascience/griffin/de_fix'

infolder01= '/user/unity/match2/de'
outfolder01= '/user/unity/match2/de_bkp'
outfolder02= '/user/unity/match2/de_fix'


# FUNCTIONS =======================================================================================

def latest_file(path, pattern=''):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    '''
    import subprocess
    import re
    files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    dirx= y[-1]
    return dirx

def last_Monday(date= datetime.date.today()):
    '''
    * Gives the date of the previous Monday. 
    * If the day is Monday then returns the imput date.
    * Default is input is today's date.
    * Returns string as 'YYYY-MM-DD'
    * Argument can be date object
    *Use:
        date= last_Monday()
        date= last_Monday(DateObject)
    '''
    bweek = date - datetime.timedelta(days=date.weekday())
    bweek_str= bweek.strftime("%Y-%m-%d")
    return bweek_str



#= MAIN ===========================================================================================

# Set the date of the beginning of week
if bweek== '':
    bweek= last_Monday()

bweek

# Create beginning of week folder
os.system(f'hdfs dfs -mkdir {outfolder01}/{bweek}')

# Get file name of DE file
filename= latest_file(f'{infolder01}/{bweek}', pattern= 'from_de__')
filename

# Get just the file name (as {filename} has location at the beginning)
filename2= os.path.basename(filename)
filename2

# Make a backup copy of DE file (do not delete this backup )
os.system(f'hdfs dfs -cp {filename} {outfolder01}/{bweek}/{filename2}') 

# Read DE file
x01= spark.read.csv(f'{filename}', header= True)
#x01.show()
# Write out file as parquet (first time)
x01.write.parquet(f'{outfolder02}/temp.parquet', mode= 'overwrite')
x01= spark.read.parquet(f'{outfolder02}/temp.parquet')

# Write out file as parquet (second time) this time it will be in parts [distributed](decided by system)
x01.write.parquet(f'{outfolder02}/temp2.parquet', mode= 'overwrite')

# Clean up a bit
os.system(f'hdfs dfs -rm -r {outfolder02}/temp.parquet')

# Read in distributed parquet files
x01= spark.read.parquet(f'{outfolder02}/temp2.parquet')
#x01.show()

# x01.groupby('UDPRN').count().count()
# x01.groupby('ip_address').count().count()
# x01.groupby('last_seen').count().count()

# Collect ip_address column into array per UDPRN
x02= x01.groupby('UDPRN').agg(F.collect_list('ip_address').alias('IP_ADDRESS'))
x03= x02.withColumn('IP_ADDRESS', F.concat_ws(',', 'IP_ADDRESS'))
#x03.show(truncate=False)

# Write out as temp parquet (could cache)
x03.write.parquet(f'{outfolder02}/temp3.parquet', mode= 'overwrite')
x04= spark.read.parquet(f'{outfolder02}/temp3.parquet')

# Write out as csv.gz (csv.gz is just the file extension, it is not actually compressed)
x04.repartition(1).write.csv(f'{outfolder02}/{bweek}/{filename2}', header= True, mode= 'overwrite')

# x05= spark.read.csv('datascience/griffin/de_fix/2025-01-27/from_de*.csv*', header= True)
# x05.count()
# x04.count()
# x05.show()

# Clean up
os.system(f'hdfs dfs -rm -r {outfolder02}/temp2.parquet')
os.system(f'hdfs dfs -rm -r {outfolder02}/temp3.parquet')

#==================================================================================================