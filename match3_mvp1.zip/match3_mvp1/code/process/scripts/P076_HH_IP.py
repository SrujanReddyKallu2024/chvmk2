
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps
import subprocess
import time

import json

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]
configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from process_adresses import bweek

#=====================
# bweek= '2023-10-09'
#=====================


spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# x01= spark.read.parquet('match2/process/2023-10-02/uid_hh.parquet')
# x02= spark.read.parquet('match2/process/2023-10-02/uid_hh_dd.parquet')
# x03= spark.read.parquet('match2/process/2023-10-02/uid_s_code_pub.parquet')

# x01.show()
# x02.show()
# x03.show()

# # P050_3_uid_out1 = os.path.join(base, 'process', bweek, 'uid_hh_pp.parquet')
# # P050_3_uid_out2 = os.path.join(base, 'process', bweek, 'uid_hh_pp_s_code.parquet')
# # P050_3_uid_out3 = os.path.join(base, 'process', bweek, 'uid_S_Code_initial.parquet')
# # P050_3_uid_out4 = os.path.join(base, 'process', bweek, 'uid_S_Code.parquet')
# # P050_3_uid_out5 = os.path.join(base, 'process', bweek, 'uid_s_code_cal.parquet')

# out1= spark.read.parquet('match2/process/2023-10-02/uid_hh_pp.parquet')
# out2= spark.read.parquet('match2/process/2023-10-02/uid_hh_pp_s_code.parquet')
# out3= spark.read.parquet('match2/process/2023-10-02/uid_S_Code_initial.parquet')
# out4= spark.read.parquet('match2/process/2023-10-02/uid_S_Code.parquet')
# out5= spark.read.parquet('match2/process/2023-10-02/uid_s_code_cal.parquet')

# out1.show()
# out2.show()
# out3.show()
# out4.show()
# out5.show()


# x1= spark.read.parquet('match2/process/2023-10-02/uid_hh_pp_s_code.parquet')
# x2= spark.read.parquet('match2/process/2023-10-02/uid_hh.parquet')

# Functions --------------------------------------------------------------
def minus_days(date, days):
    pweek= datetime.datetime.strptime(date, "%Y-%m-%d")-datetime.timedelta(days= days)
    pweek= pweek.strftime("%Y-%m-%d")
    return pweek

def file_exists(path):
    proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', path])
    proc.communicate()
    return proc.returncode

#-------------------------------------------------------------------------
blg01= spark.read.parquet(f'match2/process/{bweek}/uid_s_code_pub_all2.parquet')
blg01.show()

process_path= '/user/unity/match2/process'

pweeks= {}
for i in range(0,4):
    pweeks[i]= minus_days(bweek, i*7)

pweeks_add= {}
for key, value in pweeks.items():
    if file_exists(f'{process_path}/{value}/uid_hh.parquet')== 0:
        pweeks_add[key]= value


for x, (key, value) in enumerate(pweeks_add.items()):
    temp1= spark.read.parquet(f'{process_path}/{value}/uid_hh.parquet')
    temp2= blg01.where(F.col('week_id')== key).select(F.col('USERID').alias('uid'))
    temp3= temp1.join(temp2, 'uid', 'inner')
    temp_hh= temp3.groupby('cb_key_household').count().drop('count')
    temp_hh= temp_hh \
                .withColumn('week_id', F.lit(key)) \
                .withColumn('week', F.lit(value))
    temp_ip= temp3.groupby('ip').count().drop('count')
    temp_ip= temp_ip \
                .withColumn('week_id', F.lit(key)) \
                .withColumn('week', F.lit(value))
    if x== 0:
        hh_all= temp_hh
        ip_all= temp_ip
    else:
        hh_all= hh_all.union(temp_hh)
        ip_all= ip_all.union(temp_ip)

hh_all.cache()
ip_all.cache()

hh_all.count()
ip_all.count()
hh_all.show()
ip_all.show()


# hh in week 0
hh_all.where(F.col('week_id')== 0).groupby('cb_key_household').count().count()
# hh in week 1
hh_all.where(F.col('week_id')== 1).groupby('cb_key_household').count().count()
# hh in week 2
hh_all.where(F.col('week_id')== 2).groupby('cb_key_household').count().count()
# hh in week 3
hh_all.where(F.col('week_id')== 3).groupby('cb_key_household').count().count()

# ip in week 0
ip_all.where(F.col('week_id')== 0).groupby('ip').count().count()
# ip in week 1
ip_all.where(F.col('week_id')== 1).groupby('ip').count().count()
# ip in week 2
ip_all.where(F.col('week_id')== 2).groupby('ip').count().count()
# ip in week 3
ip_all.where(F.col('week_id')== 3).groupby('ip').count().count()

bweek

hh_all.write.parquet(f'match2/process/{bweek}/hh_all.parquet', mode= 'overwrite')
ip_all.write.parquet(f'match2/process/{bweek}/ip_all.parquet', mode= 'overwrite')