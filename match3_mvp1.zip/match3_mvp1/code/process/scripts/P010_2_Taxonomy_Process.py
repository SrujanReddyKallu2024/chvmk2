
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 
    
        
#------------------------------------------------------------

start_all= timer()

# Input and Output locations
#dt_in1= 'datascience/match2/Digital_taxonomy/process/dt_temp.parquet'
#dt_in2= 'datascience/match2/Digital_taxonomy/mc.parquet'
#dt_in3= '/data/griffin/taxonomy/S_Code.csv'
#dt_out1= 'datascience/match2/Digital_taxonomy/process/dt_long_cb_key_hh.parquet'
#dt_out2= 'datascience/match2/Digital_taxonomy/process/dt_long_cb_key_hh_2.parquet'
#dt_out3= 'datascience/match2/Digital_taxonomy/process/dt_long_cb_key_hh_dd.parquet'
#dt_out4= 'datascience/match2/Digital_taxonomy/process/dt_long_mc.parquet'
#dt_out5= 'datascience/match2/Digital_taxonomy/process/dt_long_mc_dd.parquet'
#dt_out6= 'datascience/match2/Digital_taxonomy/process/dt_long_dd.parquet'
#dt_out7= 'datascience/match2/Digital_taxonomy/process/dt_long_mc_dd_ss.parquet'

dt_in1  = P010_2_dt_in1
dt_in3  = P010_2_dt_in3
dt_out1 = P010_2_dt_out1
dt_out2 = P010_2_dt_out2
dt_out3 = P010_2_dt_out3
dt_out4 = P010_2_dt_out4


email_subject= '*** P010_2: Process Taxonomy ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n dt_in1 = {dt_in1}"
#result= f"{result}\n\n dt_in2 = {dt_in2}"
result= f"{result}\n\n dt_in3 = {dt_in3}"
#result= f"{result}\n\n de_out1 = {dt_out1}"
result= f"{result}\n\n de_out2 = {dt_out2}"
result= f"{result}\n\n de_out3 = {dt_out3}"
result= f"{result}\n\n de_out4 = {dt_out4}"
#result= f"{result}\n\n de_out5 = {dt_out5}"
#result= f"{result}\n\n de_out6 = {dt_out6}"
#result= f"{result}\n\n de_out7 = {dt_out7}"




##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1] =   'Read in Files'
proc[2] =   'Taxonomy to long form'
proc[3] =   'Filter C_Code columns'
proc[4] =   'Group by cb_key_household'
proc[5] =   'Join MCs to Digital Taxonomy'
proc[6] =   'Group by Microcells'
proc[7] =   'Group by C_code'
proc[8] =   'Attach S_Codes'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read Full Taxonomy.
    # Read in Microcell lookup
    # Read in Taxonomy C_Code to S_Code lookup.
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        dt01= spark.read.parquet(dt_in1)
        S_Code= pd.read_csv(dt_in3)
        #---------------------------------------------------------------------------------------------------
    
    # Get list of Taxonomy C_codes.
    # Transpose into Long form
    # Write out as parquet.
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        c01= dt01.columns
        cols= [x for x in c01 if ((x[0]== 'C') and (True in [char.isdigit() for char in x]) and (len(x) in [6,7,8,9,10,11]))]
        
        kvs= F.explode(F.array([F.struct(F.lit(c).alias("key"), F.col(c).alias("val")) for c in cols])).alias("kvs")
        dt02= dt01.select(['cb_key_household'] + [kvs]).select(['cb_key_household'] + ["kvs.key", "kvs.val"])
        dt03_2= dt02.filter(F.col("val").isNotNull())
        
        dt03_2.write.parquet(dt_out2, mode= 'overwrite')
        dt04= spark.read.parquet(dt_out2)
        #---------------------------------------------------------------------------------------------------
    
    # Group by 'cb_key_household'.
    # Write out to parquet.
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        S_Code2= ps.from_pandas(S_Code)
        S_Code3= S_Code2.to_spark()
        S_Code4= S_Code3.withColumn('S_Code', F.regexp_replace('S_Code', r'^S[0]*', 'S'))
        
        S_Code_Dist= dt04.groupby('key', 'val').count().withColumnRenamed('count','adults')
        S_Code_Dist= S_Code_Dist.join(S_Code4, ['key', 'val'], 'inner')
        
        S_Code_Dist.write.parquet(dt_out3, mode= 'overwrite')
        
        dt05= dt04.groupBy('cb_key_household', 'key', 'val').count().withColumnRenamed('count', 'PP')
        #dt07= dt05.join(S_Code4, ['key', 'val'], 'inner')
        dt07= dt05.join(F.broadcast(S_Code4), ['key', 'val'], 'inner') # <-- faster
        
        dt07.write.parquet(dt_out4, mode= 'overwrite')
        dt08= spark.read.parquet(dt_out4)   
        #---------------------------------------------------------------------------------------------------
    
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P010_2_stats_prev
        
        stats_name['tax_p_total']   = 'Person level long form, Total:'
        #stats_name['tax_h_total']  = 'HH level long form, Total:'
        #stats_name['tax_mc_total'] = 'MC level long form, Total:'
        #stats_name['seg_total']    = 'Segments Total'
        
        stats['tax_p_total']    = dt08.count()
        #stats['tax_h_total']   = dt05.count()
        #stats['tax_mc_total']  = dt09.count()
        #stats['seg_total']     = dt11.count()
        
        stats_perc['tax_p_total']   = round(stats['tax_p_total']  / stats_prev['tax_p_total']- 1, 4)
        #stats_perc['tax_h_total']  = round(stats['tax_h_total']  / stats_prev['tax_h_total']- 1, 4)
        #stats_perc['tax_mc_total'] = round(stats['tax_mc_total'] / stats_prev['tax_mc_total']- 1, 4)
        #stats_perc['seg_total']    = round(stats['seg_total']    / stats_prev['seg_total']- 1, 4)
        
        stats_tl['tax_p_total']     = traffic_lights(stats_perc['tax_p_total'])
        #stats_tl['tax_h_total']    = traffic_lights(stats_perc['tax_h_total'])
        #stats_tl['tax_mc_total']   = traffic_lights(stats_perc['tax_mc_total'])
        #stats_tl['seg_total']      = traffic_lights(stats_perc['seg_total'])
        
        result  = f"{result}\n\n{stats_tl['tax_p_total']} {stats_name['tax_p_total']} [{stats['tax_p_total']: ,}] ({stats_perc['tax_p_total']: 15.2%})"
        #result = f"{result}\n\n{stats_tl['tax_h_total']} {stats_name['tax_h_total']} [{stats['tax_h_total']: ,}] ({stats_perc['tax_h_total']: 15.2%})"
        #result = f"{result}\n\n{stats_tl['tax_mc_total']} {stats_name['tax_mc_total']} [{stats['tax_mc_total']: ,}] ({stats_perc['tax_mc_total']: 15.2%})"
        #result = f"{result}\n\n{stats_tl['seg_total']} {stats_name['seg_total']} [{stats['seg_total']: ,}] ({stats_perc['seg_total']: 15.2%})"
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)



#43,55,293,019