
"""
 Self contained script for Custom Segments:
 -----------------------------------------
 
 This could use system function but probably better to be 
 self contained for now as it is separate from the main process.
"""

'''
Change csv to xlsx - done
Check missing meta data - done
'''

'''
Add file use functionality - done
Check S_Code are usable - done
'''

import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import pandas as pd
import pyspark.pandas as ps
import contextlib                                                               
from pyspark.sql import SparkSession

import subprocess
import re

#---------------------------------------------------------------------

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#---------------------------------------------------------------------

start_all= timer()

bweek= "" # <--- Change if certain date is needed. yyyy-mm-dd.
#Custom_Buyer1_Advertiser1_Name1_yyyy-mm-dd <--- custom segemnt name pattern


# FUNCTIONS -----------------------------------------------------------

def list_files(path):
    '''
        List file names from given directory
    '''
    import subprocess
    import re
    try:
        files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
        x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
        y= [os.path.split(x1)[1] for x1 in x]
        return y
    except:
        return []

def file_vintage(file, directory, week):
    pweek= datetime.datetime.strptime(week, "%Y-%m-%d")-datetime.timedelta(days= 7)
    pweek= pweek.strftime("%Y-%m-%d")
    if file in list_files(os.path.join(directory,week)):
        return week
    elif file in list_files(os.path.join(directory,pweek)):
        return pweek
    else:
        return ''

def last_Monday(date= datetime.date.today()):
    '''
    * Gives the date of the previous Monday. 
    * If the day is Monday then returns the imput date.
    * Default is input is today's date.
    * Returns string as 'YYYY-MM-DD'
    * Argument can be date object
    *Use:
        date= last_Monday()
        date= last_Monday(DateObject)
    '''
    bweek = date - datetime.timedelta(days=date.weekday())
    bweek_str= bweek.strftime("%Y-%m-%d")
    return bweek_str

def email_custom(subprocess, subject, add_to):
    '''
        Function that sends email given
        the subject, body and recipient.
    '''
    import smtplib
    from email.mime.text import MIMEText
    
    msg = MIMEText(subprocess)
    msg['Subject'] = subject
    recipients= [add_to,'emsactivate@experian.com']
    msg['From'] = 'emsactivate@experian.com' # from config_process
    msg['To'] = ",".join(recipients)
    
    # Send the message via our own SMTP server, but don't include the
    # envelope header.
    s = smtplib.SMTP('localhost')
    s.sendmail(msg['From'], recipients, msg.as_string())
    s.quit()


def apply_logic():
    '''
        Function that parses the logical statement 
        and applies it to the data.
    '''
    lst_log= []
    lst_df= []
    flag= 0
    print(logic2)
    for pos, x in enumerate(logic2):
        #print(x)
        if x in ['&','|','!']:
            lst_log.append(x)
            flag= 1
        if x== '[':
            posb2= logic2[pos:].find(']')
            seg1= logic2[pos:][1: posb2]
            seg2= int(re.sub(r'^S[0]*', '', seg1))
            print('-----------------', seg2)
            # Capture non-existent Code
            if seg2 not in S_Code.values:
                error_rule[1]= seg1
                break
            #print(seg2)
            if flag==1:
                #print('------1')
                #lst_df.append(x06.where(F.col('S_Code')== seg2).drop('S_Code'))
                tmp= spark.read.parquet(f"{tax_in1}/S_Code={seg2}")
                lst_df.append(tmp)
                #lst_df[-1].show()
                flag= 0
            elif flag==0:
                if lst_log[-1]== '|':
                    #print('------2')
                    #lst_df[-1]= lst_df[-1].union(x06.where(F.col('S_Code')== seg2).drop('S_Code'))
                    tmp= spark.read.parquet(f"{tax_in1}/S_Code={seg2}").drop('S_Code')
                    lst_df[-1]= lst_df[-1].union(tmp)
                    lst_df[-1]= lst_df[-1].groupby('uid2').count().drop('count')
                elif lst_log[-1]== '&':
                    #print('-------3')
                    #lst_df[-1]= lst_df[-1].join(x06.where(F.col('S_Code')== seg2).drop('S_Code'), 'uid2', 'inner')
                    tmp= spark.read.parquet(f"{tax_in1}/S_Code={seg2}").drop('S_Code')
                    lst_df[-1]= lst_df[-1].join(tmp, 'uid2', 'inner')
                #lst_df[-1].show()
        if x== ')':
            if lst_log[-1]== '!':
                lst_df[-1]= lst_df[-1].withColumn('flag', F.lit(1))
                #lst_df[-1].show()
                lst_df[-1]= uni.join(lst_df[-1], 'uid2', 'left')
                #lst_df[-1].show()
                lst_df[-1]= lst_df[-1].where(F.col('flag').isNull()).drop('flag')
                #lst_df[-1].show()
            lst_log.pop()
            if len(lst_df)> 1:
                if lst_log[-1]== '|':
                    lst_df[-2]= lst_df[-2].union(lst_df[-1])
                    lst_df[-2]= lst_df[-2].groupby('uid2').count().drop('count')
                    #lst_df[-1].show()
                    #lst_df[-2].show()
                    lst_df.pop()
                if lst_log[-1]== '&':
                    lst_df[-2]= lst_df[-2].join(lst_df[-1], 'uid2', 'inner')
                    #lst_df[-1].show()
                    #lst_df[-2].show()
                    lst_df.pop()
    return lst_df

def logic_check_next_char(f_char, f_logic, f_allowed):
    '''
        Function which given a character, checks
        the next character against a list of allowed
        characters.
        f_char= character to check.
        f_logic= string to check.
        f_allowed= set of allowed characters
    '''
    # Find all the pos of character in string
    str_pos= re.finditer(f_char,f_logic)
    
    #iterate over all occurances of char
    for char in str_pos:
        # check the next char
        if f_logic[char.start()+1:char.start()+2] not in f_allowed:
            print('fail')
            return False
    return True

def logic_check_next_char_iter(f_logic_iter, f_chars_iter):
    '''
        Iterative wrapper for the logic_check_next_char
        function.
    '''
    for f_x in f_chars_iter:
        if f_x.isnumeric(): f_x2= '999'
        else: f_x2= f_x
        print(f_x)
        if not logic_check_next_char(f_x, f_logic_iter, dct_allowed[f_x2]):
            return False
    return True


# - Dictionaries -----------------------------------------------------

# NOT,AND,OR,(),[],S,0,1,2,3,4,5,6,7,8,9,','

decimals= set([str(x) for x in range(10)])
allowed= {'A','N','D','O','R','N','T','S','(',')','[',']',','}.union(decimals)
allowed_iter= {'A','N','D','O','R','N','T','S','\(','\)','\[','\]',','}.union(decimals)
allowed_iter  

dct_allowed= {}
dct_allowed.update({'N': {'O','D'}})
dct_allowed.update({'O': {'T','R'}})
dct_allowed.update({'T': {'('}})
dct_allowed.update({'A': {'N'}})
dct_allowed.update({'D': {'('}})
dct_allowed.update({'R': {'('}})
dct_allowed.update({'\(': {'N','O','T','A','D','R','['}})
dct_allowed.update({'\)': {'',',',')'}})
dct_allowed.update({'\[': {'S'}.union(decimals)})
dct_allowed.update({'\]': {',',')'}})
dct_allowed.update({'S': decimals})
dct_allowed.update({'999': {']'}.union(decimals)})
dct_allowed.update({',': {'[','N','A','O'}})

# Error rules for logic funtion
error_rule= {}
error_rule.update({1:'0'})
error_rule.update({2:'0'})
error_rule.update({3:'0'})

#---------------------------------------------------------------------

# Get date of start of week (if not already set manually
if bweek == '':
    bweek= last_Monday()

week_uid= file_vintage('uid2_s_code2.parquet', '/user/unity/match2/process', bweek)
week_uid

# Set file locations
tax_in1     = f"/user/unity/match2/process/{week_uid}/uid2_s_code2.parquet"
tax_in2     = f"/user/unity/match2/process/{week_uid}/uid_lookup.parquet"
mp_in3      = '/data/data_from_sts/marketplace_input_files'
cust_out1   = '/user/unity/match2/custom/data'

# Set local locations
dir_temp= '/data/data_to_sts/temp'
file_temp= 'for_cust_pub.tsv'

# Set meta data
dpid= '949'
pub_request= 'addseg'
dir_final= '/data/griffin'
#dir_final= '/data/data_to_sts/marketplaces/pubmatic' 
# uncomment ^ to actually upload to Pub

# Input --------------------------------------------------------------

uni= spark.read.parquet(tax_in2).select('uid2').cache()
uni.count()

lookup= spark.read.parquet(tax_in2)

S_Code= pd.read_csv('/data/griffin/S_CODE_PUBMATIC.csv')
S_Code['S_Code']= S_Code['S_Code'].apply(lambda x: int(re.sub(r'^S[0]*','',x)))

#---------------------------------------------------------------------

'''
-------------------
# MAIN CODE
-------------------
'''
# Get list of files (at least one should exist as it has been called by a bash script)
files= os.listdir('/data/data_from_sts/marketplace_input_files/')
files.remove('bkp') # wrap in an 'if' statement for existential reasons.
files

# Order list
def order_date_time(s):
    return s[-16:]

files= sorted(files, key= order_date_time)

# Get file name (should only be one) [ Not true anymore, it will process them in order ]
file_str= files[0]
file_str


# Read csv
#file= pd.read_csv(f"{mp_in3}/{file_str}") changed to xlsx
file = pd.read_excel(f"{mp_in3}/{file_str}", sheet_name='Sheet1')

# Move file to backup (now there should be no files in input folder)
os.system(f"mv {mp_in3}/{file_str} {mp_in3}/bkp")

# Clean (remove rows where all are missing)
#file2= file.dropna(how='all', axis= 'columns') keep all columns for now.
#file2= file.dropna(subset= ['email', 'rule'], axis= 'rows')
file2= file.dropna(how= 'all', axis= 'rows')
# Apply row id
file2['id']= file2.index+1 # not used
file2= file2.fillna('')
file

# flags to be used more than once
if "replace" in file_str.lower():
    return_flag= 'c'
else:
    return_flag= '0'
    

if return_flag== 'v':
    subject= "Custom Segment Volume Request"
elif return_flag== 'c':
    subject= "Custom Segment Create Request"
else:
    subject== "Custom Segment Request"

# Apply logic
if ("custom" in file_str.lower()) and (return_flag== 'c'):
    
    cont_flag= True
    
    # Number of requests
    row_count= file2.shape[0]
    
    # Initailize lists
    lst_codes= []
    lst_segs= []
    
    email_return= file2.loc[0]['email']
    if email_return=='': cont_flag= False
    
    # Personalize     
    forename= email_return.split('.')[0].title()
    
    result= f"Hi {forename},"
    result= f"{result}\n\nYour Custom Segments have been updated."
    result= f"{result}\n\nSubmitted filename: {file_str}"
    
    if cont_flag:
        
        for index, row in file2.iterrows():
            
            print(result)
            
            #custom_id       = row['id'] not used for now
            #email_return   = row['email'] email comes earlier
            logic           = row['rule'].upper()
            aud_name        = row['Audience Name (Mandatory)']
            CS_Code         = row['Source Segment Id (Mandatory)']
            
            result= f"{result}\n\n===================================================="
            result= f"{result}\n\nREQUEST:"
            result= f"{result}\n---------------"
            #result= f"{result}\nid= {custom_id}:"
            result= f"{result}\naudience name= {aud_name}"
            result= f"{result};                    \nrule= {logic}"
            if return_flag== 'c':
                result= f"{result};                    \nCS_Code= {CS_Code}"
            
            result= f"{result}\n\nRESULT:"
            result= f"{result}\n---------------"
            
            # Attempt to capture some logic errors ----------------------------------
            if aud_name== '':
                result= f"{result}\nERROR: You have not supplied an audience name."
                continue
            if logic== '':
                result= f"{result}\nERROR: You have not supplied a rule."
                continue
            if logic.count('(')!=logic.count(')'):
                result= f"{result}\nERROR: The number of left parenthesis, in 'rule', is not equal to the number of right parenthesis"
                continue
            if not set(logic) <= allowed:
                result= f"{result}\nERROR: Your rule contains illegal characters"
                continue
            if ' ' in set(logic):
                result= f"{result}\nERROR: Your rule contains spaces, please correct and resubmit"
                continue
            if not logic_check_next_char_iter(logic, allowed_iter):
                result= f"{result}\nERROR: Your rule is illegal, please correct and resubmit"
                continue
            #-------------------------------------------------------------------------
            
            # Partly parse rule
            logic2= logic.replace('AND','&')
            logic2= logic2.replace('NOT','!')
            logic2= logic2.replace('OR','|')
            
            # Apply function
            lst= apply_logic()
            
            if not error_rule[1]== '0':
                result= f"{result}\nERROR: S_Code [{error_rule[1]}] is not currently available"
                continue
            # Volume
            volume= lst[0].count()
            result= f"{result}\nvolume= {volume}"
            
            # Append to lists to be used if creation was requested -------------
            if volume> 0:
                if return_flag== 'c':
                    scode= row['Source Segment Id (Mandatory)'] #change - done
                    
                    # UIDs
                    lst_segs.append(lst[0])
                    
                     # Append to list of S_Codes
                    lst_codes.append(scode)
                    result= f"{result}\n\nThe new volumes have been sent to Pubmatic"
            else:
                result= f"{result}: Please check your rule!"
                continue
                
            #-------------------------------------------------------------------
    
    result= f"{result}\n\n===================================================="
    result= f"{result}\n\nThe dataset used belongs to the process week beginning {week_uid}.          "
    end_all= timer()
    time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
    result= f"{result}\nTime taken to process: {time_all}."
    result= f"{result}\n\nThank you"
    result= f"{result}\n\nThe EMS Activate Team"    
    email_custom(result, subject, email_return)
    
    # Send Segment(s) to Pubmatic (if requested)
    if return_flag== 'c':
        
        if len(lst_segs)> 0:
        
            lst_codes2= [re.sub(r'^CS[0]*','CS',x) for x in lst_codes]
            lst_codes2
            
            for pos, x in enumerate(lst_segs):
                lst_segs[pos]= x.withColumn('S_Code', F.lit(lst_codes2[pos]))
            
            for pos, x in enumerate(lst_segs):
                if pos==0:
                    segs_all= x
                else:
                    segs_all= segs_all.union(x)
            
            segs_all2= segs_all.groupby('uid2').agg(F.collect_list('S_Code').alias('S_Code'))
            segs_all3= segs_all2.withColumn('SEGID', F.concat_ws(',', 'S_Code')).drop('S_Code')
            #segs_all3.show()
            
            segs_all4= segs_all3.join(lookup, 'uid2', 'inner') \
                .withColumnRenamed('uid', 'USERID') \
                .drop('uid2')
            
            segs_all5= segs_all4 \
                .withColumn('DPID', F.lit(949)) \
                .withColumn('IP', F.lit('')) \
                .withColumn('COUNTRY', F.lit('GB')) \
                .withColumn('UIDTYPE', F.lit('4'))
            
            segs_all6= segs_all5.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
            #segs_all6.show()
            
            output= f"{cust_out1}/{file_str}"
            segs_all6.write.csv(f"{cust_out1}/{file_str}", header= False, sep= '\t', mode= 'overwrite')
            
            dt_out1= output
            dt_out2= '/data/data_to_sts/temp/for_cust_pub.tsv'
            os.system(f"hdfs dfs -getmerge {dt_out1} {dt_out2}")
            
            os.system(
                "cd " + dir_temp + "\n" \
                "timestamp=$(date +%s%3N)\n" \
                "md5=$(md5sum " + file_temp + " | awk '{ print $1 }')\n" \
                "filename=" + dpid + "_" + pub_request + "_${timestamp}_${md5}.tsv.gz\n" \
                "gzip " + file_temp + "\n" \
                "mv " + file_temp + ".gz ${filename}\n" \
                "mv ${filename} " + dir_final
            )


x01= spark.read.csv('match2/custom/data/pubmatic_custom_replace_2023-09-21-14-48.xlsx', sep= '\t')
x01= x01.toDF('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
x01.show()

old01= spark.read.csv('match2/custom/data/pubmatic_custom_create_2023-09-20-17-23.xlsx', sep= '\t')
old02= spark.read.csv('match2/custom/data/pubmatic_custom_create_2023-09-19-14-54.xlsx', sep= '\t')
old03= old01.union(old02)
old03= old03.toDF('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
old03.show()

old03.groupby('SEGID').count().show()
old04= old03.groupby('USERID').count().drop('count')
old04.count()

x01.count()
x01.groupby('USERID').count().count()

old05= old04.join(x01.select('USERID'), 'USERID', 'left_anti')
old05.count()

old06= old05 \
    .withColumn('DPID', F.lit(949)) \
    .withColumn('IP', F.lit('')) \
    .withColumn('COUNTRY', F.lit('GB')) \
    .withColumn('UIDTYPE', F.lit('4')) \
    .withColumn('SEGID', F.lit(''))

old07= old06.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')

all01= x01.union(old07)
all02= all01 \
    .withColumn('IP', F.lit(''))
    
all01.count()
all01.groupby('USERID').count().count()
all01.groupby('SEGID').count().show()



dir_temp= '/data/data_to_sts/temp'
file_temp= 'for_cust_pub.tsv'

# Set meta data
dpid= '949'
pub_request= 'replaceseg'
dir_final= '/data/griffin'
#dir_final= '/data/data_to_sts/marketplaces/pubmatic' 
# uncomment ^ to actually upload to Pub

cust_out1= f'match2/custom/data/pubmatic/{bweek}'
file_str
all02.write.csv(f"{cust_out1}/{file_str}", header= False, sep= '\t', mode= 'overwrite')

dt_out1= f"{cust_out1}/{file_str}"
dt_out2= '/data/data_to_sts/temp/for_cust_pub.tsv'
os.system(f"hdfs dfs -getmerge {dt_out1} {dt_out2}")

os.system(
    "cd " + dir_temp + "\n" \
    "timestamp=$(date +%s%3N)\n" \
    "md5=$(md5sum " + file_temp + " | awk '{ print $1 }')\n" \
    "filename=" + dpid + "_" + pub_request + "_${timestamp}_${md5}.tsv.gz\n" \
    "gzip " + file_temp + "\n" \
    "mv " + file_temp + ".gz ${filename}\n" \
    #"mv ${filename} " + dir_final
)

