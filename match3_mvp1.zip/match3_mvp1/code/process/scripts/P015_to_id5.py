
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

#ip_in1     = '/user/unity/datascience/match2/ip/process/ip_all_agg_sup.parquet'
#ip_out1    = '/user/unity/datascience/match2/ip/process/to_de.csv'
#ip_out2    = '/data/griffin/output'

ip_in1  = P015_ip_in1
ip_in2  = P015_ip_in2
ip_out1 = P015_ip_out1
ip_out2 = P015_ip_out2

#ip_out1= '/user/unity/datascience/griffin/match2/id5/2023-11-06/to_id5.csv'

email_subject= '*** P015: OUTPUT FOR ID5 ***'

# Initiate results string with title of process
result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n ip_in1: {ip_in1}"
result= f"{result}\n\n ip_in1: {ip_in2}"
result= f"{result}\n\n ip_out1: {ip_out1}"
result= f"{result}\n\n ip_out2: {ip_out2}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Read file'
proc[2]= 'Add ChV MK2 IPs'
proc[3]= 'Add Unacast IPs'
proc[4]= 'Write to HDFS'
proc[5]= 'Write to local'



#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read parquet
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        chv01= spark.read.parquet(ip_in1)
        #uc01= spark.read.parquet(ip_in2)
        #---------------------------------------------------------------------------------------------------
    
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        chv02= chv01.withColumn('diff', F.round(F.datediff(F.col('last_seen'), F.col('first_seen'))/2, 0).cast('integer'))
        #
        chv03= chv02.selectExpr(
            "ip",
            "first_seen",
            "diff",
            "date_add(to_date(first_seen,'yyyy-MM-dd'),cast(diff as int)) as Timestamp")
        #
        # Take last 100 days (id5 uses a 90 days buffer!).
        today= datetime.date.today()
        today_100= today- datetime.timedelta(days= 100)
        today_100= today_100.strftime("%Y-%m-%d")
        today_100
        #
        chv04= chv03.where(F.col('Timestamp')>= F.lit(today_100))
        #
        chv05= chv04.groupby('ip').agg(F.max('Timestamp').alias('Timestamp'))
        #---------------------------------------------------------------------------------------------------
    
    # Write to HDFS
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        chv05.write.csv(ip_out1, header= True, mode= 'overwrite')
        chv06= spark.read.csv(ip_out1, header= True)
        #---------------------------------------------------------------------------------------------------
    
    # OLD ################################################################
    # Process dates                                               
    #with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        #first_seen= datetime.datetime.strptime(bweek, "%Y-%m-%d")-datetime.timedelta(days= 6)
        #first_seen= first_seen.strftime("%Y-%m-%d")
        #last_seen=  bweek
        #first_seen
        #last_seen
        #
        #chv01.groupby('chv_de_flag').count().show()
        #
        #chv01_2_2= chv01 \
        #    .withColumn('first_seen', F.when(F.col('chv_de_flag')== 'de', F.lit(first_seen)).otherwise(F.col('first_seen'))) \
        #   .withColumn('last_seen',  F.when(F.col('chv_de_flag')== 'de', F.lit(last_seen)).otherwise(F.col('last_seen')))
        #chv01_2_2.show()
        #
        #chv01_2= chv01_2_2 \
        #   .withColumn("datediff", F.round(F.datediff(F.col('last_seen'), F.col('first_seen'))/2, 0))
        #chv01_2.show()
        #
        #x= chv01_2.selectExpr(
        #    "ip",
        #    "first_seen",
        #    "datediff",
        #    "date_add(to_date(first_seen,'yyyy-MM-dd'),cast(datediff as int)) as inc_date")
        #
        #x2= x.groupby('ip', 'inc_date').count().drop('count')
        #---------------------------------------------------------------------------------------------------
    
    #with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        #uc02= uc01.where((F.col('flag_chv')== '1') | (F.col('flag_pubip')== '1'))
        #uc03= uc02.groupby('ip').agg(F.max('last').alias('Timestamp'))
        #uc03.show()
        #ip= x2.groupby('ip').count().drop('count')
        #ip.count()
        #
        #uc04= uc03.join(ip, 'ip', 'left_anti')
        #uc04.show()
        #uc04.count()
        #---------------------------------------------------------------------------------------------------
    
    # Write to HDFS
    #with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        #id04= x2.select(F.col('ip'), F.col('inc_date').alias('Timestamp'))
        #id04_1= id04.groupby('ip').agg(F.max('Timestamp').alias('Timestamp')) # <--- Changed this so that IPs are unique
        #id04_2= id04.union(uc04)
        #id04.groupby('ip').count().count()
        #id04_2.groupby('ip').count().count()
        #id04_1.write.csv(ip_out1, header= True, mode= 'overwrite')
        #id05= spark.read.csv(ip_out1, header= True)
        #---------------------------------------------------------------------------------------------------
    
    # Copy to local
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        today= datetime.date.today().strftime("%Y-%m-%d")
        dt1= ip_out1
        dt3= f'{ip_out2}/temp.csv'
        dt4= f'{ip_out2}/to_id5__{today}.csv'
        #os.system(f"rm {dt4}")
        os.system(f"hdfs dfs -getmerge {dt1} {dt3}")
        os.system("awk 'BEGIN{f=\"\"}{if($0!=f){print $0}if(NR==1){f=$0}}' " + dt3 + " > " + dt4)
        os.system(f"rm {dt3}")
        #---------------------------------------------------------------------------------------------------
    
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        
        stats_prev  = P015_stats_prev
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        
        stats_name['tot_in'] = 'Total number of rows sent:'
        stats_name['tot_out']= 'Number of unique IPs sent:'
        
        stats['tot_in']     = chv06.count()
        stats['tot_out']    = chv06.groupby('ip').count().count()
        
        stats_perc['tot_in']    = round(stats['tot_in']  / stats_prev['tot_in']- 1, 4)
        stats_perc['tot_out']   = round(stats['tot_out'] / stats_prev['tot_out']- 1, 4)
        
        stats_tl['tot_in']  = traffic_lights(stats_perc['tot_in'])
        stats_tl['tot_out'] = traffic_lights(stats_perc['tot_out'])
        
        result= f"{result}\n\n{stats_tl['tot_in']} {stats_name['tot_in']} [{stats['tot_in']: ,}] ({stats_perc['tot_in']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['tot_out']} {stats_name['tot_out']} [{stats['tot_out']: ,}] ({stats_perc['tot_out']: 15.2%})"        
        #---------------------------------------------------------------------------------------------------
        
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)





