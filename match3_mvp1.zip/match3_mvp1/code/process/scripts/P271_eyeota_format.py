
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 



# Settings ------------------------------------------------------------------------------
script_code= 'P271' # For 'Quick Stats'
email_subject= '*** P271: Eyeota Format ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['in1_eye'] = f'/user/unity/match2/process/{bweek}/uid_s_code_eye.parquet'
# Output
address_dict['out1_eye'] = f'/user/unity/match2/marketplaces/eyeota/{bweek}/eyeota.parquet'

# Input Test
#address_dict['in1_eye'] = f'/user/unity/datascience/griffin/match2/process/{bweek}/uid_s_code_eye.parquet'
# Output test
#address_dict['out1_eye'] = f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/{bweek}/eyeota.parquet'


# List of addresses to clean ------------------------------------------------------------
address_clean= []


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Transpose and Order S Codes'
proc[3] =   'Write to HDFS'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= 'Input: Number of rows:'
stats_name['2']= 'Input: Number of ID5s:'
stats_name['3']= 'Input: Number of S_Codes:'
stats_name['4']= 'Output: Number of rows:'
stats_name['5']= 'Output: Number of ID5s'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,df2):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= df1.groupby('uid').count().count()
    stats['3']= df1.groupby('S_Code').count().count()
    stats['4']= df2.count()
    stats['5']= df2.groupby('ID5').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read in files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        i01= spark.read.parquet(address_dict['in1_eye'])
        #---------------------------------------------------------------------------------------------------
    #
    # Format and Subset S_Codes
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        i01_1= i01.withColumn('S_Code2', F.regexp_replace('s_code', r'^S[0]*', '').cast(IntegerType()))
        i01_2= i01_1.sort('uid', 'S_Code2')
        i02= i01_2.groupby('uid').agg(F.collect_list('S_Code').alias('S_Code')) 
        i03= i02.withColumn('SEGID', F.concat_ws(',', 'S_Code')).drop('S_Code').withColumnRenamed('uid','ID5')
        #
        i04= i03.withColumn('COUNTRY', F.lit('GB'))  
        i05= i04.select('ID5','COUNTRY','SEGID')
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        i05.write.parquet(address_dict['out1_eye'], mode= 'overwrite')
        i06= spark.read.parquet(address_dict['out1_eye'])
        i06.show()
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(i01, i06)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)



