
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

start_all= timer()

script_code= 'P075'

# P075_pub_path   = '/user/unity/match2/marketplaces/pubmatic'
# P075_pub_out1   = os.path.join(base, 'process', bweek, 'uid_s_code_pub_all2.parquet')
# P075_pub_out2   = os.path.join(base, 'process', bweek, 'uid_s_code_pub_all.parquet')
# P075_pub_out3   = os.path.join(base, 'marketplaces', 'pubmatic', bweek, 'pubmatic.csv')
# P075_pub_out4   = '/data/data_to_sts/temp/for_pubmatic.tsv'

pub_path    = P075_pub_path
pub_out1    = P075_pub_out1
pub_out2    = P075_pub_out2
pub_out3    = P075_pub_out3 
pub_out4    = P075_pub_out4 

#pub_out1    = '/user/unity/datascience/griffin/x3.parquet'
#pub_out2    = '/user/unity/datascience/griffin/x4.parquet'
#pub_out3    = '/user/unity/datascience/griffin/x5.parquet'

#pub_out1= '/user/unity/datascience/griffin/match2/process/2023-09-25/uid_s_code_pub_all2.parquet'
#pub_out2= '/user/unity/datascience/griffin/match2/process/2023-09-25/uid_s_code_pub_all.parquet' 
#pub_out3= '/user/unity/datascience/griffin/match2/process/2023-09-25/x.csv'

email_subject= '*** P075: Add Pubmatic Backlog (3 weeks total) ***'


result= '--- FILES ----------------------------------------------'
result= f"{result}\n\n pub_path = {pub_path}"
result= f"{result}\n\n pub_out1 = {pub_out1}"
result= f"{result}\n\n pub_out2 = {pub_out2}"
result= f"{result}\n\n pub_out3 = {pub_out3}"
result= f"{result}\n\n pub_out4 = {pub_out4}"

##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Create date dictionary'
proc[2]= 'Check Backlogs exist'
proc[3]= 'Add previous weeks USERIDs'
proc[4]= 'Output Wide format USERID-SEGID parquet'
proc[5]= 'Output Long format UID-S_Code parquet'
proc[6]= 'Output week0 and week3 to tsv hdfs file'
proc[7]= 'Output to local, zip and rename'

#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---------------------------------"

try:
    # Read files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        pweeks= {}
        for i in range(0,4):
            pweeks[i]= minus_days(bweek, i*7)
        #---------------------------------------------------------------------------------------------------
    
    # Create flag
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        pweeks_add= {}
        for key, value in pweeks.items():
            if file_exists(f'{pub_path}/{value}/pubmatic.parquet')== 0:
                pweeks_add[key]= value
        #---------------------------------------------------------------------------------------------------
    
    # Create flag
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        for x, (key, value) in enumerate(pweeks_add.items()):
            if x== 0:
                all01= spark.read.parquet(f'{pub_path}/{value}/pubmatic.parquet').select('USERID', 'SEGID', 'UIDTYPE', 'IP')
                all01= all01.withColumn('week', F.lit(value))
                all01= all01.withColumn('week_id', F.lit(key))
                all01= all01.select('USERID', 'SEGID', 'UIDTYPE', 'IP', 'week', 'week_id')
            else:
                temp= spark.read.parquet(f'{pub_path}/{value}/pubmatic.parquet').select('USERID', 'SEGID', 'UIDTYPE', 'IP')
                miss01= temp.join(all01.select('USERID'), 'USERID', 'left_anti')
                miss01= miss01.withColumn('week', F.lit(value))
                miss01= miss01.withColumn('week_id', F.lit(key))
                if key== 3:
                    miss01= miss01.withColumn('SEGID', F.lit(''))
                miss01= miss01.select('USERID', 'SEGID', 'UIDTYPE', 'IP', 'week', 'week_id')
                all01= all01.union(miss01)
        #---------------------------------------------------------------------------------------------------
    
    with doing_xy(process_num= 4):
        #---------------------------------------------------------------------------------------------------
        all01.write.parquet(pub_out1, mode= 'overwrite')
        all01_2= spark.read.parquet(pub_out1)
        #---------------------------------------------------------------------------------------------------
    
    with doing_xy(process_num= 5):
        #---------------------------------------------------------------------------------------------------
        all02= all01_2.withColumn("x", F.split(F.col("SEGID"),","))
        all03= all02.select("USERID", "IP", "week", "week_id", F.posexplode("x").alias("seg_rank", "S_Code"))
        all04= all03.withColumnRenamed('USERID', 'uid').drop('seg_rank')
        #
        all04.write.parquet(pub_out2, mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    
    with doing_xy(process_num= 6):
        #---------------------------------------------------------------------------------------------------
        all01_2.show()
        all06= all01_2.where((F.col('week_id')== 0) | (F.col('week_id')== 3))
        #
        j16= all06 \
            .withColumn('DPID', F.lit(857)) \
            .withColumn('COUNTRY', F.lit('GB'))
            #.withColumn('UIDTYPE', F.lit('4'))
        j17= j16.select('DPID','USERID','SEGID','IP','COUNTRY','UIDTYPE')
        #
        j17.repartition(10).write.csv(pub_out3, header= False, sep= '\t', mode= 'overwrite')
        #---------------------------------------------------------------------------------------------------
    
    with doing_xy(process_num= 7):
        #---------------------------------------------------------------------------------------------------
        os.system(f"hdfs dfs -copyToLocal {pub_out3}/* {pub_out4}")
        #
        # dir_temp= '/data/data_to_sts/temp'
        # file_temp= 'for_pubmatic.tsv'
        # dpid= '857'
        # pub_request= 'replaceseg'
        # dir_final= '/data/data_to_sts/marketplaces/pubmatic'
        # #
        # os.system(
        #     "cd " + dir_temp + "\n" \
        #     "timestamp=$(date +%s%3N)\n" \
        #     "md5=$(md5sum " + file_temp + " | awk '{ print $1 }')\n" \
        #     "filename=" + dpid + "_" + pub_request + "_${timestamp}_${md5}.tsv.gz\n" \
        #     "gzip " + file_temp + "\n" \
        #     "mv " + file_temp + ".gz ${filename}\n" \
        #     #"mv ${filename} " + dir_final
        # )
        #---------------------------------------------------------------------------------------------------
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS --------------------------------------"
        #
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        #
        stats_name['tot']   = 'Total Number of Unique UIDs:'
        stats_name['0']     = f'Num UIDs for {pweeks[0]}'
        stats_name['1']     = f'Num UIDs for {pweeks[1]}'
        stats_name['2']     = f'Num UIDs for {pweeks[2]}'
        stats_name['3']     = f'Num UIDs for {pweeks[3]}'
        #
        stats['tot']        = all01_2.groupby('USERID').count().count()
        stats['0']          = all01_2.where(F.col('week_id')== 0).groupby('USERID').count().count()
        stats['1']          = all01_2.where(F.col('week_id')== 1).groupby('USERID').count().count()
        stats['2']          = all01_2.where(F.col('week_id')== 2).groupby('USERID').count().count()
        stats['3']          = all01_2.where(F.col('week_id')== 3).groupby('USERID').count().count()
        #
        if stats_prev!= '':
            stats_perc['tot']   = round(stats['tot']    / stats_prev['tot'] - 1, 4)
            stats_perc['0']     = round(stats['0']      / stats_prev['0'] - 1, 4)
            stats_perc['1']     = round(stats['1']      / stats_prev['1']- 1, 4)
            stats_perc['2']     = round(stats['2']      / stats_prev['2']- 1, 4)
            stats_perc['3']     = round(stats['3']      / stats_prev['3']- 1, 4)
            #
            stats_tl['tot']     = traffic_lights(stats_perc['tot'])
            stats_tl['0']       = traffic_lights(stats_perc['0'])
            stats_tl['1']       = traffic_lights(stats_perc['1'])
            stats_tl['2']       = traffic_lights(stats_perc['2'])
            stats_tl['3']       = traffic_lights(stats_perc['3'])
            #
            result= f"{result}\n\n{stats_tl['tot']} {stats_name['tot']} [{stats['tot']: ,}] ({stats_perc['tot']: 15.2%})"        
            result= f"{result}\n\n{stats_tl['0']} {stats_name['0']} [{stats['0']: ,}] ({stats_perc['0']: 15.2%})"        
            result= f"{result}\n\n{stats_tl['1']} {stats_name['1']} [{stats['1']: ,}] ({stats_perc['1']: 15.2%})"        
            result= f"{result}\n\n{stats_tl['2']} {stats_name['2']} [{stats['2']: ,}] ({stats_perc['2']: 15.2%})"
            result= f"{result}\n\n{stats_tl['3']} {stats_name['3']} [{stats['3']: ,}] ({stats_perc['3']: 15.2%})"
        else:
            stats_perc['tot']   = '-.--'
            stats_perc['0']     = '-.--'
            stats_perc['1']     = '-.--'
            stats_perc['2']     = '-.--'
            stats_perc['3']     = '-.--'
            #
            stats_tl['tot']     = traffic_lights(0)
            stats_tl['0']       = traffic_lights(0)
            stats_tl['1']       = traffic_lights(0)
            stats_tl['2']       = traffic_lights(0)
            stats_tl['3']       = traffic_lights(0)
            #
            result= f"{result}\n\n{stats_tl['tot']} {stats_name['tot']} [{stats['tot']: ,}] ({stats_perc['tot']}%)"        
            result= f"{result}\n\n{stats_tl['0']} {stats_name['0']} [{stats['0']: ,}] ({stats_perc['0']}%)"        
            result= f"{result}\n\n{stats_tl['1']} {stats_name['1']} [{stats['1']: ,}] ({stats_perc['1']}%)"        
            result= f"{result}\n\n{stats_tl['2']} {stats_name['2']} [{stats['2']: ,}] ({stats_perc['2']}%)"
            result= f"{result}\n\n{stats_tl['3']} {stats_name['3']} [{stats['3']: ,}] ({stats_perc['3']}%)"
            result= f"{result}\n\n*If the percentage change is not given, then the counts for the previous week do not exist. This may be because the process is new or the particular stats are new." 
        #
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n--- TOTAL TIME TAKEN --------------------------------"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        result= f"{result}\n\nUIDType done correctly"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)
