
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#--------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 

#--------------------------------------------------------

#de_in1  = 'match2/de/2022-12-19/from_de__*.csv'
#de_out1 = 'match2/process/2022-12-19/tmp.parquet'
#de_out2 = 'match2/process/2022-12-19/de01.parquet'

de_in1  = P030_1_de_in1 
de_out1 = P030_1_de_out1
de_out2 = P030_1_de_out2


email_subject= '*** P030_1: INGEST DE FILE ***'


result= '--- FILES ---'
result= f"{result}\n\n de_in1 = {de_in1}"
result= f"{result}\n\n de_out1 = {de_out1}"
result= f"{result}\n\n de_out2 = {de_out2}"


##################################
# SET UP DICTIONARIES            #
##################################

# Dictionary of Process labels
proc= dict()
proc[1]= 'Create parquet'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---"

try:
    # Create parquet
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        de01= spark.read.csv(de_in1, header= True)
        de01.write.parquet(de_out1, mode= "overwrite")
        de02= spark.read.parquet(de_out1)
        de02.write.parquet(de_out2, mode= "overwrite")
        de03= spark.read.parquet(de_out2)
                
        os.system(f"hdfs dfs -rm -r {de_out1}")
        #---------------------------------------------------------------------------------------------------
        # example:
        #+----------+--------------------+--------+--------------------------------------------------+
        #|     MDTK1|    cb_key_household|      PC|                                      IP_ADDRESSES|
        #+----------+--------------------+--------+--------------------------------------------------+
        #|0690000001|02523097983567790080|AB10 1AS|138.248.142.37;79.77.55.135;90.204.100.245;151....|
        #|0690000002|02523097995392581632|AB10 1AU|86.132.193.193;2a01:4c8:141f:5ea5::;137.50.241....|
        #|0690000003|02523097995394678784|AB10 1AU|86.132.193.193;2a01:4c8:141f:5ea5::;137.50.241....|
        #|0690000004|02523097995398873088|AB10 1AU|86.132.193.193;2a01:4c8:141f:5ea5::;137.50.241....|
        #|0690000005|02523097995399921664|AB10 1AU|86.132.193.193;2a01:4c8:141f:5ea5::;137.50.241....|
    
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS ---"
        
        stats_prev  = P030_1_stats_prev
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        
        stats_name['total'] = 'Number of Rows:'
        
        stats['total']  = de03.count()
        
        stats_perc['total'] = round(stats['total']  / stats_prev['total'] - 1, 4)
        
        stats_tl['total']= traffic_lights(stats_perc['total'])
        
        result= f"{result}\n\n{stats_tl['total']} {stats_name['total']} [{stats['total']: ,}] ({stats_perc['total']: 15.2%})"        
        #---------------------------------------------------------------------------------------------------
        
        email_process(result, email_subject)
    
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)






