
import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import datetime
import contextlib
from pyspark.sql import SparkSession
import pandas as pd
import pyspark.pandas as ps
from pyspark.sql.window import Window

import math

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#----------------------------------------------------------------------------------------

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 



# Settings ------------------------------------------------------------------------------
script_code= 'P272' # For 'Quick Stats'
email_subject= '*** P272: Eyeota add Backlog ***'


# Dictionary of addresses ---------------------------------------------------------------
address_dict= dict()

# Input
address_dict['in1_eye'] = f'/user/unity/match2/marketplaces/eyeota/{bweek}/eyeota.parquet'
address_dict['in2_eye'] = '/user/unity/match2/marketplaces/eyeota'

# Output
address_dict['out1_eye'] = f'/user/unity/match2/marketplaces/eyeota/{bweek}/for_eyeota.parquet'

# Input Test
#address_dict['in1_eye'] = f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/{bweek}/eyeota.parquet'
#address_dict['in2_eye'] = '/user/unity/datascience/griffin/match2/marketplaces/eyeota'
# Output test
#address_dict['out1_eye'] = f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/{bweek}/for_eyeota.parquet'


# List of addresses to clean ------------------------------------------------------------
address_clean= []


# Dictionary of Process labels ----------------------------------------------------------
proc= dict()
proc[1] =   'Read in files'
proc[2] =   'Add backlog'
proc[3] =   'Write to HDFS'


# Dictionary of stats -------------------------------------------------------------------
stats_name= dict()
stats_name['1']= "Input: Number of Rows:"
stats_name['2']= "Number of dates in backlog:"
stats_name['3']= 'Number of ID5s in backlog:'
stats_name['4']= 'Output: Number of rows:'
stats_name['5']= 'Output: Number of ID5s'


# Stats definitions ---------------------------------------------------------------------
def quick_stats_definitions(df1,lst,df2,df3):
    stats= dict()
    stats['1']= df1.count()
    stats['2']= len(lst)
    stats['3']= df2.groupby('ID5').count().count()
    stats['4']= df3.count()
    stats['5']= df3.groupby('ID5').count().count()
    return stats


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
start_all= timer()

result= result_files(address_dict, headers['files'])
result= f"{result}\n\n{headers['health']}"

try:
    # Read in files
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        i01= spark.read.parquet(address_dict['in1_eye'])
        #
        # Read previous 3 weeks
        bweekp= datetime.datetime.strptime(bweek, "%Y-%m-%d")
        bweekp
        #
        date_list= [(bweekp- datetime.timedelta(days=7*x)).strftime("%Y-%m-%d") for x in range(1,4)]
        date_list
        #
        date_list_eye= date_list.copy()
        for x in date_list:
            if file_exists(f"{address_dict['in2_eye']}/{x}/for_eyeota.parquet")!= 0:
                date_list_eye.remove(x)
        #
        date_list_eye
        #
        for count, x in enumerate(date_list_eye):
            tmp= spark.read.parquet(f"{address_dict['in2_eye']}/{x}/for_eyeota.parquet")
            tmp= tmp.withColumn('week_id', F.lit(count+1))
            if count== 0:
                eyeb01= tmp
            else:
                eyeb01= eyeb01.unionByName(tmp)
        #
        window1= Window.partitionBy('ID5').orderBy('week_id')
        eyeb02= eyeb01.withColumn('row_num', F.row_number().over(window1)).where(F.col('row_num')== 1).drop('row_num')
        #---------------------------------------------------------------------------------------------------
    #
    # Format and Subset S_Codes
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        i02= i01.join(eyeb02, ['ID5','SEGID'], 'left_anti')
        i02= i02.select('ID5','COUNTRY','SEGID')
        #---------------------------------------------------------------------------------------------------
    #
    # Join to UID S_Code file
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        i02.write.parquet(address_dict['out1_eye'], mode= 'overwrite')
        i03= spark.read.parquet(address_dict['out1_eye'])
        #---------------------------------------------------------------------------------------------------
    #
    # CREATE QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------       
        result= f"{result}\n\n{headers['qstats']}"
        # Loads stats from previous run (max 2 weeks ago)
        stats_prev  = stats_prev_load(quick_stats_path, script_code, bweek)
        # Use function to create this weeks stats
        stats= quick_stats_definitions(i01, date_list_eye, eyeb02, i03)
        # Percentage change
        stats_perc, stats_tl, result= quick_stats(stats, stats_name, stats_prev, result)
        # Save this run's stats
        quick_stats_backup(quick_stats_path, script_code, bweek, stats)        
        #---------------------------------------------------------------------------------------------------
        #
        end_all= timer()
        time_all= str(datetime.timedelta(seconds = round(end_all- start_all, 0)))
        #
        result= f"{result}\n\n{headers['time']}"
        result= f"{result}\n\n{emoji['clock']} {time_all}"
        #
        email_process(result, email_subject)
    #
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
    #
    # Clean up
    clean_up_hdfs(address_clean)
#
except Exception as error:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    result= f"{result} ({type(error).__name__}: {error})"
    email_process(result, email_subject)



# dct= [{'ID5': 'x' ,'COUNTRY': 'US', 'SEGID': 'S9999999'}]
# pdf= pd.DataFrame(dct)
# pdf

# xps= ps.from_pandas(pdf)
# df1= xps.to_spark()
# df1.show()

# df1= df1.where(F.col('ID5')=='y')
# df1.show()
# df1.write.parquet(f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/2023-12-25/eyeota.parquet', mode= 'overwrite')
# df1= spark.read.parquet(f'/user/unity/datascience/griffin/match2/marketplaces/eyeota/2023-12-25/eyeota.parquet', mode= 'overwrite')
