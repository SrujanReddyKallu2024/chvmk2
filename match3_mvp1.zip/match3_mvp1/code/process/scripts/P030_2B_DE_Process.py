
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

#==============================================================

scripts = os.path.dirname(__file__)
dir01   = os.path.split(scripts)[0]

configs = os.path.join(dir01, 'configs')
dictions= os.path.join(dir01, 'dictionaries')
funcs   = os.path.join(dir01, 'funcs')

sys.path.append(configs)
sys.path.append(dictions)
sys.path.append(funcs)

from config_process import *
from process_dict import *
from process_functions import *

exec_func= os.path.join(funcs, 'exec_functions.py')
exec(open(exec_func).read())

if process_run in (0,3):
    from process_adresses import *
    from unit_test_stats import *
else:
    from unit_test_adresses import *
    from unit_test_stats import *
    if process_run== 2:
        from wrong_test_addresses import * 
 
#==============================================================


#de_in1 = 'match2/process/2022-12-19/de01.parquet'
#de_out1 = 'match2/process/2022-12-19/de01_long.parquet'
de_in1  = P030_2B_de_in1
de_out1 = P030_2B_de_out1


email_subject= '*** P030_2: PROCESS DE FILE ***'

result= '--- FILES ---'
result= f"{result}\n\n de_in1 = {de_in1}"
result= f"{result}\n\n de_out1 = {de_out1}"


#=================================
# SET UP DICTIONARIES            =
#=================================

# Dictionary of Process labels
proc= dict()
proc[1]= 'Create parquet'
proc[2]= 'Transpose into long form'
proc[3]= 'Write to HDFS'


#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################

# Initiate results string with title of process
result= f"{result}\n\n--- PROCESS HEALTH ---"

try:
    # Create parquet
    with doing_xy(process_num= 1):
        #---------------------------------------------------------------------------------------------------
        de01= spark.read.parquet(de_in1)
        #---------------------------------------------------------------------------------------------------
        
    # Transpose into long form
    with doing_xy(process_num= 2):
        #---------------------------------------------------------------------------------------------------
        de02= de01
        de03= de02\
            .withColumnRenamed('ip_address', 'ip')\
            .withColumnRenamed('rank', 'ip_rank')
        #
        de03_2= de03.withColumn('ip_flag', F.when(F.col('ip').rlike("\d+\.+\d+\.+\d+\.+\d"), '1').otherwise('0'))
        #---------------------------------------------------------------------------------------------------
        
    # Write to parquet
    with doing_xy(process_num= 3):
        #---------------------------------------------------------------------------------------------------
        de03_2.write.parquet(de_out1, mode= 'overwrite')
        de04= spark.read.parquet(de_out1)
        #---------------------------------------------------------------------------------------------------
        
    # QUICK STATS
    try:
        #---------------------------------------------------------------------------------------------------
        result= f"{result}\n\n--- QUICK STATS ---"
        
        stats_name  = dict()
        stats       = dict()
        stats_perc  = dict()
        stats_tl    = dict()
        stats_prev  = P030_2_stats_prev
        
        stats_name['total'] = 'Number of Rows:'
        stats_name['hh_ip'] = 'Number of UDPRNs with IP:'
        stats_name['ip']    = 'Number of IPs:'
        
        stats['total']  = de04.count()
        stats['hh_ip']  = de04.groupby('UDPRN').count().count()
        stats['ip']     = de04.groupby('ip').count().count()
        
        stats_perc['total'] = round(stats['total']  / stats_prev['total'] - 1, 4)
        stats_perc['hh_ip'] = round(stats['hh_ip']  / stats_prev['hh_ip'] - 1, 4)
        stats_perc['ip']    = round(stats['ip']     / stats_prev['ip']- 1, 4)
        
        stats_tl['total']= traffic_lights(stats_perc['total'])
        stats_tl['hh_ip']= traffic_lights(stats_perc['hh_ip'])
        stats_tl['ip']= traffic_lights(stats_perc['ip'])
        
        result= f"{result}\n\n{stats_tl['total']} {stats_name['total']} [{stats['total']: ,}] ({stats_perc['total']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['hh_ip']} {stats_name['hh_ip']} [{stats['hh_ip']: ,}] ({stats_perc['hh_ip']: 15.2%})"        
        result= f"{result}\n\n{stats_tl['ip']} {stats_name['ip']} [{stats['ip']: ,}] ({stats_perc['ip']: 15.2%})"        
        #---------------------------------------------------------------------------------------------------
        
        email_process(result, email_subject)
        
    except:
        result= f"{result}\n\n{emoji['fail']} Stats failed"
        email_process(result, email_subject)
        
except:
    result= f"{result}\n\n{emoji['fail']} {proc[process_num2]}"
    email_process(result, email_subject)






