
#P010_1
P010_1_stats_prev= dict()
P010_1_stats_prev['total'] = 1000
P010_1_stats_prev['cb_key']= 969
P010_1_stats_prev['udprn'] = 969

# P010_2
P010_2_stats_prev = dict()
P010_2_stats_prev['tax_p_total']    = 4346904178
P010_2_stats_prev['tax_h_total']    = 390112  
P010_2_stats_prev['tax_mc_total']   = 330983 
P010_2_stats_prev['seg_total']      = 1114

# P015
P015_stats_prev = dict()
P015_stats_prev['tot_in']     = 12000000
P015_stats_prev['tot_out']    = 12000000

# P020_1
P020_1_stats_prev= dict()
P020_1_stats_prev['Total_A16'] = 26
P020_1_stats_prev['Total_dt']  = 1000
P020_1_stats_prev['hh']        = 24
P020_1_stats_prev['udprn']     = 24
P020_1_stats_prev['Total_hhs'] = 24
P020_1_stats_prev['Total_pp']  = 24

# P020_2
P020_2_stats_prev= dict()
P020_2_stats_prev['Tax']   = 1000
P020_2_stats_prev['UDPRN'] = 847
P020_2_stats_prev['Out']   = 824

# P030_1
P030_1_stats_prev= dict()
P030_1_stats_prev['total']= 966

# P030_2
P030_2_stats_prev= dict()
P030_2_stats_prev['total'] = 2792
P030_2_stats_prev['hh_ip'] = 610
P030_2_stats_prev['ip']    = 2631

# P35_1
P035_1_stats_prev= dict()
P035_1_stats_prev['HH0']    = 26678835
P035_1_stats_prev['HH1']    = 19840165

# P35_2
P035_2_stats_prev= dict()
P035_2_stats_prev['CHV']    = 18108117
P035_2_stats_prev['DE']     = 19840165
P035_2_stats_prev['BOTH']   = 12337292

#P035_3
P035_3_stats_prev= dict()
P035_3_stats_prev['PUB']    = 4275555
P035_3_stats_prev['DE']     = 7135677
P035_3_stats_prev['BOTH']   = 753679
P035_3_stats_prev['HH']     = 1705386

#P035_4
P035_4_stats_prev= dict()
P035_4_stats_prev['HH0'] = 7323308
P035_4_stats_prev['IP0'] = 6381998
P035_4_stats_prev['HH1'] = 14042678
P035_4_stats_prev['IP1'] = 9373054

#P036_1
P036_1_stats_prev= dict()
P036_1_stats_prev['HH0'] = 14599923
P036_1_stats_prev['IP0'] = 9481651
P036_1_stats_prev['HH1'] = 83710
P036_1_stats_prev['IP1'] = 81954
P036_1_stats_prev['HH2'] = 14573952
P036_1_stats_prev['IP2'] = 9420198

# P040
P040_stats_prev  = dict()
P040_stats_prev['total']    = 36550674
P040_stats_prev['ip']       = 3894397
P040_stats_prev['uid']      = 36550670
P040_stats_prev['total2']   = 30180467
P040_stats_prev['ip2']      = 3894397
P040_stats_prev['uid2']     = 30180467

# P050_1
P050_1_stats_prev= dict()
P050_1_stats_prev['HH0']  = 14000000
P050_1_stats_prev['IP0']  = 2500000

# P050_2
P050_2_stats_prev  = dict()
P050_2_stats_prev['total']     = 3834
P050_2_stats_prev['cb_key']    = 362
P050_2_stats_prev['cb_key_dd'] = 350
P050_2_stats_prev['uid']       = 3688
P050_2_stats_prev['uid_dd']    = 3688

# P050_3_UID_S_Code.py
P050_3_stats_prev= dict()
P050_3_stats_prev['Tot'] = 4000000000
P050_3_stats_prev['uid'] = 35000000
P050_3_stats_prev['code']= 910

# P060
P060_stats_prev= dict()
P060_stats_prev['total']    = 617052
P060_stats_prev['uid']      = 3675

# P070
P070_stats_prev= dict()
P070_stats_prev['tot']  = 35000000
P070_stats_prev['uid']  = 35000000
P070_stats_prev['code'] = 900

# P070_1
P070_1_stats_prev= dict()
P070_1_stats_prev['UID']    = 37000000

# P080_1
P080_1_stats_prev= dict()
P080_1_stats_prev['total'] = 1000
P080_1_stats_prev['ip']    = 998

# P080_2
P080_2_stats_prev= dict()
P080_2_stats_prev['total'] = 2147
P080_2_stats_prev['ip']    = 2077

# P080_3
P080_3_stats_prev= dict()
P080_3_stats_prev['total'] = 1000
P080_3_stats_prev['ip']    = 1000

# P080_4
P080_4_stats_prev  = dict()
P080_4_stats_prev['total'] = 4075
P080_4_stats_prev['ip']    = 4075

# P080_5
P080_5_stats_prev= dict()
P080_5_stats_prev['tot_ip']   = 4075
P080_5_stats_prev['tot_sup']  = 2800
P080_5_stats_prev['ip_0']     = 4074
P080_5_stats_prev['ip_1']     = 1

# P080_6
P080_6_stats_prev  = dict()
P080_6_stats_prev['tot_in']    = 4075
P080_6_stats_prev['tot_out']   = 3074













