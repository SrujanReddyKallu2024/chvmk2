
# Dictionary of emojis
emoji= dict()
emoji['pass']   = '✔'
emoji['fail']   = '❌'
emoji['green']  = '🟢'
emoji['amber']  = '🟡'
emoji['red']    = '🔴'
emoji['clock']  = '🕒'

# Process health and quick stata headers
headers= dict()
headers['files']    = '--- FILES ------------------------------------------------------------------------------------------'
headers['health']   = '--- PROCESS HEALTH ----------------------------------------------------------------------------'
headers['qstats']   = '--- QUICK STATS ---------------------------------------------------------------------------------'
headers['time']     = '--- TOTAL TIME TAKEN ---------------------------------------------------------------------------'



