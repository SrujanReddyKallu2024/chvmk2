
import contextlib

# Function to add pre and post code to each subprocess
@contextlib.contextmanager
def doing_xy(process_num):
    global result, process_num2
    # Pre code
    process_num2= process_num
    start= timer()
    yield
    # Post code
    end= timer()
    time= str(datetime.timedelta(seconds = round(end- start, 0)))
    result= f"{result}\n\n{emoji['pass']} {proc[process_num]} ({emoji['clock']} {time})"
    print(result)


