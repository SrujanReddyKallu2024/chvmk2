
import os
import sys
import pyspark.sql.functions as F
from timeit import default_timer as timer
import datetime
import pandas as pd
import contextlib
from pyspark.sql import SparkSession
import json
import subprocess
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, ArrayType
import socket
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
import smtplib

spark = SparkSession.builder.appName("griff.com").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

from config_process import *
from process_dict import *


def email_process(subprocess, subject,mail_to='andrew.griffin@experian.com'):
    
    import smtplib
    from email.mime.text import MIMEText
    
    msg = MIMEText(subprocess)
    msg['Subject'] = subject
    msg['From'] = email # from config_process
    msg['To'] = mail_to
    
    # Send the message via our own SMTP server, but don't include the
    # envelope header.
    s = smtplib.SMTP('localhost')
    s.sendmail(msg['From'], msg['To'], msg.as_string())
    s.quit()


# Function to apply triffic lights to stats
def traffic_lights(x):
    if x> 0:
        y= emoji['green']
    elif x< 0:
        y= emoji['red']
    else:
        y= emoji['amber']
    return y
    

def latest_file(path, pattern=''):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    '''
    import subprocess
    import re
    files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    dirx= y[-1]
    return dirx


def list_files(path, pattern=''):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    '''
    import subprocess
    import re
    files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    return y


def latest_file_local(path, pattern= ''):
    lenptrn= len(pattern)
    lst1= os.listdir(path)
    lst2= [x for x in lst1 if os.path.split(x)[1][0:lenptrn]==pattern]
    lst3= sorted(lst2)
    return lst3[-1]


def list_files_local(path, pattern= ''):
    lenptrn= len(pattern)
    lst1= os.listdir(path)
    lst2= [x for x in lst1 if os.path.split(x)[1][0:lenptrn]==pattern]
    lst3= sorted(lst2)
    return lst3


def last_Monday(date= datetime.date.today()):
    '''
    * Gives the date of the previous Monday. 
    * If the day is Monday then returns the imput date.
    * Default is input is today's date.
    * Returns string as 'YYYY-MM-DD'
    * Argument can be date object
    *Use:
        date= last_Monday()
        date= last_Monday(DateObject)
    '''
    bweek = date - datetime.timedelta(days=date.weekday())
    bweek_str= bweek.strftime("%Y-%m-%d")
    return bweek_str


def next_Monday(date= datetime.date.today()):
    '''
    * Gives the date of the next Monday. 
    * If the day is Monday then returns the NEXT MONDAY.
    * Default is input is today's date.
    * Returns string as 'YYYY-MM-DD'
    * Argument can be date object
    *Use:
        date= next_Monday()
        date= next_Monday(DateObject)
    '''
    nweek = date + datetime.timedelta(days=-date.weekday(), weeks= 1)
    nweek_str= nweek.strftime("%Y-%m-%d")
    return nweek_str


def minus_days(date, days):
    pweek= datetime.datetime.strptime(date, "%Y-%m-%d")-datetime.timedelta(days= days)
    pweek= pweek.strftime("%Y-%m-%d")
    return pweek


def minus_months(date, months):
    pmonth= datetime.datetime.strptime(date, "%Y-%m")-relativedelta(months=months)
    pmonth= pmonth.strftime("%Y-%m")
    return pmonth


def file_exists(path):
    proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', path])
    proc.communicate()
    return proc.returncode


def current_month(date1= datetime.date.today()):
    bweek_str= date1.strftime("%Y-%m")
    return bweek_str


# Apply NMR
def nmr_apply(df_in):
    #
    nmr_path= '/user/unity/v2/weekly_nmr'
    nmr= latest_file(nmr_path, 'A16')
    print(nmr)
    #
    nmr01= spark.read.csv(nmr, header= True)
    nmr02= nmr01.groupby('cb_key_household').count().drop('count')
    #
    temp01= df_in.join(nmr02, 'cb_key_household', 'left_anti')
    #
    return temp01


# Apply CIP
def cip_apply(df_in):
    #
    pub_cip_path= '/user/unity/v2/central_backlog/cip/*/'
    cip= latest_file(pub_cip_path, 'master_optouts_cip_backlog')
    print(cip)
    #
    cip01= spark.read.parquet(cip)
    cip02= cip01.withColumnRenamed('host', 'ip')
    cip03= cip02.groupby('ip').count().drop('count')
    #
    temp01= df_in.join(cip03, 'ip', 'left_anti')
    #
    return temp01


# Clean-up
def clean_up_hdfs(add):
    for x in add:
        os.system(f"hdfs dfs -rm -r {x}")


def parse_cmpid_list(ctx, jsonfilepath):
    """
    Loads cmpid list from HDFS (server) and local path (local) and outputs a list of cmp ids
    """
    from datetime import datetime
    if sys.platform[:3]!="win":        
        servername = (socket.gethostname())[:-1]+"1"
        file_path = f"hdfs://{servername}:8020{jsonfilepath}"
        rdd = ctx.sparkContext.wholeTextFiles(file_path)
        # Parse the JSON and extract the "cmpids" dictionary
        def parse_json(file_content):
            data = json.loads(file_content)
            cmps = data.get('cmps', {})
            cmps_keys = []
            current_time = datetime.now()
            for key, value in cmps.items():
                if 'deletedDate' in value:
                    deletedDate = datetime.strptime(value['deletedDate'], "%Y-%m-%dT%H:%M:%SZ")
                    if deletedDate > current_time:
                        cmps_keys.append(str(key))
                else:
                    cmps_keys.append(str(key))
            return cmps_keys
        parse_json_udf = F.udf(parse_json, ArrayType(StringType()))
        df = rdd.toDF(["path", "content"])
        df = df.withColumn("cmp_keys", parse_json_udf(df.content))
        return df.select("cmp_keys").collect()[0]["cmp_keys"]


def parse_tcf(df, tcf_col):
    """
    Parses TCF string in dataframe column and extracts the version, purposes consented to, vendors consented to, and CMP ID
    """
    # create a udf to check tcf version and then use the appropriate decode function decode the tcf string 
    sys.path.append("./venv/lib/python3.9/site-packages")
    def decode_tcf(tcf_string):        
        import iab_tcf as iab
        try:
            consent = iab.decode(tcf_string)
            # version = getattr(consent, 'version', None)
            tcf_purposes_consent = [k for k, v in getattr(consent, 'purposes_consent', {}).items() if v]
            tcf_vendor_consent = [k for k, v in getattr(consent, 'consented_vendors', {}).items() if v]
            cmp_id = getattr(consent, 'cmp_id', None)
            return tcf_purposes_consent, tcf_vendor_consent, cmp_id, #version
        except:
            return [0], [0], [0]
    decode_tcf_udf = F.udf(decode_tcf, StructType([
        #StructField("version", IntegerType(), True),
        StructField("tcf_purposes_consent", ArrayType(IntegerType()), True),
        StructField("tcf_vendor_consent", ArrayType(IntegerType()), True),
        StructField("cmp_id", IntegerType(), True)    
    ]))
    return (
        df
        .where(~F.col("type_uid").isin(['android','ios']))
        .withColumn("decoded", decode_tcf_udf(df[tcf_col]))
        .select("*", "decoded.*").drop("decoded")
    )


def identify_invalid_tcf(df, gcl):
    """
    Filters out invalid TCF strings from a DataFrame
    Conditions:-
    1. tcf_vendor_consent should have values 877 and 131
    2. tcf_purposes_consent should have values 3,5,10
    3. cmp_id shold be one of the valid cmp_ids from the global cmpid list(gcl)
    """
    return (
        df
        .withColumn(
            "tcf_consent",
            F.when(
                (F.array_contains(df.tcf_vendor_consent, 877)) &
                (F.array_contains(df.tcf_vendor_consent, 131)) &
                (F.array_contains(df.tcf_purposes_consent, 1)) &
                (F.array_contains(df.tcf_purposes_consent, 3)) &
                (F.array_contains(df.tcf_purposes_consent, 5)) &
                (F.array_contains(df.tcf_purposes_consent, 10)) &
                (F.col("cmp_id").isin(gcl)),
                F.lit('1')
            ).otherwise(F.lit('0'))
        )
        .drop("tcf_vendor_consent", "tcf_purposes_consent", "cmp_id", "version")
    )


def get_valid_date_dirs(indir, dateformat=r"\d{4}-\d{2}-\d{2}$"):
    """
    Lists all valid date directories in the input HDFS directory
    """
    import re
    import subprocess    
    hdfs_cmd = ["hdfs", "dfs", "-ls", indir]    
    proc = subprocess.run(hdfs_cmd, capture_output=True, text=True)
    all_folders = [
        line.split()[7] for line in proc.stdout.splitlines() 
        if line and 'Picked' not in line and len(line.split()) > 7        
    ]
    date_pattern = re.compile(dateformat)
    all_dates = [re.search(date_pattern, path).group() for path in all_folders if re.search(date_pattern, path)]
    return all_dates if all_dates else []

#----------------------------------------------------------------------------------------
# QUICK STATS FUNCTIONS -----------------------------------------------------------------
#----------------------------------------------------------------------------------------

def quick_stats_result(stats, stats_name, stats_perc, stats_tl, result):
    for key, value in stats.items():
        result= f"{result}\n\n{stats_tl[key]} {stats_name[key]} [{stats[key]: ,}] ({stats_perc[key]}%)"
    return result

def latest_file_local(path, pattern= ''):
    lenptrn= len(pattern)
    lst1= os.listdir(path)
    lst2= [x for x in lst1 if os.path.split(x)[1][0:lenptrn]==pattern]
    lst3= sorted(lst2)
    return lst3[-1]

def get_prev_stats_filename(path, pweek1, pweek2):
    if os.path.isdir(path):
        filepath1= f'{path}/{pweek1}'
        filepath2= f'{path}/{pweek2}'
        if os.path.isdir(filepath1):
            return f"{filepath1}/{latest_file_local(filepath1, 'stats_')}"
        elif os.path.isdir(filepath2):
            return f"{filepath2}/{latest_file_local(filepath2, 'stats_')}"
    return ''

def stats_prev_load(quick_stats_path, script_code, bweek, update_frequency= 'week'):
    quick_stats_path_ext= os.path.join(quick_stats_path, script_code)
    #
    if update_frequency== 'week':
        pweek1= minus_days(bweek, 7)
        pweek2= minus_days(bweek, 14)
    elif update_frequency== 'month':
        pweek1= minus_months(bweek,1)
        pweek2= minus_months(bweek,2)
    else:
        return ''
    #
    stats_filename= get_prev_stats_filename(quick_stats_path_ext, pweek1, pweek2)
    #
    if stats_filename== '':
        return ''
    #
    with open(stats_filename, 'r') as fp:
        return json.load(fp)

def result_files(address_dict, header):
    result= header
    for key, item in address_dict.items():
        result= f"{result}\n\n {key}: {item}"
    return result

def quick_stats_perc(stats, stats_prev):
    stats_perc= dict()
    if stats_prev== '':
        stats_prev= dict()
    for key, value in stats.items():
        if key in stats_prev:
            stats_perc[key]   = round(100*(stats[key]/ stats_prev[key] - 1), 2)
        else:
            stats_perc[key]   = '-.--'
    return stats_perc

def quick_stats_traffic(stats_perc):
    stats_tl= dict()
    for key, value in stats_perc.items():
        if stats_perc[key]== '-.--':
            stats_tl[key]= traffic_lights(0)
        else:
            stats_tl[key]= traffic_lights(stats_perc[key])
    return stats_tl

def quick_stats(stats, stats_name, stats_prev, result):
    stats_perc= quick_stats_perc(stats, stats_prev)
    stats_tl= quick_stats_traffic(stats_perc)
    result= quick_stats_result(stats, stats_name, stats_perc, stats_tl, result)
    return stats_perc, stats_tl, result

def quick_stats_backup(quick_stats_path, script_code, bweek, stats):
    #
    quick_stats_path_ext= os.path.join(quick_stats_path, script_code)
    quick_stats_path_ext_dt= os.path.join(quick_stats_path_ext, bweek)
    #
    if not os.path.isdir(quick_stats_path_ext):
        os.system(f'mkdir {quick_stats_path_ext}')
    #
    if not os.path.isdir(quick_stats_path_ext_dt):
        os.system(f'mkdir {quick_stats_path_ext_dt}')
    #
    now= datetime.datetime.now()
    now= now.strftime("%Y-%m-%d_%H-%M-%S")
    filename= f'stats_{now}.txt'
    #
    with open(f'{quick_stats_path_ext_dt}/{filename}', 'w') as fp:
        json.dump(stats, fp)


def update_stats(stats, milestone, status="success", message=""):
    """
    Update the stats dictionary with the milestone, status and message
    """
    from datetime import datetime
    STATUS_EMOJIS = {
        'green': '\U00002705',  # ✅
        'amber': '\U000026A0',  # ⚠️
        'red': '\U0000274C'     # ❌
    }
    stats.append({
        "Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Milestone": milestone,
        "Message": message,
        "Status": STATUS_EMOJIS['green'] if status.lower()=="success" else STATUS_EMOJIS['red']
    })


def get_greeting():
    """
    Gets the greeting based on time of day
    """
    now_time = datetime.now()
    if (now_time.hour>=12) & (now_time.hour<17):
        return "Good afternoon"
    elif (now_time.hour>=17):
        return "Good evening"
    else:
        return "Good morning"


def send_email(email_to, email_subject, email_body=None, file_path=None, sender="emsactivate@experian.com"):
    # email variables    
    greeting = get_greeting()
    email_from = sender
    email_cc = ''
    if email_body is None:
        email_body = f"Please find attached the latest {email_subject}"      
    message_body = f"{greeting},\n\n{email_body}.\n\nThanks and regards \nExperian Match Team"
    smtp_server = "relay.uk.experian.local"
    msg = MIMEMultipart()
    body_part = MIMEText(message_body, 'plain')
    msg['Subject'] = email_subject
    msg['From'] = email_from
    msg['To'] = email_to
    # Add body to email
    msg.attach(body_part)
    if file_path is not None:
        with open(file_path, 'rb') as f:
            attachment = MIMEApplication(f.read(), _subtype='xlsx')
        
        attachment.add_header('Content-Disposition', 'attachment', filename=os.path.split(file_path)[-1])
        msg.attach(attachment)
    smtp = smtplib.SMTP(smtp_server)
    smtp.sendmail(email_from, email_to.split(","), msg.as_string())
    smtp.quit()


def send_teams_email(mask, email_subject, body, email_to, swap_newlines=True):
    """
    email formatted for both stats and alerts
    """
    # email variables
    EMAIL_FROM = 'emsactivate@experian.com'
    EMAIL_CC = ''
    SMTP_SERVER = "relay.uk.experian.local"
    msg = MIMEMultipart('alternative')
    if body==False:
        body = "No stats generated, please check logs."
    if swap_newlines:
        body = body.replace("\\n","<br>")

    msg_body = f"""\
        <!DOCTYPE html>
        <html>
          <head></head>
          <body>
            <div style="text-align: center;"><b>{email_subject}</b></div>
            <br>
            <br>
            {body}
            <br>
            <p style='margin-bottom:0;'>Thanks and regards</p>
            <p style="margin : 0; padding-top:0;">Experian Match Team</p>
          </body>
        </html>
    """
    body_part = MIMEText(msg_body, 'html')
    msg['Subject'] = mask + ": " + email_subject
    msg['From'] = EMAIL_FROM
    msg['To'] = email_to
    msg.attach(body_part)
    smtp = smtplib.SMTP(SMTP_SERVER)    
    smtp.sendmail(EMAIL_FROM, email_to.split(","), msg.as_string())
    smtp.quit()


def compare_stats(logger, mask, quick_stats_path, alerts_df, freq=7):
    """
    Compares the latest stats with the previous stats and merges them into a single dataframe
    if previous stats couldn't be found, it returns the latest stats only
    """
    pmask = minus_days(mask, freq)
    previous_qstats_path = quick_stats_path.format(wsd=pmask)
    logger.info(f"previous stats path: {previous_qstats_path}")
    try:
        previous_alerts_df = pd.read_csv(previous_qstats_path)
        logger.info(f"read previous stats from {previous_qstats_path}")
        if previous_alerts_df is None:
            latest_alerts_df = alerts_df
            logger.info("no previous quick stats found, using only latest stats")
        else:
            latest_alerts_df = pd.merge(alerts_df, previous_alerts_df, on="Milestone", how="left")
            logger.info("merged latest quick stats with previous quick stats")
    except:
        latest_alerts_df = alerts_df
        logger.info("unable to load previous quick stats, using only latest stats")    
    return latest_alerts_df